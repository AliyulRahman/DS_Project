# E-commerce Customer Segmentation — Interview & Viva Q&A Guide

---

## PART 1: PROJECT-SPECIFIC QUESTIONS

---

### 1.1 Dataset & Problem Understanding

**Q1. What is the goal of this project?**
To segment e-commerce customers into distinct groups based on their purchasing behavior using RFM analysis and clustering algorithms, so the business can tailor marketing strategies to each group.

**Q2. Describe the dataset.**
The dataset contains 541,909 retail transactions from a UK-based online store (Dec 2010 – Dec 2011) with 8 columns: InvoiceNo, StockCode, Description, Quantity, InvoiceDate, UnitPrice, CustomerID, Country. It covers 38 countries with 4,372 unique customers.

**Q3. Why is this an unsupervised learning problem?**
There are no pre-existing labels telling us which segment a customer belongs to. The model must discover natural groupings in the data on its own — this is the definition of unsupervised learning.

**Q4. What is RFM Analysis?**
RFM stands for:
- **Recency (R)**: How many days since the customer's last purchase. Lower = more engaged.
- **Frequency (F)**: How many unique orders the customer placed. Higher = more loyal.
- **Monetary (M)**: Total amount the customer has spent. Higher = more valuable.
These three features together capture the most important dimensions of customer purchasing behavior.

---

### 1.2 Data Cleaning & Preprocessing

**Q5. What data cleaning steps did you perform?**
1. Removed 9,288 cancelled orders (InvoiceNo starting with 'C')
2. Dropped 135,080 rows with missing CustomerID (25% of data — cannot segment without an ID)
3. Removed rows with Quantity ≤ 0 or UnitPrice ≤ 0 (returns, adjustments, test entries)
4. Converted CustomerID to integer and InvoiceDate to datetime
5. Added TotalAmount = Quantity × UnitPrice

After cleaning: **397,884 transactions, 4,338 unique customers**.

**Q6. Why did you drop rows with missing CustomerID instead of imputing?**
CustomerID is the key used to aggregate transactions per customer and compute RFM features. There is no meaningful way to impute an identity — you cannot guess which customer made an anonymous transaction. Dropping is the only valid option.

**Q7. Why remove cancelled orders?**
Cancelled orders have negative monetary value and inflate recency/frequency counts incorrectly. Including them would distort the RFM features and produce misleading segments.

**Q8. What is TotalAmount and why did you add it?**
TotalAmount = Quantity × UnitPrice. It represents the revenue generated per line item. This is aggregated per customer to compute the Monetary RFM feature.

---

### 1.3 Feature Engineering & Scaling

**Q9. Why apply log transformation before scaling?**
RFM features are heavily right-skewed (a few customers spend 100× more than average). Log transformation (log1p) compresses the long tail, making the distribution more symmetric. Without it, outliers dominate the clustering and distort cluster shapes.

**Q10. What is StandardScaler and why is it necessary?**
StandardScaler transforms each feature to have mean=0 and standard deviation=1. It is necessary because K-Means and other distance-based algorithms use Euclidean distance — if one feature has a much larger scale (e.g., Monetary in £1000s vs Recency in days), it will dominate the distance calculation and overshadow the others.

**Q11. Why save the scaler as scaler.pkl?**
Any new customer data must be transformed using the exact same mean and std that was calculated on the training data. If you re-fit the scaler on new data, the transformation would be different and the model's predictions would be incorrect. The saved scaler ensures consistency.

**Q12. What is the reference date in RFM and why is it important?**
The reference date is one day after the last transaction in the dataset (2011-12-10). Recency is calculated as the number of days between each customer's last purchase and this reference date. Using a fixed reference date ensures all recency values are comparable.

---

### 1.4 Clustering Algorithms

**Q13. How does K-Means work?**
1. Randomly initialise k cluster centroids (k-means++ places them far apart for better initialisation)
2. Assign each data point to the nearest centroid (using Euclidean distance)
3. Recalculate each centroid as the mean of all points assigned to it
4. Repeat steps 2–3 until centroids stop moving (convergence)
5. Output: cluster labels for every data point

**Q14. What is the Elbow Method?**
Plot inertia (within-cluster sum of squared distances) against number of clusters k. As k increases, inertia decreases. The "elbow" is where the rate of decrease sharply slows — this is the optimal k. Beyond this point, adding more clusters gives diminishing returns.

**Q15. What is the Silhouette Score?**
For each point, it measures:
- **a** = average distance to points in the same cluster
- **b** = average distance to points in the nearest other cluster
- **score = (b - a) / max(a, b)**

Range: -1 to 1. Score near 1 = well-clustered. Score near 0 = on boundary. Score negative = misclassified. The overall silhouette score is the mean across all points.

**Q16. What is Davies-Bouldin Index?**
Measures the average similarity between each cluster and its most similar cluster. Similarity = ratio of within-cluster scatter to between-cluster distance. **Lower is better**. A score of 0 means perfectly separated clusters.

**Q17. What is Calinski-Harabasz Index?**
Also called the Variance Ratio Criterion. It is the ratio of between-cluster variance to within-cluster variance. **Higher is better** — it means clusters are dense and well-separated.

**Q18. How does Hierarchical Clustering work?**
Starts with every point as its own cluster, then repeatedly merges the two closest clusters (agglomerative / bottom-up approach). The linkage criterion (Ward, Complete, Average) defines how distance between clusters is measured. Ward minimises the total within-cluster variance, making it preferred for compact clusters. Results are visualised as a dendrogram — cut horizontally to get k clusters.

**Q19. What are the limitations of Hierarchical Clustering?**
- Time complexity O(n³) and space O(n²) — does not scale to large datasets
- Once two points are merged, they cannot be separated (greedy approach)
- Sensitive to outliers
- In this project: used on a 200-point sample for the dendrogram

**Q20. How does DBSCAN work?**
Density-Based Spatial Clustering of Applications with Noise:
- For each point, count neighbours within radius **eps**
- If a point has ≥ **min_samples** neighbours → it is a **core point**
- Points within eps of a core point are **border points**
- Points that are neither → **noise (-1)**
- Clusters = connected regions of core points

Key advantage: does not require k to be specified; can find arbitrarily shaped clusters and identify outliers.

**Q21. What are eps and min_samples in DBSCAN? How did you choose them?**
- **eps**: the radius of the neighbourhood around each point
- **min_samples**: minimum number of points needed to form a dense region
Used the **k-distance plot**: sorted distances to the 4th nearest neighbour for all points. The "elbow" in this curve suggests eps ≈ 0.5. min_samples = 5 is a common default (≥ dimensions + 1).

**Q22. Why did DBSCAN perform poorly on this dataset?**
DBSCAN found only 2 meaningful clusters and classified many customers as noise. RFM customer data tends to form broad, roughly spherical clusters without sharp density boundaries. DBSCAN excels with irregular-shaped, density-varying clusters — not RFM-style data.

**Q23. How does a Gaussian Mixture Model (GMM) differ from K-Means?**
- K-Means uses hard assignment (each point belongs to exactly one cluster)
- GMM uses soft assignment (each point has a probability of belonging to each cluster)
- GMM models each cluster as a Gaussian distribution; clusters can be elliptical (not just spherical like K-Means)
- GMM is more flexible but more complex and slower
- In this project GMM had lower Silhouette Score (0.173) vs K-Means (0.337), suggesting K-Means better fits the RFM data structure

**Q24. What is BIC and AIC in the context of GMM?**
- **BIC (Bayesian Information Criterion)**: penalises model complexity; lower is better
- **AIC (Akaike Information Criterion)**: similar but less penalty for complexity; lower is better
Used to select the optimal number of GMM components. The k where BIC/AIC is minimised is the best.

---

### 1.5 Model Selection & Results

**Q25. Why was K-Means selected as the best algorithm?**
K-Means achieved:
- Highest Silhouette Score (0.337) — best cluster cohesion and separation
- Lowest Davies-Bouldin Index (1.010) — most compact and distinct clusters
- Highest Calinski-Harabasz Score (3,329) — best variance ratio

Additionally: excellent scalability (handles 4,338 customers efficiently), high interpretability for business stakeholders, and deterministic results with k-means++ initialisation.

**Q26. Why k=4?**
The elbow in the inertia curve and peak of the silhouette score both pointed to k=3 or k=4. k=4 was chosen because it produces business-meaningful segments (Champions, Potential Loyalists, At Risk, Lapsed) rather than overly broad groups. This aligns with common RFM segmentation practice.

**Q27. Describe the 4 customer segments.**
| Segment | Customers | Avg Recency | Avg Frequency | Avg Spend |
|---------|-----------|-------------|---------------|-----------|
| Champions | 716 (16.5%) | 12 days | 13.7 orders | £8,074 |
| Potential Loyalists | 837 (19.3%) | 18 days | 2.2 orders | £552 |
| At Risk | 1,173 (27.0%) | 71 days | 4.1 orders | £1,803 |
| Lapsed | 1,612 (37.2%) | 182 days | 1.3 orders | £343 |

**Q28. What marketing strategy do you recommend for each segment?**
- **Champions**: VIP loyalty rewards, early access to sales, ask for reviews and referrals
- **Potential Loyalists**: First repeat-purchase discount, personalised recommendations, enroll in loyalty programme
- **At Risk**: Win-back campaigns with discounts, remind of past purchases, survey to understand disengagement
- **Lapsed**: Re-engagement emails with strong incentives, show new products matching history, accept churn if cost too high

**Q29. What is PCA and why was it used for visualisation?**
Principal Component Analysis (PCA) reduces high-dimensional data to 2 dimensions by finding the directions (principal components) of maximum variance. Since RFM data is 3-dimensional, it was reduced to 2D to create scatter plots that humans can interpret. The two components explained approximately 85–90% of total variance.

---

### 1.6 Deployment

**Q30. What does the Streamlit app do?**
It has 3 pages:
1. **Dashboard**: Shows segment distribution (pie chart), average RFM per segment (bar charts), and the full customer table
2. **Predict Segment**: Takes Recency, Frequency, Monetary inputs → applies log1p → scales with scaler.pkl → predicts with kmeans_model.pkl → shows segment + marketing recommendations
3. **About**: Project methodology and algorithm comparison

**Q31. Why are two .pkl files needed?**
`kmeans_model.pkl` stores the trained model (cluster centroids). `scaler.pkl` stores the fitted StandardScaler (training mean and std). Both are needed in sequence for every prediction: new data must be scaled with the same scaler used during training before the model can make a valid prediction.

---

## PART 2: GENERAL MACHINE LEARNING CONCEPTS

---

### 2.1 Core Concepts

**Q32. What is the difference between supervised, unsupervised, and reinforcement learning?**
- **Supervised**: Model learns from labelled data (input → known output). Examples: classification, regression.
- **Unsupervised**: No labels; model finds hidden patterns or structure. Examples: clustering, dimensionality reduction.
- **Reinforcement Learning**: Agent learns by taking actions and receiving rewards/penalties. Examples: game-playing AI, robotics.

**Q33. What is the difference between classification and clustering?**
- **Classification** (supervised): Predicts a known category label for new data using a model trained on labelled examples (e.g., spam/not spam).
- **Clustering** (unsupervised): Groups data points by similarity with no predefined labels. Labels are discovered, not predicted.

**Q34. What is overfitting and underfitting?**
- **Overfitting**: Model memorises training data including noise; performs well on training set but poorly on new data. Caused by excessive model complexity.
- **Underfitting**: Model is too simple to capture the underlying patterns; performs poorly on both training and new data.
- In clustering: overfitting = too many clusters (every point is its own cluster); underfitting = too few clusters.

**Q35. What is the bias-variance tradeoff?**
- **Bias**: Error from wrong assumptions (underfitting — model too simple)
- **Variance**: Error from sensitivity to small fluctuations in training data (overfitting — model too complex)
- Tradeoff: decreasing bias tends to increase variance and vice versa. Goal is to find the sweet spot.

**Q36. What is cross-validation?**
A technique to evaluate model performance on unseen data by splitting data into k folds, training on k-1 folds, and testing on the remaining fold — repeated k times. Common variant: **k-fold cross-validation**. Not typically used for unsupervised clustering (no labels to validate against).

**Q37. What is the curse of dimensionality?**
As the number of features increases, the volume of the feature space grows exponentially, making data sparse. Distance-based algorithms (K-Means, KNN) lose effectiveness because all points appear equidistant. Solutions: feature selection, dimensionality reduction (PCA).

---

### 2.2 Algorithms

**Q38. What is logistic regression? When would you use it?**
A classification algorithm that models the probability of a binary outcome using the sigmoid function. Used when: output is binary (0/1), relationship between features and log-odds is linear, and interpretability matters. Not suitable for complex non-linear boundaries.

**Q39. What is a Decision Tree?**
A model that splits data recursively based on feature thresholds to maximise class purity (Gini impurity or entropy). Advantages: interpretable, handles non-linear data. Disadvantages: prone to overfitting (pruning or ensemble methods needed).

**Q40. What is Random Forest?**
An ensemble of decision trees where each tree is trained on a random bootstrap sample of data and a random subset of features. Final prediction is by majority vote (classification) or average (regression). Reduces variance compared to a single decision tree.

**Q41. What is gradient boosting? How does it differ from bagging?**
- **Bagging** (e.g., Random Forest): trains trees in parallel on random subsets; reduces variance
- **Boosting** (e.g., XGBoost, GBM): trains trees sequentially, each correcting errors of the previous; reduces both bias and variance. Generally more accurate but slower and more prone to overfitting.

**Q42. What is KNN (K-Nearest Neighbours)?**
A lazy learning algorithm (no training phase) that classifies a new point based on the majority class of its k nearest neighbours in feature space. Simple but slow at prediction (O(n) per query) and sensitive to feature scale and irrelevant features.

**Q43. What is SVM (Support Vector Machine)?**
Finds the hyperplane that maximises the margin between two classes. Points closest to the hyperplane are **support vectors**. Uses the **kernel trick** to handle non-linear boundaries (RBF, polynomial kernels). Effective in high-dimensional spaces.

---

### 2.3 Evaluation Metrics

**Q44. What is accuracy, and when is it misleading?**
Accuracy = (correct predictions) / (total predictions). Misleading on **imbalanced datasets** — if 95% of samples are class A, a model predicting only class A achieves 95% accuracy but is useless for detecting class B.

**Q45. Explain Precision, Recall, and F1 Score.**
- **Precision** = TP / (TP + FP) — of all predicted positives, how many are actually positive? (Minimise false alarms)
- **Recall** = TP / (TP + FN) — of all actual positives, how many did we catch? (Minimise misses)
- **F1 Score** = 2 × (Precision × Recall) / (Precision + Recall) — harmonic mean; balances both
- Use F1 when false positives and false negatives are both costly, especially on imbalanced datasets.

**Q46. What is the ROC curve and AUC?**
- **ROC curve**: plots True Positive Rate (Recall) vs False Positive Rate at various classification thresholds
- **AUC** (Area Under Curve): ranges 0 to 1. AUC = 0.5 means random; AUC = 1.0 means perfect classifier
- Useful for comparing classifiers independent of threshold choice.

**Q47. Why are F1, Precision, and Recall not used for clustering?**
These metrics require ground truth labels to compare against. In unsupervised clustering there are no predefined labels — the model is discovering labels. Cluster quality is instead measured by internal metrics (Silhouette, Davies-Bouldin, Calinski-Harabasz) that use only the data's own structure.

---

### 2.4 Feature Engineering & Data Processing

**Q48. What is feature engineering?**
The process of using domain knowledge to create, transform, or select features from raw data to improve model performance. In this project: converting raw transactions into RFM features was the core feature engineering step.

**Q49. What are the common ways to handle missing values?**
- **Drop rows**: when few rows are missing or the column is essential (e.g., CustomerID here)
- **Mean/Median imputation**: for numerical features with random missingness
- **Mode imputation**: for categorical features
- **Model-based imputation**: predict missing values using other features
- **Forward/backward fill**: for time series data

**Q50. What is the difference between normalisation and standardisation?**
- **Normalisation (Min-Max Scaling)**: scales values to [0, 1] range. Sensitive to outliers.
- **Standardisation (Z-score / StandardScaler)**: transforms to mean=0, std=1. Less sensitive to outliers, preferred for algorithms assuming Gaussian distribution or using Euclidean distance.

**Q51. What is one-hot encoding?**
Converts categorical variables into binary columns (one per category). E.g., Country = [UK, Germany, France] → three binary columns. Necessary because most ML algorithms work with numbers. Drawback: creates many columns for high-cardinality features (use target encoding or embedding instead).

**Q52. What is feature importance?**
A measure of how much each feature contributes to a model's predictions. In tree-based models: based on how much each feature reduces impurity across all splits. In clustering: features with higher variance and lower correlation tend to drive cluster formation.

---

### 2.5 Dimensionality Reduction

**Q53. What is PCA and how does it work?**
Principal Component Analysis finds orthogonal directions (principal components) of maximum variance in the data. Projects data onto the top k components, reducing dimensionality while retaining most information. Used for: visualisation, noise reduction, speeding up downstream algorithms.

**Q54. When would you use PCA vs feature selection?**
- **PCA**: when you want to reduce dimensions while keeping all original features' information (combines them into new components). Good for visualisation and when features are correlated.
- **Feature selection**: when you want to keep original interpretable features and remove irrelevant ones. Better when interpretability matters.

---

### 2.6 Model Training & Validation

**Q55. What is a train-test split and why is it needed?**
Divides data into a training set (to fit the model) and a test set (to evaluate on unseen data). Prevents evaluating the model on data it was trained on, which would give overly optimistic performance estimates.

**Q56. What is hyperparameter tuning?**
The process of finding the best configuration settings for a model (e.g., k in K-Means, eps in DBSCAN, learning rate in gradient boosting). Common methods: Grid Search, Random Search, Bayesian Optimisation.

**Q57. What is regularisation?**
Technique to reduce overfitting by penalising model complexity:
- **L1 (Lasso)**: adds absolute value of coefficients to loss; drives some to zero (feature selection)
- **L2 (Ridge)**: adds squared coefficients to loss; shrinks all coefficients but rarely to zero
- **ElasticNet**: combination of L1 and L2

---

### 2.7 Deep Learning Basics

**Q58. What is a neural network?**
A computational model inspired by the brain, consisting of layers of interconnected nodes (neurons). Input layer → hidden layers → output layer. Each connection has a weight; activation functions (ReLU, sigmoid) introduce non-linearity. Learns by backpropagation and gradient descent.

**Q59. What is the difference between machine learning and deep learning?**
- **ML**: algorithms that learn patterns from structured/tabular data with manual feature engineering (Decision Trees, SVM, K-Means)
- **Deep Learning**: subset of ML using multi-layer neural networks that can automatically learn hierarchical features from raw data (images, text, audio). Requires much more data and compute.

**Q60. What is transfer learning?**
Using a model pre-trained on a large dataset as a starting point for a new task. E.g., using a pre-trained image recognition model (trained on ImageNet) and fine-tuning it for medical image classification with a small dataset. Saves time and data.

---

### 2.8 Practical/Scenario Questions

**Q61. If your model performs well on training data but poorly on test data, what do you do?**
This is overfitting. Solutions: increase training data, add regularisation, reduce model complexity, use dropout (neural nets), use cross-validation, apply feature selection to remove noise features.

**Q62. How would you handle a highly imbalanced dataset?**
- Resample: oversample minority class (SMOTE) or undersample majority class
- Use class weights in model (class_weight='balanced')
- Use appropriate metrics: F1, AUC-ROC instead of accuracy
- Use algorithms robust to imbalance (tree-based methods)

**Q63. A client asks: "How do we know the segments are real and not random?"**
Run the silhouette analysis — if scores are consistently high (> 0.3), clusters are genuine. Compare against a random baseline. Validate business intuition: do the segments make sense? Run A/B tests: send different marketing to each segment and measure response rate differences.

**Q64. How would you deploy this model in production?**
1. Serialize model and scaler with joblib (done)
2. Build a REST API (Flask/FastAPI) or Streamlit app (done) to serve predictions
3. Input new customer data → preprocess → predict segment → return result
4. Schedule periodic model retraining (e.g., monthly) as customer behavior evolves
5. Monitor for data drift: if incoming RFM distributions shift significantly, retrain

**Q65. How would you improve this project further?**
1. Add a supervised classifier (Random Forest) trained on the cluster labels to predict segments for new customers with fewer transactions
2. Incorporate more features: product categories, time of day, device type, geographic region
3. Use time-series clustering to track how customers move between segments over time
4. Build a recommendation system on top of the segmentation
5. Apply NLP on product descriptions to add product affinity as a feature

---

*End of Q&A Guide — 65 Questions*
