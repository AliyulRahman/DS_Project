# Project Files Guide & Web Application User Manual

---

## PART 1 — OUTPUT FILES: PURPOSE & DESCRIPTION

---

### Source Files (Input)

| File | Purpose |
|------|---------|
| `data.csv` | Raw e-commerce transaction dataset. Source of all analysis. Do not modify. |
| `Data_columns_description.txt` | Column-by-column description of data.csv fields. Reference document. |
| `Project_Description.txt` | Original project brief with objectives, deliverables, and guidelines. |

---

### Submission Deliverables

#### `Customer_Segmentation_Analysis.ipynb`
The main Jupyter notebook for submission. Contains the complete data science workflow in 42 cells:
- Data loading and initial exploration
- Data cleaning and preprocessing steps
- Exploratory Data Analysis with charts
- RFM feature engineering
- Feature scaling (log transform + StandardScaler)
- Optimal cluster selection (Elbow, Silhouette, Davies-Bouldin, Calinski-Harabasz)
- Four clustering algorithms: K-Means, Hierarchical, DBSCAN, GMM
- Algorithm comparison and winner selection
- Customer segment profiling and business recommendations
- Model saving

Open in Jupyter Notebook or VS Code and run all cells top to bottom.

---

#### `Customer_Segmentation_Presentation.pptx`
10-slide PowerPoint presentation for the final submission report. Covers:
- Project benefits and business value
- RFM analysis explanation
- Data preprocessing pipeline
- All four algorithms compared
- Why K-Means was selected
- Customer segment profiles with marketing strategies
- How the model meets business expectations
- Streamlit app and vibe coding explanation
- Future improvement roadmap

---

#### `Project_QA_Guide.md`
65-question Q&A reference document covering both project-specific questions and general machine learning concepts. Useful for viva preparation, presentations, or written reports. Organised into two parts:
- Part 1: Project-specific questions (dataset, RFM, algorithms, results, deployment)
- Part 2: General ML concepts (supervised vs unsupervised, evaluation metrics, algorithms, feature engineering)

---

### Model Artifacts (Required by App)

#### `kmeans_model.pkl`
The trained K-Means clustering model saved using joblib. Stores the four cluster centroids learned from customer RFM data. Used by the Streamlit app to predict which segment a new customer belongs to. **Do not delete — the app will not run without this file.**

#### `scaler.pkl`
The fitted StandardScaler saved using joblib. Stores the mean and standard deviation calculated from training data. Every prediction must pass through this scaler first to ensure the input is on the same scale as the training data. **Do not delete — required alongside kmeans_model.pkl.**

---

### Data Outputs

#### `rfm_customers.csv`
Customer-level dataset with 4,338 rows. Each row is one unique customer with their computed RFM values and assigned segment. Columns:

| Column | Description |
|--------|-------------|
| CustomerID | Unique customer identifier |
| Recency | Days since last purchase |
| Frequency | Number of unique orders placed |
| Monetary | Total spend across all orders (£) |
| Cluster | Numeric cluster label (0–3) assigned by K-Means |
| Segment | Human-readable segment name (Champions, Potential Loyalists, At Risk, Lapsed) |

Used by the Streamlit app Dashboard page to display charts and the customer table.

#### `cluster_profiles.csv`
Summary statistics for each of the four customer segments. Contains average and median Recency, Frequency, and Monetary values per cluster, plus the segment name. Used by the Streamlit app to build dynamic segment descriptions and the cluster profile table.

---

### Charts Folder (`charts/`)

All 15 PNG charts generated during analysis. Useful for inserting into reports or presentations.

| File | What it shows |
|------|--------------|
| `eda_countries.png` | Top countries by revenue and order count |
| `eda_monthly.png` | Monthly revenue and order trends over time |
| `rfm_distributions.png` | Histogram distributions of Recency, Frequency, Monetary |
| `optimal_k.png` | Elbow, Silhouette, Davies-Bouldin, and Calinski-Harabasz plots for k=2 to 10 |
| `kmeans_clusters.png` | K-Means cluster scatter plot (PCA 2D) and cluster size bar chart |
| `kmeans_silhouette.png` | Silhouette plot showing cohesion of each K-Means cluster |
| `hierarchical_dendrogram.png` | Ward linkage dendrogram on a 200-customer sample |
| `hierarchical_clusters.png` | Hierarchical clustering PCA scatter and size chart |
| `dbscan_kdistance.png` | K-distance plot used to select DBSCAN epsilon parameter |
| `dbscan_clusters.png` | DBSCAN clusters and noise points visualised in PCA space |
| `gmm_selection.png` | BIC and AIC scores for GMM component selection (k=2 to 8) |
| `gmm_clusters.png` | GMM cluster assignments and confidence probability heatmap |
| `algorithm_comparison.png` | Side-by-side bar chart comparing all four algorithms on three metrics |
| `segment_rfm_scores.png` | Normalised RFM scores per segment for easy comparison |
| `final_dashboard.png` | Four-panel summary: segment distribution, avg spend, frequency, recency |

---

### Script Files (Not Required for Submission)

| File | Purpose |
|------|---------|
| `run_analysis.py` | The Python script that was executed to produce all model artifacts, CSVs, and chart PNGs. Re-run only if you need to regenerate everything from scratch. |
| `create_notebook.py` | Script that generated `Customer_Segmentation_Analysis.ipynb` using nbformat. |
| `create_ppt.py` | Script that generated `Customer_Segmentation_Presentation.pptx` using python-pptx. |

---

---

## PART 2 — WEB APPLICATION USER GUIDE

---

### Overview

The Streamlit app (`app.py`) is a self-contained interactive tool that lets any user — without coding knowledge — explore the customer segments and predict the segment for any customer based on their purchasing behaviour.

---

### How to Launch

Open a terminal in the project folder and run:

```
python -m streamlit run app.py
```

The app opens automatically in your browser at `http://localhost:8501`

The model and data files (`kmeans_model.pkl`, `scaler.pkl`, `rfm_customers.csv`, `cluster_profiles.csv`) must be in the same folder as `app.py`.

---

### Navigation

The app has three pages accessible from the **left sidebar**:

- **Dashboard** — View existing customer segments and statistics
- **Predict Segment** — Predict the segment for a new or existing customer
- **About** — Project methodology and reference information

The sidebar also shows the current model status (green tick = loaded successfully).

---

### Page 1: Dashboard

**What it shows:** A full overview of all 4,338 segmented customers.

**Top metrics row:**
Four KPI cards displayed at the top:
- Total Customers in the dataset
- Average Recency (days since last purchase across all customers)
- Average Frequency (average number of orders per customer)
- Average Monetary Value (average total spend per customer in £)

**Segment Distribution (pie chart + bar chart):**
- Pie chart shows what percentage of customers fall into each segment
- Horizontal bar chart shows the raw count per segment
- Both charts are interactive — hover over any section to see exact numbers

**Average RFM Values by Segment (three bar charts):**
- Left chart: Average Recency per segment (lower days = more engaged)
- Middle chart: Average Frequency per segment (higher = more loyal)
- Right chart: Average Monetary value per segment (higher = more valuable)
- Use these to understand how each segment differs from the others

**Cluster Profile Summary (table):**
A summary table showing the average Recency, Frequency, and Monetary for each cluster alongside the segment name and customer count.

**Customer RFM Data (full table):**
- Shows every customer's individual RFM values and their assigned segment
- Use the dropdown to filter by a specific segment
- Useful for exporting specific segments for marketing campaigns

---

### Page 2: Predict Segment

**What it does:** Takes a customer's three RFM values and predicts which segment they belong to.

#### Single Customer Prediction

Three sliders in the left panel:
- **Recency**: Set the number of days since the customer's last purchase (1 to 400)
- **Frequency**: Set the number of orders the customer has placed (1 to 100)
- **Monetary**: Set the customer's total spend in pounds (£1 to £50,000)

Click the **Predict Segment** button. The result panel on the right shows:
- The predicted segment name (e.g., Champions)
- A brief description of what that segment means
- A list of recommended marketing actions tailored to that segment

**Example:**
- Recency = 10 days, Frequency = 15 orders, Monetary = £9,000 → **Champions**
  - Reward with VIP loyalty benefits, offer early access to sales
- Recency = 200 days, Frequency = 1 order, Monetary = £300 → **Lapsed**
  - Launch aggressive win-back campaign, offer significant discount

#### Batch Prediction (Multiple Customers)

To predict segments for many customers at once:

1. Prepare a CSV file with three columns: `Recency`, `Frequency`, `Monetary`
2. Use the **Upload CSV for Batch Prediction** file uploader
3. The app will predict the segment for every row
4. A preview table appears showing the input values alongside the predicted segment
5. Click **Download Predictions** to save the results as a CSV

**CSV format example:**
```
Recency,Frequency,Monetary
10,15,9000
200,1,300
45,4,1800
```

---

### Page 3: About

**What it contains:**
- Project overview and objectives
- Explanation of RFM analysis and why it is used
- Summary of all four clustering algorithms tested
- Algorithm comparison table (Silhouette, Davies-Bouldin, Calinski-Harabasz scores)
- Explanation of why K-Means was selected as the best algorithm
- Segment descriptions and characteristics

Use this page as a reference when presenting the project or explaining the methodology.

---

### Understanding the Segments

| Segment | Behaviour | Priority |
|---------|-----------|----------|
| **Champions** | Purchased very recently, very frequently, highest spenders | Protect and reward — highest value |
| **Potential Loyalists** | Recently active but infrequent buyers with moderate spend | Nurture — encourage repeat purchases |
| **At Risk** | Used to buy regularly but haven't purchased recently | Act fast — win-back before full churn |
| **Lapsed** | Have not purchased for a long time, low frequency, low spend | Re-engage or accept churn |

---

### Troubleshooting

| Problem | Solution |
|---------|----------|
| App does not open | Ensure `python -m streamlit run app.py` is run from the project folder |
| "Model not loaded" error in sidebar | Check that `kmeans_model.pkl` and `scaler.pkl` are in the same folder as `app.py` |
| Dashboard shows no data | Check that `rfm_customers.csv` and `cluster_profiles.csv` are present |
| Batch upload fails | Ensure the CSV has exactly three columns named `Recency`, `Frequency`, `Monetary` |
| Port 8501 already in use | Run with a different port: `python -m streamlit run app.py --server.port 8502` |
