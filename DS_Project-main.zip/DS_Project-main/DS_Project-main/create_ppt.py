from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt
import copy

# ── Colour palette ────────────────────────────────────────────────────────────
DARK_BG    = RGBColor(0x0D, 0x1B, 0x2A)   # deep navy
ACCENT1    = RGBColor(0x00, 0xB4, 0xD8)   # cyan-blue
ACCENT2    = RGBColor(0xFF, 0x6B, 0x6B)   # coral-red
ACCENT3    = RGBColor(0x4E, 0xCD, 0xC4)   # teal
ACCENT4    = RGBColor(0x96, 0xCE, 0xB4)   # sage-green
WHITE      = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GREY = RGBColor(0xCC, 0xD6, 0xE0)
YELLOW     = RGBColor(0xFF, 0xD1, 0x66)

prs = Presentation()
prs.slide_width  = Inches(13.33)
prs.slide_height = Inches(7.5)

BLANK = prs.slide_layouts[6]   # completely blank

# ── Helpers ───────────────────────────────────────────────────────────────────
def add_rect(slide, l, t, w, h, fill, alpha=None):
    shape = slide.shapes.add_shape(1, Inches(l), Inches(t), Inches(w), Inches(h))
    shape.line.fill.background()
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    return shape

def add_text(slide, text, l, t, w, h, size, bold=False, color=WHITE,
             align=PP_ALIGN.LEFT, italic=False, wrap=True):
    txb = slide.shapes.add_textbox(Inches(l), Inches(t), Inches(w), Inches(h))
    txb.word_wrap = wrap
    tf = txb.text_frame
    tf.word_wrap = wrap
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return txb

def add_para(tf, text, size, bold=False, color=WHITE, align=PP_ALIGN.LEFT,
             space_before=6, italic=False):
    p = tf.add_paragraph()
    p.alignment = align
    p.space_before = Pt(space_before)
    run = p.add_run()
    run.text = text
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return p

def bg(slide):
    add_rect(slide, 0, 0, 13.33, 7.5, DARK_BG)

def accent_bar(slide, color=ACCENT1, height=0.07):
    add_rect(slide, 0, 0, 13.33, height, color)
    add_rect(slide, 0, 7.5 - height, 13.33, height, color)

def slide_title(slide, title, subtitle=None, color=ACCENT1):
    add_text(slide, title, 0.45, 0.18, 12.4, 0.7, 28, bold=True, color=color)
    if subtitle:
        add_text(slide, subtitle, 0.45, 0.82, 12.4, 0.4, 14, color=LIGHT_GREY)
    add_rect(slide, 0.45, 1.18, 12.4, 0.04, color)

def card(slide, l, t, w, h, fill=RGBColor(0x14, 0x2A, 0x3F), radius=False):
    r = add_rect(slide, l, t, w, h, fill)
    return r

# =============================================================================
# SLIDE 1 — TITLE
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl)
add_rect(sl, 0, 0, 13.33, 7.5, DARK_BG)
# gradient accent strip
add_rect(sl, 0, 0, 13.33, 0.12, ACCENT1)
add_rect(sl, 0, 7.38, 13.33, 0.12, ACCENT1)
# decorative side bar
add_rect(sl, 0, 0, 0.18, 7.5, ACCENT1)

# big title
txb = sl.shapes.add_textbox(Inches(0.55), Inches(1.6), Inches(12.2), Inches(1.5))
txb.word_wrap = True
tf = txb.text_frame; tf.word_wrap = True
p = tf.paragraphs[0]; p.alignment = PP_ALIGN.LEFT
r = p.add_run(); r.text = "E-Commerce Customer"
r.font.size = Pt(48); r.font.bold = True; r.font.color.rgb = WHITE

add_para(tf, "Segmentation & Prediction", 48, bold=True, color=ACCENT1, space_before=2)
add_para(tf, "Using RFM Analysis & Machine Learning", 20, color=LIGHT_GREY, space_before=14)

add_rect(sl, 0.55, 3.65, 4.5, 0.05, ACCENT1)

add_text(sl, "Algorithms: K-Means  |  Hierarchical  |  DBSCAN  |  GMM",
         0.55, 3.85, 11.0, 0.45, 14, color=LIGHT_GREY)
add_text(sl, "Best Model: K-Means (k=4)   |   4,338 Customers Segmented",
         0.55, 4.25, 11.0, 0.45, 14, color=ACCENT3)

# bottom badges
for i, (lbl, col) in enumerate([("4 Segments", ACCENT2),
                                  ("4,338 Customers", ACCENT3),
                                  ("4 Algorithms Compared", ACCENT1),
                                  ("Streamlit App Deployed", YELLOW)]):
    x = 0.55 + i * 3.18
    card(sl, x, 5.6, 2.95, 0.8, fill=col)
    add_text(sl, lbl, x + 0.12, 5.72, 2.75, 0.56, 13, bold=True, color=DARK_BG,
             align=PP_ALIGN.CENTER)

# =============================================================================
# SLIDE 2 — PROJECT BENEFITS
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT2)
slide_title(sl, "Project Benefits", "Why does this project matter to the business?", ACCENT2)

benefits = [
    ("🎯", "Targeted Marketing",
     "Identify high-value customers (Champions) and focus ad spend on them, reducing wasted budget on low-engagement segments."),
    ("💰", "Revenue Optimisation",
     "Champions (16.5% of customers) generate disproportionately high revenue (avg £8,074 spend). Retaining them maximises ROI."),
    ("🔄", "Customer Retention",
     "Early detection of At-Risk customers (27%) allows timely win-back campaigns before they churn completely."),
    ("📦", "Inventory Management",
     "Purchase frequency and product patterns per segment guide smarter stock planning and demand forecasting."),
    ("😊", "Customer Satisfaction",
     "Personalised offers and communications tailored to each segment improve customer experience and brand loyalty."),
    ("📊", "Data-Driven Decisions",
     "Replaces guesswork with evidence-based segmentation; every marketing decision is backed by purchasing behaviour data."),
]

cols = [(0.35, 1.45), (4.6, 1.45), (8.85, 1.45),
        (0.35, 4.1),  (4.6, 4.1),  (8.85, 4.1)]

for (l, t), (icon, title, desc) in zip(cols, benefits):
    card(sl, l, t, 3.95, 2.4, fill=RGBColor(0x14, 0x28, 0x3E))
    add_text(sl, icon + "  " + title, l + 0.18, t + 0.18, 3.6, 0.5,
             13, bold=True, color=ACCENT1)
    add_rect(sl, l + 0.18, t + 0.62, 3.58, 0.03, ACCENT1)
    add_text(sl, desc, l + 0.18, t + 0.72, 3.6, 1.5, 11, color=LIGHT_GREY, wrap=True)

# =============================================================================
# SLIDE 3 — WHAT IS RFM?
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT3)
slide_title(sl, "RFM Analysis — Feature Engineering", "Converting raw transactions into customer behaviour metrics", ACCENT3)

# three big cards
rfm_data = [
    (ACCENT2,  "R",  "Recency",   "Days since last purchase",
     ["Lower = More Engaged", "Ref. date: 10 Dec 2011", "Range: 1 – 374 days", "Avg: 93 days"]),
    (ACCENT1,  "F",  "Frequency", "Number of unique orders placed",
     ["Higher = More Loyal", "Counted as unique InvoiceNo", "Range: 1 – 209 orders", "Avg: 4.3 orders"]),
    (ACCENT3,  "M",  "Monetary",  "Total spend across all orders",
     ["Higher = More Valuable", "Sum of Qty × UnitPrice", "Range: £3 – £280k", "Avg: £2,061"]),
]

for i, (color, letter, name, tagline, bullets) in enumerate(rfm_data):
    x = 0.35 + i * 4.32
    card(sl, x, 1.45, 4.1, 5.7, fill=RGBColor(0x0A, 0x22, 0x36))
    # big letter
    add_text(sl, letter, x + 0.18, 1.55, 1.1, 1.1, 64, bold=True, color=color,
             align=PP_ALIGN.CENTER)
    add_text(sl, name, x + 1.2, 1.62, 2.8, 0.5, 20, bold=True, color=WHITE)
    add_text(sl, tagline, x + 1.2, 2.08, 2.8, 0.45, 11, color=LIGHT_GREY, italic=True)
    add_rect(sl, x + 0.18, 2.55, 3.74, 0.04, color)
    for j, b in enumerate(bullets):
        add_text(sl, "▸  " + b, x + 0.28, 2.7 + j * 0.52, 3.55, 0.48, 11.5, color=LIGHT_GREY)

# bottom formula
add_rect(sl, 1.0, 7.0, 11.3, 0.38, RGBColor(0x1A, 0x35, 0x50))
add_text(sl,
         "Preprocessing:  log1p( R, F, M )  →  StandardScaler( mean=0, std=1 )  →  Clustering Input",
         1.1, 7.02, 11.1, 0.35, 11.5, color=YELLOW, align=PP_ALIGN.CENTER)

# =============================================================================
# SLIDE 4 — DATA PREPROCESSING
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT1)
slide_title(sl, "Data Preprocessing Pipeline", "From raw transactions to model-ready RFM features", ACCENT1)

steps = [
    ("RAW DATA",  "Online Retail Dataset\n8 columns",              ACCENT2),
    ("STEP 1",    "Remove cancelled orders\n(InvoiceNo with 'C')", ACCENT1),
    ("STEP 2",    "Drop rows with\nmissing CustomerID",            ACCENT1),
    ("STEP 3",    "Remove invalid\nQty or UnitPrice",              ACCENT1),
    ("STEP 4",    "Add TotalAmount\n= Qty × UnitPrice",            ACCENT3),
    ("STEP 5",    "Compute RFM\nper customer",                     ACCENT3),
    ("STEP 6",    "log1p transform\n+ StandardScaler",             ACCENT3),
    ("READY",     "Customers segmented\n3 scaled features",        YELLOW),
]

arrow_col = RGBColor(0x33, 0x55, 0x70)
box_w = 1.42
gap   = 0.06
start = 0.28

for i, (label, detail, col) in enumerate(steps):
    x = start + i * (box_w + gap)
    card(sl, x, 1.5, box_w, 2.6, fill=RGBColor(0x10, 0x25, 0x3A))
    add_rect(sl, x, 1.5, box_w, 0.38, col)
    add_text(sl, label, x + 0.05, 1.52, box_w - 0.1, 0.34,
             9.5, bold=True, color=DARK_BG, align=PP_ALIGN.CENTER)
    add_text(sl, detail, x + 0.08, 1.96, box_w - 0.16, 2.06,
             9.5, color=LIGHT_GREY, align=PP_ALIGN.CENTER, wrap=True)
    if i < len(steps) - 1:
        ax = x + box_w + 0.01
        add_text(sl, "▶", ax, 2.5, 0.09, 0.5, 11, color=arrow_col, align=PP_ALIGN.CENTER)

# =============================================================================
# SLIDE 5 — ALGORITHMS COMPARED
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT2)
slide_title(sl, "Clustering Algorithms Compared", "Four algorithms evaluated on the same RFM feature set", ACCENT2)

algos = [
    (ACCENT1,  "K-Means",        "Partition-based",
     ["Assigns each point to nearest centroid",
      "k-means++ smart initialisation",
      "Fast: O(nkI) complexity",
      "Best for spherical, similar-sized clusters"],
     "k = 4  |  n_init = 10  |  random_state = 42"),
    (ACCENT3,  "Hierarchical\n(Agglomerative)", "Linkage-based",
     ["Merges closest clusters bottom-up",
      "Ward linkage minimises variance",
      "Dendrogram visualises merges",
      "Slow: O(n³) — not scalable"],
     "linkage = Ward  |  k = 4"),
    (ACCENT2,  "DBSCAN",         "Density-based",
     ["Groups dense regions; labels sparse as noise",
      "No k required — discovers automatically",
      "Found only 2 clusters + 62 noise pts",
      "Poor fit for RFM spherical structure"],
     "eps = 0.5  |  min_samples = 5"),
    (YELLOW,   "GMM",            "Probabilistic",
     ["Soft assignment — probability per cluster",
      "Assumes Gaussian-shaped clusters",
      "BIC/AIC for component selection",
      "Lowest Silhouette (0.173) here"],
     "n_components = 4  |  full covariance"),
]

for i, (col, name, algo_type, bullets, params) in enumerate(algos):
    x = 0.3 + i * 3.23
    card(sl, x, 1.45, 3.05, 5.7, fill=RGBColor(0x0E, 0x22, 0x35))
    add_rect(sl, x, 1.45, 3.05, 0.42, col)
    add_text(sl, name, x + 0.1, 1.47, 2.85, 0.38, 13, bold=True,
             color=DARK_BG, align=PP_ALIGN.CENTER)
    add_text(sl, algo_type, x + 0.1, 1.88, 2.85, 0.35, 10,
             color=col, italic=True)
    for j, b in enumerate(bullets):
        add_text(sl, "• " + b, x + 0.12, 2.28 + j * 0.52, 2.82, 0.48, 10, color=LIGHT_GREY)
    add_rect(sl, x + 0.12, 4.42, 2.82, 0.03, col)
    add_text(sl, params, x + 0.12, 4.52, 2.82, 0.55, 9.5, color=col, italic=True)

# =============================================================================
# SLIDE 6 — WHY K-MEANS WON
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT1)
slide_title(sl, "Best Algorithm: K-Means (k=4)", "Quantitative metrics + qualitative reasoning", ACCENT1)

# metrics table
headers = ["Algorithm", "Silhouette ↑", "Davies-Bouldin ↓", "Calinski-Harabasz ↑", "Scalable?", "Interpretable?"]
rows = [
    ("K-Means",      "0.337 ★", "1.010 ★", "3,329 ★", "Yes ✓", "High ✓"),
    ("Hierarchical", "0.330",   "1.045",   "3,186",   "No ✗",  "High ✓"),
    ("DBSCAN",       "0.089",   "—",       "—",       "Med",   "Low"),
    ("GMM",          "0.173",   "1.241",   "2,814",   "Med",   "Low"),
]

col_widths = [2.2, 1.7, 2.05, 2.35, 1.35, 1.65]
col_starts = [0.3]
for w in col_widths[:-1]:
    col_starts.append(col_starts[-1] + w)

row_h = 0.48
header_y = 1.42

# header row
add_rect(sl, 0.3, header_y, 11.73, row_h, ACCENT1)
for j, (hdr, cw, cx) in enumerate(zip(headers, col_widths, col_starts)):
    add_text(sl, hdr, cx + 0.08, header_y + 0.08, cw - 0.16, row_h - 0.1,
             11, bold=True, color=DARK_BG, align=PP_ALIGN.CENTER)

for i, row in enumerate(rows):
    y = header_y + (i + 1) * row_h
    row_bg = RGBColor(0x08, 0x1E, 0x32) if i % 2 == 0 else RGBColor(0x10, 0x28, 0x3E)
    if i == 0:
        row_bg = RGBColor(0x00, 0x3D, 0x56)   # highlight winner
    add_rect(sl, 0.3, y, 11.73, row_h, row_bg)
    for j, (val, cw, cx) in enumerate(zip(row, col_widths, col_starts)):
        txt_col = YELLOW if (i == 0 and "★" in val) else (ACCENT3 if i == 0 else WHITE)
        add_text(sl, val, cx + 0.08, y + 0.08, cw - 0.16, row_h - 0.1,
                 11, color=txt_col, align=PP_ALIGN.CENTER,
                 bold=(i == 0))

# reasons below
reasons = [
    ("Highest Silhouette Score",   "0.337 — compact, well-separated clusters"),
    ("Lowest Davies-Bouldin",      "1.010 — most distinct cluster boundaries"),
    ("Highest Calinski-Harabasz",  "3,329 — best between/within variance ratio"),
    ("O(nkI) Scalability",         "Handles thousands of customers efficiently"),
    ("Business Interpretability",  "Clear centroid profiles map to marketing actions"),
]

for i, (title, detail) in enumerate(reasons):
    x = 0.3 + (i % 3) * 4.0
    y = 4.32 + (i // 3) * 0.9
    card(sl, x, y, 3.75, 0.78, fill=RGBColor(0x10, 0x28, 0x3E))
    add_rect(sl, x, y, 0.06, 0.78, ACCENT1)
    add_text(sl, title, x + 0.2, y + 0.06, 3.45, 0.35, 11, bold=True, color=ACCENT1)
    add_text(sl, detail, x + 0.2, y + 0.38, 3.45, 0.35, 10, color=LIGHT_GREY)

# =============================================================================
# SLIDE 7 — CUSTOMER SEGMENTS
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT3)
slide_title(sl, "Customer Segments Discovered", "K-Means (k=4) identified four actionable groups", ACCENT3)

segments = [
    (ACCENT2,  "Champions",           "716",  "16.5%",
     "12 days", "13.7 orders", "£8,074",
     ["Reward with VIP loyalty benefits",
      "Early access to new products & sales",
      "Request reviews & referrals"]),
    (ACCENT1,  "Potential Loyalists", "837",  "19.3%",
     "18 days", "2.2 orders",  "£552",
     ["Send welcome email series",
      "Offer first repeat-purchase discount",
      "Enroll in loyalty programme"]),
    (YELLOW,   "At Risk",             "1,173","27.0%",
     "71 days", "4.1 orders",  "£1,803",
     ["Win-back campaigns with discounts",
      "Remind of past purchase history",
      "Survey to find disengagement reason"]),
    (ACCENT3,  "Lapsed",              "1,612","37.2%",
     "182 days","1.3 orders",  "£343",
     ["Strong re-engagement incentives",
      "Show new products matching history",
      "Accept churn if cost too high"]),
]

for i, (col, name, count, pct, rec, freq, mon, actions) in enumerate(segments):
    x = 0.28 + i * 3.23
    card(sl, x, 1.45, 3.05, 5.72, fill=RGBColor(0x0E, 0x22, 0x35))
    add_rect(sl, x, 1.45, 3.05, 0.42, col)
    add_text(sl, name, x + 0.1, 1.47, 2.85, 0.38, 13, bold=True,
             color=DARK_BG, align=PP_ALIGN.CENTER)
    add_text(sl, count + " customers (" + pct + ")", x + 0.1, 1.92, 2.85, 0.35,
             11, color=col, align=PP_ALIGN.CENTER)
    rfm_items = [("Recency", rec), ("Frequency", freq), ("Monetary", mon)]
    for j, (lbl, val) in enumerate(rfm_items):
        y = 2.38 + j * 0.5
        add_text(sl, lbl + ":", x + 0.15, y, 1.2, 0.42, 10, color=LIGHT_GREY)
        add_text(sl, val,       x + 1.3,  y, 1.6, 0.42, 10.5, bold=True, color=WHITE)
    add_rect(sl, x + 0.15, 3.92, 2.75, 0.03, col)
    add_text(sl, "Strategy:", x + 0.15, 4.0, 2.75, 0.32, 10, bold=True, color=col)
    for j, a in enumerate(actions):
        add_text(sl, "▸ " + a, x + 0.15, 4.34 + j * 0.42, 2.75, 0.38, 9.5, color=LIGHT_GREY)

# =============================================================================
# SLIDE 8 — HOW THE MODEL MEETS PROJECT EXPECTATIONS
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT2)
slide_title(sl, "How This Model Meets Business Expectations",
            "Translating data science output into measurable business value", ACCENT2)

# left — business expectations
card(sl, 0.3, 1.45, 6.0, 5.72, fill=RGBColor(0x0A, 0x20, 0x34))
add_text(sl, "Business Goals Achieved", 0.45, 1.52, 5.7, 0.45, 15, bold=True, color=ACCENT2)
add_rect(sl, 0.45, 1.93, 5.7, 0.04, ACCENT2)
expectations = [
    ("Know Your Customer",
     "4 distinct customer groups uncovered from real purchasing data — "
     "no guesswork, every decision backed by behaviour."),
    ("Targeted Marketing Campaigns",
     "Each segment receives a tailored strategy: VIP rewards for Champions, "
     "win-back offers for At Risk, onboarding nudges for Potential Loyalists."),
    ("Protect Revenue — Retain Champions",
     "Top 16.5% of customers (Champions) average £8,074 spend. "
     "Identifying them enables proactive retention before they disengage."),
    ("Reduce Churn — Act on At Risk Early",
     "27% of customers show declining engagement. Early detection allows "
     "timely intervention before they become fully Lapsed."),
    ("Optimise Marketing Budget",
     "Focus ad spend on high-value segments; reduce wastage on "
     "Lapsed customers with low return probability."),
    ("Scalable Self-Service Tool",
     "Marketing team can predict any new customer's segment instantly "
     "via the Streamlit app — no data science expertise required."),
]
for j, (title, detail) in enumerate(expectations):
    y = 2.08 + j * 0.8
    add_rect(sl, 0.45, y, 0.06, 0.62, ACCENT2)
    add_text(sl, title,  0.62, y,        5.45, 0.28, 11, bold=True,  color=WHITE)
    add_text(sl, detail, 0.62, y + 0.3,  5.45, 0.44, 10, color=LIGHT_GREY, wrap=True)

# right — prediction pipeline
card(sl, 6.65, 1.45, 6.35, 5.72, fill=RGBColor(0x0A, 0x20, 0x34))
add_text(sl, "Prediction Pipeline", 6.82, 1.52, 6.0, 0.45, 15, bold=True, color=ACCENT1)
add_rect(sl, 6.82, 1.93, 6.0, 0.04, ACCENT1)

pipeline = [
    (ACCENT2,  "INPUT",    "Customer: Recency, Frequency, Monetary values"),
    (ACCENT1,  "STEP 1",   "Apply log1p( ) transformation to reduce skewness"),
    (ACCENT3,  "STEP 2",   "StandardScaler.transform( ) — loaded from scaler.pkl"),
    (YELLOW,   "STEP 3",   "KMeans.predict( ) — loaded from kmeans_model.pkl"),
    (ACCENT2,  "OUTPUT",   "Segment label: Champions / Potential Loyalists / At Risk / Lapsed"),
    (ACCENT3,  "ACTION",   "Display marketing strategy tailored to that segment"),
]
for j, (col, stage, desc) in enumerate(pipeline):
    y = 2.1 + j * 0.84
    add_rect(sl, 6.82, y, 1.0, 0.42, col)
    add_text(sl, stage, 6.82, y + 0.06, 1.0, 0.3,
             9.5, bold=True, color=DARK_BG, align=PP_ALIGN.CENTER)
    add_text(sl, desc, 7.9, y + 0.06, 4.9, 0.6, 10.5, color=LIGHT_GREY)
    if j < len(pipeline) - 1:
        add_text(sl, "↓", 7.2, y + 0.44, 0.5, 0.38, 13, color=col, align=PP_ALIGN.CENTER)

# =============================================================================
# SLIDE 9 — VIBE CODING & STREAMLIT APP
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, YELLOW)
slide_title(sl, "Streamlit App — Built with Vibe Coding",
            "AI-assisted development: describing intent, not writing every line", YELLOW)

# left: what is vibe coding
card(sl, 0.3, 1.45, 5.9, 5.72, fill=RGBColor(0x0A, 0x20, 0x34))
add_text(sl, "What is Vibe Coding?", 0.45, 1.55, 5.6, 0.42, 14, bold=True, color=YELLOW)
add_rect(sl, 0.45, 1.93, 5.6, 0.04, YELLOW)

vibe_points = [
    ("Natural Language Driven",
     "The app was described in plain English: 'show a pie chart of segment distribution', "
     "'add sliders for R, F, M inputs, predict the segment on button click'."),
    ("AI Writes the Code",
     "Claude (the AI) translated each description into working Python + Streamlit code — "
     "no manual syntax lookup or boilerplate needed."),
    ("Iterative Refinement",
     "Output was reviewed, feedback given ('add batch prediction upload', "
     "'make segment names dynamic from CSV'), and AI revised instantly."),
    ("Speed Advantage",
     "A full 3-page Streamlit app with Plotly charts, model loading, and batch CSV "
     "prediction was produced in minutes, not hours."),
]
for j, (title, detail) in enumerate(vibe_points):
    y = 2.06 + j * 1.18
    add_rect(sl, 0.45, y, 0.06, 0.9, YELLOW)
    add_text(sl, title,  0.62, y,        5.45, 0.35, 11.5, bold=True, color=YELLOW)
    add_text(sl, detail, 0.62, y + 0.35, 5.45, 0.72, 10,   color=LIGHT_GREY, wrap=True)

# right: app features
card(sl, 6.55, 1.45, 6.45, 5.72, fill=RGBColor(0x0A, 0x20, 0x34))
add_text(sl, "Streamlit App Features", 6.72, 1.55, 6.1, 0.42, 14, bold=True, color=ACCENT1)
add_rect(sl, 6.72, 1.93, 6.1, 0.04, ACCENT1)

pages = [
    (ACCENT2, "Page 1: Dashboard",
     ["KPI metrics: total customers, avg R/F/M",
      "Plotly pie chart — segment distribution",
      "Bar charts — avg Monetary & Frequency",
      "Full customer table with search"]),
    (ACCENT3, "Page 2: Predict Segment",
     ["Sliders: Recency (1-400), Frequency (1-100)",
      "Monetary slider (£1 – £50,000)",
      "Predict button → segment + recommendation",
      "Batch upload: predict CSV of customers"]),
    (ACCENT1, "Page 3: About",
     ["Project overview and methodology",
      "Algorithm comparison table",
      "RFM explanation and segment guide"]),
]
y_pos = 2.06
for col, page_name, bullets in pages:
    add_rect(sl, 6.72, y_pos, 1.5, 0.36, col)
    add_text(sl, page_name, 6.72, y_pos + 0.04, 1.5, 0.28, 9,
             bold=True, color=DARK_BG, align=PP_ALIGN.CENTER)
    for k, b in enumerate(bullets):
        add_text(sl, "  ▸  " + b, 8.32, y_pos + k * 0.36, 4.6, 0.34, 10, color=LIGHT_GREY)
    y_pos += len(bullets) * 0.36 + 0.28

add_rect(sl, 6.72, 6.82, 6.1, 0.28, RGBColor(0x1A, 0x35, 0x50))
add_text(sl, "Run:  python -m streamlit run app.py  →  http://localhost:8501",
         6.82, 6.84, 5.9, 0.24, 10.5, color=YELLOW, align=PP_ALIGN.CENTER)

# =============================================================================
# SLIDE 10 — FUTURE IMPROVEMENTS
# =============================================================================
sl = prs.slides.add_slide(BLANK)
bg(sl); accent_bar(sl, ACCENT3)
slide_title(sl, "Future Improvements & Roadmap",
            "Extending the project from segmentation to a full customer intelligence platform", ACCENT3)

improvements = [
    (ACCENT2, "Supervised Classifier",
     "Train a Random Forest or XGBoost on the cluster labels so new customers "
     "with limited history can be classified instantly without re-running clustering."),
    (ACCENT1, "Dynamic Re-Training",
     "Schedule monthly re-training pipeline (Airflow / cron) to update segments "
     "as customer behaviour evolves — prevents segment drift over time."),
    (ACCENT3, "Richer Feature Engineering",
     "Add product categories, time-of-day, day-of-week, device type, geographic "
     "region, and customer lifetime value (CLV) to improve cluster precision."),
    (YELLOW,  "Recommendation Engine",
     "Layer a collaborative-filtering recommender on top of segments to suggest "
     "personalised products based on what Champions and Loyalists buy together."),
    (ACCENT2, "Time-Series Segmentation",
     "Track how customers move between segments month-over-month using transition "
     "matrices — identify early warning signals before customers become Lapsed."),
    (ACCENT3, "Real-Time Prediction API",
     "Wrap the model in a FastAPI REST endpoint so the e-commerce platform can "
     "classify a customer's segment on every login and personalise in real time."),
]

for i, (col, title, desc) in enumerate(improvements):
    r, c = divmod(i, 3)
    x = 0.3 + c * 4.35
    y = 1.45 + r * 2.7
    card(sl, x, y, 4.15, 2.52, fill=RGBColor(0x0A, 0x20, 0x34))
    add_rect(sl, x, y, 4.15, 0.42, col)
    add_text(sl, str(i + 1) + ".  " + title, x + 0.14, y + 0.07,
             3.87, 0.34, 12, bold=True, color=DARK_BG)
    add_text(sl, desc, x + 0.14, y + 0.52, 3.87, 1.88,
             10.5, color=LIGHT_GREY, wrap=True)

# bottom tagline
add_rect(sl, 0.3, 6.92, 12.73, 0.38, RGBColor(0x0A, 0x20, 0x34))
add_text(sl,
         "Vision:  Move from batch segmentation  →  Real-time personalisation engine  →  "
         "Fully automated customer intelligence platform",
         0.45, 6.94, 12.43, 0.34, 11.5, color=ACCENT1, align=PP_ALIGN.CENTER)

# =============================================================================
# SAVE
# =============================================================================
prs.save("Customer_Segmentation_Presentation.pptx")
print("Presentation saved: Customer_Segmentation_Presentation.pptx")
