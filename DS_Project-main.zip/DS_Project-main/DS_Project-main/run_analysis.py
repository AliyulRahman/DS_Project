# ============================================================
# E-commerce Customer Segmentation — Full Analysis Script
# ============================================================

import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.neighbors import NearestNeighbors
from scipy.cluster.hierarchy import dendrogram, linkage

import joblib
import os

# ── styling ──────────────────────────────────────────────────
sns.set_theme(style='whitegrid', palette='husl')
COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD']

SAVE_DIR = r'C:\work\DS_Project-main\DS_Project-main'

def save_fig(name):
    path = os.path.join(SAVE_DIR, name)
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {name}")


# ============================================================
# SECTION 1 — Data Loading & Cleaning
# ============================================================
print("\n" + "="*60)
print("SECTION 1: Data Loading & Cleaning")
print("="*60)

df = pd.read_csv(os.path.join(SAVE_DIR, 'data.csv'), encoding='latin-1')
print(f"Raw shape: {df.shape}")

# Remove cancelled orders
df = df[~df['InvoiceNo'].astype(str).str.startswith('C')]
print(f"After removing cancellations: {df.shape}")

# Drop missing CustomerID
df = df.dropna(subset=['CustomerID'])
print(f"After dropping missing CustomerID: {df.shape}")

# Remove non-positive Quantity / UnitPrice
df = df[(df['Quantity'] > 0) & (df['UnitPrice'] > 0)]
print(f"After removing Qty/Price <= 0: {df.shape}")

# Type conversions
df['CustomerID'] = df['CustomerID'].astype(int)
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], format='mixed')

# Feature: TotalAmount
df['TotalAmount'] = df['Quantity'] * df['UnitPrice']

print(f"Final clean shape: {df.shape}")
print(f"Date range: {df['InvoiceDate'].min()} to {df['InvoiceDate'].max()}")
print(f"Unique customers: {df['CustomerID'].nunique()}")


# ============================================================
# SECTION 2 — EDA
# ============================================================
print("\n" + "="*60)
print("SECTION 2: Exploratory Data Analysis")
print("="*60)

# ── Top 10 countries by revenue ──────────────────────────────
country_rev = (df.groupby('Country')['TotalAmount']
               .sum()
               .sort_values(ascending=False)
               .head(10))

fig, ax = plt.subplots(figsize=(12, 6))
bars = ax.bar(country_rev.index, country_rev.values / 1e6,
              color=COLORS[:len(country_rev)])
ax.set_title('Top 10 Countries by Revenue', fontsize=16, fontweight='bold')
ax.set_xlabel('Country')
ax.set_ylabel('Revenue (£ Millions)')
plt.xticks(rotation=45, ha='right')
for bar, val in zip(bars, country_rev.values):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height(),
            f'£{val/1e6:.2f}M', ha='center', va='bottom', fontsize=9)
plt.tight_layout()
save_fig('eda_countries.png')

# ── Monthly revenue trend ────────────────────────────────────
df['YearMonth'] = df['InvoiceDate'].dt.to_period('M')
monthly = df.groupby('YearMonth')['TotalAmount'].sum().reset_index()
monthly['YearMonth_str'] = monthly['YearMonth'].astype(str)

fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(monthly['YearMonth_str'], monthly['TotalAmount'] / 1e6,
        marker='o', linewidth=2, color='#FF6B6B', markersize=6)
ax.fill_between(monthly['YearMonth_str'], monthly['TotalAmount'] / 1e6,
                alpha=0.3, color='#FF6B6B')
ax.set_title('Monthly Revenue Trend', fontsize=16, fontweight='bold')
ax.set_xlabel('Month')
ax.set_ylabel('Revenue (£ Millions)')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
save_fig('eda_monthly.png')
print("EDA charts saved.")


# ============================================================
# SECTION 3 — RFM Feature Engineering
# ============================================================
print("\n" + "="*60)
print("SECTION 3: RFM Feature Engineering")
print("="*60)

reference_date = df['InvoiceDate'].max() + pd.Timedelta(days=1)
print(f"Reference date: {reference_date}")

rfm = df.groupby('CustomerID').agg(
    Recency   = ('InvoiceDate',  lambda x: (reference_date - x.max()).days),
    Frequency = ('InvoiceNo',    'nunique'),
    Monetary  = ('TotalAmount',  'sum')
).reset_index()

print(f"RFM shape: {rfm.shape}")
print(rfm.describe().round(2))

# ── RFM distributions ────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
for ax, col, color in zip(axes, ['Recency', 'Frequency', 'Monetary'], COLORS):
    ax.hist(rfm[col], bins=50, color=color, edgecolor='white', alpha=0.8)
    ax.set_title(f'{col} Distribution', fontsize=13, fontweight='bold')
    ax.set_xlabel(col)
    ax.set_ylabel('Count')
    ax.axvline(rfm[col].median(), color='red', linestyle='--', linewidth=1.5,
               label=f'Median: {rfm[col].median():.1f}')
    ax.legend()
plt.suptitle('RFM Feature Distributions', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
save_fig('rfm_distributions.png')


# ============================================================
# SECTION 4 — Feature Scaling
# ============================================================
print("\n" + "="*60)
print("SECTION 4: Feature Scaling")
print("="*60)

rfm_log = rfm[['Recency', 'Frequency', 'Monetary']].copy()
rfm_log['Recency']   = np.log1p(rfm_log['Recency'])
rfm_log['Frequency'] = np.log1p(rfm_log['Frequency'])
rfm_log['Monetary']  = np.log1p(rfm_log['Monetary'])

scaler = StandardScaler()
rfm_scaled = scaler.fit_transform(rfm_log)
print(f"rfm_scaled shape: {rfm_scaled.shape}")
print(f"Mean (should be ~0): {rfm_scaled.mean(axis=0).round(4)}")
print(f"Std  (should be ~1): {rfm_scaled.std(axis=0).round(4)}")


# ============================================================
# SECTION 5 — Optimal K
# ============================================================
print("\n" + "="*60)
print("SECTION 5: Finding Optimal Number of Clusters")
print("="*60)

k_range = range(2, 11)
inertias, silhouettes, db_scores, ch_scores = [], [], [], []

for k in k_range:
    km = KMeans(n_clusters=k, init='k-means++', random_state=42, n_init=10)
    labels = km.fit_predict(rfm_scaled)
    inertias.append(km.inertia_)
    silhouettes.append(silhouette_score(rfm_scaled, labels))
    db_scores.append(davies_bouldin_score(rfm_scaled, labels))
    ch_scores.append(calinski_harabasz_score(rfm_scaled, labels))
    print(f"  k={k}: inertia={km.inertia_:.0f}, sil={silhouettes[-1]:.4f}, "
          f"db={db_scores[-1]:.4f}, ch={ch_scores[-1]:.0f}")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
metrics = [
    (inertias,    'Inertia (Elbow Method)',       'Inertia',            '#FF6B6B'),
    (silhouettes, 'Silhouette Score (↑ better)',  'Silhouette Score',   '#4ECDC4'),
    (db_scores,   'Davies-Bouldin Score (↓ better)', 'DB Score',        '#45B7D1'),
    (ch_scores,   'Calinski-Harabasz Score (↑ better)', 'CH Score',     '#96CEB4'),
]
for ax, (vals, title, ylabel, col) in zip(axes.flat, metrics):
    ax.plot(list(k_range), vals, marker='o', color=col, linewidth=2, markersize=8)
    ax.axvline(4, color='red', linestyle='--', alpha=0.7, label='k=4 (chosen)')
    ax.set_title(title, fontsize=12, fontweight='bold')
    ax.set_xlabel('Number of Clusters (k)')
    ax.set_ylabel(ylabel)
    ax.legend()
    ax.set_xticks(list(k_range))
plt.suptitle('Optimal Number of Clusters Analysis', fontsize=16, fontweight='bold')
plt.tight_layout()
save_fig('optimal_k.png')

K_FINAL = 4
print(f"\nChosen k = {K_FINAL}")


# ============================================================
# SECTION 6 — Algorithm 1: K-Means
# ============================================================
print("\n" + "="*60)
print("SECTION 6: K-Means Clustering (k=4)")
print("="*60)

kmeans = KMeans(n_clusters=K_FINAL, init='k-means++', random_state=42, n_init=10)
km_labels = kmeans.fit_predict(rfm_scaled)

km_sil = silhouette_score(rfm_scaled, km_labels)
km_db  = davies_bouldin_score(rfm_scaled, km_labels)
km_ch  = calinski_harabasz_score(rfm_scaled, km_labels)
print(f"K-Means  | Sil={km_sil:.4f}  DB={km_db:.4f}  CH={km_ch:.0f}")

# PCA visualisation
pca = PCA(n_components=2, random_state=42)
rfm_pca = pca.fit_transform(rfm_scaled)

fig, ax = plt.subplots(figsize=(10, 8))
for i in range(K_FINAL):
    mask = km_labels == i
    ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
               c=COLORS[i], label=f'Cluster {i}', alpha=0.6, s=30)
centers_pca = pca.transform(kmeans.cluster_centers_)
ax.scatter(centers_pca[:, 0], centers_pca[:, 1],
           c='black', marker='X', s=200, zorder=5, label='Centroids')
ax.set_title(f'K-Means Clustering (k={K_FINAL}) — PCA Projection',
             fontsize=14, fontweight='bold')
ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
ax.legend()
save_fig('kmeans_clusters.png')

# Silhouette plot
from sklearn.metrics import silhouette_samples
sil_vals = silhouette_samples(rfm_scaled, km_labels)
fig, ax = plt.subplots(figsize=(10, 7))
y_lower = 10
for i in range(K_FINAL):
    cluster_sil = np.sort(sil_vals[km_labels == i])
    size = cluster_sil.shape[0]
    y_upper = y_lower + size
    ax.fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_sil,
                     facecolor=COLORS[i], edgecolor=COLORS[i], alpha=0.7)
    ax.text(-0.05, y_lower + 0.5 * size, str(i))
    y_lower = y_upper + 10
ax.axvline(km_sil, color='red', linestyle='--', label=f'Avg={km_sil:.3f}')
ax.set_title('K-Means Silhouette Plot', fontsize=14, fontweight='bold')
ax.set_xlabel('Silhouette Coefficient')
ax.set_ylabel('Cluster')
ax.legend()
save_fig('kmeans_silhouette.png')


# ============================================================
# SECTION 7 — Algorithm 2: Hierarchical Clustering
# ============================================================
print("\n" + "="*60)
print("SECTION 7: Hierarchical Clustering (k=4)")
print("="*60)

# Dendrogram on a 200-sample subset
np.random.seed(42)
sample_idx = np.random.choice(len(rfm_scaled), size=min(200, len(rfm_scaled)), replace=False)
rfm_sample = rfm_scaled[sample_idx]

linked = linkage(rfm_sample, method='ward')
fig, ax = plt.subplots(figsize=(16, 7))
dendrogram(linked, ax=ax, truncate_mode='lastp', p=30,
           leaf_rotation=45, leaf_font_size=9, show_contracted=True)
ax.set_title('Hierarchical Clustering Dendrogram (200-sample subset)',
             fontsize=14, fontweight='bold')
ax.set_xlabel('Sample Index')
ax.set_ylabel('Distance')
plt.tight_layout()
save_fig('hierarchical_dendrogram.png')

# Full clustering
hc = AgglomerativeClustering(n_clusters=K_FINAL, linkage='ward')
hc_labels = hc.fit_predict(rfm_scaled)

hc_sil = silhouette_score(rfm_scaled, hc_labels)
hc_db  = davies_bouldin_score(rfm_scaled, hc_labels)
hc_ch  = calinski_harabasz_score(rfm_scaled, hc_labels)
print(f"Hierarchical | Sil={hc_sil:.4f}  DB={hc_db:.4f}  CH={hc_ch:.0f}")

fig, ax = plt.subplots(figsize=(10, 8))
for i in range(K_FINAL):
    mask = hc_labels == i
    ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
               c=COLORS[i], label=f'Cluster {i}', alpha=0.6, s=30)
ax.set_title('Hierarchical Clustering — PCA Projection', fontsize=14, fontweight='bold')
ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
ax.legend()
save_fig('hierarchical_clusters.png')


# ============================================================
# SECTION 8 — Algorithm 3: DBSCAN
# ============================================================
print("\n" + "="*60)
print("SECTION 8: DBSCAN")
print("="*60)

# K-distance plot (k=5 nearest neighbours)
nbrs = NearestNeighbors(n_neighbors=5).fit(rfm_scaled)
distances, _ = nbrs.kneighbors(rfm_scaled)
k_distances = np.sort(distances[:, 4])[::-1]

fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(k_distances, color='#FF6B6B', linewidth=1.5)
ax.axhline(0.5, color='blue', linestyle='--', label='eps=0.5')
ax.set_title('K-Distance Plot (k=5) for DBSCAN eps Selection',
             fontsize=14, fontweight='bold')
ax.set_xlabel('Points (sorted)')
ax.set_ylabel('5th Nearest Neighbour Distance')
ax.legend()
save_fig('dbscan_kdistance.png')

db = DBSCAN(eps=0.5, min_samples=5)
db_labels = db.fit_predict(rfm_scaled)

n_clusters_db = len(set(db_labels)) - (1 if -1 in db_labels else 0)
n_noise_db    = np.sum(db_labels == -1)
print(f"DBSCAN clusters: {n_clusters_db},  noise points: {n_noise_db}")

# Metrics (exclude noise)
mask_no_noise = db_labels != -1
if n_clusters_db >= 2 and mask_no_noise.sum() > n_clusters_db:
    db_sil = silhouette_score(rfm_scaled[mask_no_noise], db_labels[mask_no_noise])
    db_db  = davies_bouldin_score(rfm_scaled[mask_no_noise], db_labels[mask_no_noise])
    db_ch  = calinski_harabasz_score(rfm_scaled[mask_no_noise], db_labels[mask_no_noise])
else:
    db_sil, db_db, db_ch = 0.0, float('inf'), 0.0
    print("  DBSCAN: < 2 valid clusters — metrics set to 0/inf")

print(f"DBSCAN   | Sil={db_sil:.4f}  DB={db_db:.4f}  CH={db_ch:.0f}")

# PCA visualisation (noise = grey)
fig, ax = plt.subplots(figsize=(10, 8))
unique_labels = sorted(set(db_labels))
for lbl in unique_labels:
    mask = db_labels == lbl
    if lbl == -1:
        ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
                   c='lightgrey', label='Noise', alpha=0.4, s=20)
    else:
        ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
                   c=COLORS[lbl % len(COLORS)], label=f'Cluster {lbl}',
                   alpha=0.6, s=30)
ax.set_title('DBSCAN Clustering — PCA Projection', fontsize=14, fontweight='bold')
ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
ax.legend()
save_fig('dbscan_clusters.png')


# ============================================================
# SECTION 9 — Algorithm 4: Gaussian Mixture Model
# ============================================================
print("\n" + "="*60)
print("SECTION 9: Gaussian Mixture Model (GMM)")
print("="*60)

n_components_range = range(2, 9)
bic_scores, aic_scores = [], []
for n in n_components_range:
    gmm_tmp = GaussianMixture(n_components=n, random_state=42, n_init=5)
    gmm_tmp.fit(rfm_scaled)
    bic_scores.append(gmm_tmp.bic(rfm_scaled))
    aic_scores.append(gmm_tmp.aic(rfm_scaled))
    print(f"  n={n}: BIC={bic_scores[-1]:.0f}  AIC={aic_scores[-1]:.0f}")

fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(list(n_components_range), bic_scores, marker='o', label='BIC', color='#FF6B6B', linewidth=2)
ax.plot(list(n_components_range), aic_scores, marker='s', label='AIC', color='#4ECDC4', linewidth=2)
ax.axvline(K_FINAL, color='red', linestyle='--', alpha=0.7, label=f'n={K_FINAL} (chosen)')
ax.set_title('GMM — BIC / AIC Model Selection', fontsize=14, fontweight='bold')
ax.set_xlabel('Number of Components')
ax.set_ylabel('Score')
ax.legend()
save_fig('gmm_selection.png')

gmm = GaussianMixture(n_components=K_FINAL, random_state=42, n_init=10)
gmm_labels = gmm.fit_predict(rfm_scaled)

gmm_sil = silhouette_score(rfm_scaled, gmm_labels)
gmm_db  = davies_bouldin_score(rfm_scaled, gmm_labels)
gmm_ch  = calinski_harabasz_score(rfm_scaled, gmm_labels)
print(f"GMM      | Sil={gmm_sil:.4f}  DB={gmm_db:.4f}  CH={gmm_ch:.0f}")

fig, ax = plt.subplots(figsize=(10, 8))
for i in range(K_FINAL):
    mask = gmm_labels == i
    ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
               c=COLORS[i], label=f'Component {i}', alpha=0.6, s=30)
ax.set_title('GMM Clustering — PCA Projection', fontsize=14, fontweight='bold')
ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
ax.legend()
save_fig('gmm_clusters.png')


# ============================================================
# SECTION 10 — Algorithm Comparison
# ============================================================
print("\n" + "="*60)
print("SECTION 10: Algorithm Comparison")
print("="*60)

comparison = pd.DataFrame({
    'Algorithm':        ['K-Means', 'Hierarchical', 'DBSCAN', 'GMM'],
    'Clusters':         [K_FINAL, K_FINAL, n_clusters_db, K_FINAL],
    'Noise Points':     [0, 0, n_noise_db, 0],
    'Silhouette':       [km_sil, hc_sil, db_sil, gmm_sil],
    'Davies-Bouldin':   [km_db,  hc_db,  db_db,  gmm_db],
    'Calinski-Harabasz':[km_ch,  hc_ch,  db_ch,  gmm_ch],
})
print(comparison.to_string(index=False))

# Bar chart
fig, axes = plt.subplots(1, 3, figsize=(16, 6))
algos = comparison['Algorithm']

axes[0].bar(algos, comparison['Silhouette'], color=COLORS[:4])
axes[0].set_title('Silhouette Score (↑ better)', fontweight='bold')
axes[0].set_ylabel('Score')
axes[0].tick_params(axis='x', rotation=15)

axes[1].bar(algos, comparison['Davies-Bouldin'].replace(float('inf'), 0), color=COLORS[:4])
axes[1].set_title('Davies-Bouldin Score (↓ better)', fontweight='bold')
axes[1].set_ylabel('Score')
axes[1].tick_params(axis='x', rotation=15)

axes[2].bar(algos, comparison['Calinski-Harabasz'], color=COLORS[:4])
axes[2].set_title('Calinski-Harabasz Score (↑ better)', fontweight='bold')
axes[2].set_ylabel('Score')
axes[2].tick_params(axis='x', rotation=15)

plt.suptitle('Algorithm Comparison', fontsize=16, fontweight='bold')
plt.tight_layout()
save_fig('algorithm_comparison.png')

print("\nWINNER: K-Means (best balance of silhouette and interpretability)")


# ============================================================
# SECTION 11 — Segment Profiling
# ============================================================
print("\n" + "="*60)
print("SECTION 11: Customer Segment Profiling")
print("="*60)

rfm_final = rfm.copy()
rfm_final['Cluster'] = km_labels

cluster_profile = rfm_final.groupby('Cluster').agg(
    Count           = ('CustomerID', 'count'),
    Avg_Recency     = ('Recency',    'mean'),
    Median_Recency  = ('Recency',    'median'),
    Avg_Frequency   = ('Frequency',  'mean'),
    Median_Frequency= ('Frequency',  'median'),
    Avg_Monetary    = ('Monetary',   'mean'),
    Median_Monetary = ('Monetary',   'median'),
).round(2)

print(cluster_profile)

# Assign segment names based on relative R/F/M medians
overall_r_med = rfm_final['Recency'].median()
overall_f_med = rfm_final['Frequency'].median()
overall_m_med = rfm_final['Monetary'].median()

def assign_segment(row):
    r_low  = row['Median_Recency']   < overall_r_med   # bought recently → good
    f_high = row['Median_Frequency'] > overall_f_med
    m_high = row['Median_Monetary']  > overall_m_med

    if r_low and f_high and m_high:
        return 'Champions'
    elif (not r_low) and f_high and m_high:
        return 'At Risk'
    elif r_low and f_high:
        return 'Loyal Customers'
    elif r_low and m_high:
        return 'Loyal Customers'
    elif r_low:
        return 'Potential Loyalists'
    else:
        return 'At Risk'

cluster_profile['Segment'] = cluster_profile.apply(assign_segment, axis=1)
# Guarantee uniqueness — if two clusters map to same name, suffix with cluster id
seen = {}
new_names = []
for idx, seg in cluster_profile['Segment'].items():
    if seg in seen:
        new_names.append(f"{seg} (C{idx})")
    else:
        seen[seg] = True
        new_names.append(seg)
cluster_profile['Segment'] = new_names

print("\nCluster -> Segment mapping:")
print(cluster_profile[['Count', 'Segment']])

rfm_final['Segment'] = rfm_final['Cluster'].map(
    cluster_profile['Segment'].to_dict())

# ── Final Dashboard: Pie + 3 bars ─────────────────────────────
fig = plt.figure(figsize=(18, 12))
gs  = gridspec.GridSpec(2, 3, figure=fig, hspace=0.4, wspace=0.35)

# Pie
ax_pie = fig.add_subplot(gs[0, :])   # full top row
seg_counts = rfm_final['Segment'].value_counts()
wedge_colors = COLORS[:len(seg_counts)]
ax_pie.pie(seg_counts.values, labels=seg_counts.index,
           autopct='%1.1f%%', colors=wedge_colors,
           startangle=140, pctdistance=0.85)
ax_pie.set_title('Customer Segment Distribution', fontsize=16, fontweight='bold')

ax_r = fig.add_subplot(gs[1, 0])
ax_f = fig.add_subplot(gs[1, 1])
ax_m = fig.add_subplot(gs[1, 2])

seg_means = rfm_final.groupby('Segment')[['Recency', 'Frequency', 'Monetary']].mean()

ax_r.bar(seg_means.index, seg_means['Recency'], color=COLORS[:len(seg_means)])
ax_r.set_title('Avg Recency by Segment\n(lower = better)', fontweight='bold')
ax_r.set_ylabel('Days')
ax_r.tick_params(axis='x', rotation=30)

ax_f.bar(seg_means.index, seg_means['Frequency'], color=COLORS[:len(seg_means)])
ax_f.set_title('Avg Frequency by Segment', fontweight='bold')
ax_f.set_ylabel('# Purchases')
ax_f.tick_params(axis='x', rotation=30)

ax_m.bar(seg_means.index, seg_means['Monetary'], color=COLORS[:len(seg_means)])
ax_m.set_title('Avg Monetary Value by Segment', fontweight='bold')
ax_m.set_ylabel('£ Revenue')
ax_m.tick_params(axis='x', rotation=30)

plt.suptitle('Customer Segmentation Dashboard', fontsize=18, fontweight='bold', y=1.01)
save_fig('final_dashboard.png')

# ── Normalised RFM scores per segment ────────────────────────
seg_rfm = rfm_final.groupby('Segment')[['Recency', 'Frequency', 'Monetary']].mean()
# For Recency: invert so "lower recency = better score"
seg_rfm_norm = seg_rfm.copy()
seg_rfm_norm['Recency'] = seg_rfm_norm['Recency'].max() - seg_rfm_norm['Recency']
for col in seg_rfm_norm.columns:
    rng = seg_rfm_norm[col].max() - seg_rfm_norm[col].min()
    if rng > 0:
        seg_rfm_norm[col] = (seg_rfm_norm[col] - seg_rfm_norm[col].min()) / rng

x = np.arange(len(seg_rfm_norm.columns))
width = 0.8 / len(seg_rfm_norm)
fig, ax = plt.subplots(figsize=(12, 7))
for i, (seg, row) in enumerate(seg_rfm_norm.iterrows()):
    offset = (i - len(seg_rfm_norm) / 2 + 0.5) * width
    ax.bar(x + offset, row.values, width=width,
           label=seg, color=COLORS[i % len(COLORS)], alpha=0.85)
ax.set_xticks(x)
ax.set_xticklabels(['Recency\n(inverted)', 'Frequency', 'Monetary'])
ax.set_title('Normalised RFM Scores by Customer Segment', fontsize=14, fontweight='bold')
ax.set_ylabel('Normalised Score (0–1)')
ax.legend(title='Segment', bbox_to_anchor=(1.01, 1), loc='upper left')
plt.tight_layout()
save_fig('segment_rfm_scores.png')

print("\nSegment profiling complete.")


# ============================================================
# SECTION 12 — Save Artifacts
# ============================================================
print("\n" + "="*60)
print("SECTION 12: Saving Artifacts")
print("="*60)

joblib.dump(kmeans, os.path.join(SAVE_DIR, 'kmeans_model.pkl'))
print("  Saved: kmeans_model.pkl")

joblib.dump(scaler, os.path.join(SAVE_DIR, 'scaler.pkl'))
print("  Saved: scaler.pkl")

rfm_final.to_csv(os.path.join(SAVE_DIR, 'rfm_customers.csv'), index=False)
print("  Saved: rfm_customers.csv")

cluster_profile.to_csv(os.path.join(SAVE_DIR, 'cluster_profiles.csv'))
print("  Saved: cluster_profiles.csv")

print("\n" + "="*60)
print("ALL DONE! Analysis complete.")
print("="*60)
