"""
Creates Customer_Segmentation_Analysis.ipynb using nbformat.
"""
import nbformat
from nbformat.v4 import new_notebook, new_markdown_cell, new_code_cell

nb = new_notebook()
nb.metadata = {
    "kernelspec": {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3"
    },
    "language_info": {
        "name": "python",
        "version": "3.14.0"
    }
}

cells = []

# ── Title ────────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""# E-commerce Customer Segmentation and Prediction

**Project Overview**

This notebook develops a robust customer segmentation model for a UK-based e-commerce company
using the Online Retail dataset (541,909 transactions, Dec 2010 – Dec 2011).
By applying RFM (Recency, Frequency, Monetary) feature engineering and comparing four clustering
algorithms — K-Means, Hierarchical Clustering, DBSCAN, and Gaussian Mixture Models —
we identify distinct customer groups to support targeted marketing strategies.

**Key Steps**
1. Data Loading and Exploration
2. Data Cleaning and Preprocessing
3. Exploratory Data Analysis (EDA)
4. RFM Feature Engineering
5. Feature Scaling
6. Finding the Optimal Number of Clusters
7. Algorithm Comparison (K-Means, Hierarchical, DBSCAN, GMM)
8. Best Algorithm Selection
9. Customer Segment Profiling
10. Business Recommendations
11. Save Model and Artifacts
"""))

# ── Imports ──────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("## 0. Imports and Setup"))
cells.append(new_code_cell("""import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import (silhouette_score, silhouette_samples,
                             davies_bouldin_score, calinski_harabasz_score)
from sklearn.neighbors import NearestNeighbors
from scipy.cluster.hierarchy import dendrogram, linkage

import joblib

sns.set_theme(style='whitegrid', palette='husl')
COLORS = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD']
print("Libraries loaded successfully.")
"""))

# ── Section 1 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 1. Data Loading and Exploration

The dataset contains 541,909 transactional records from a UK-based online retailer.
Each row represents one item in an invoice, with 8 attributes:
`InvoiceNo`, `StockCode`, `Description`, `Quantity`, `InvoiceDate`, `UnitPrice`, `CustomerID`, `Country`.
"""))
cells.append(new_code_cell("""df_raw = pd.read_csv('data.csv', encoding='latin-1')
print(f"Shape: {df_raw.shape}")
df_raw.head()
"""))
cells.append(new_code_cell("""print("Data Types:")
print(df_raw.dtypes)
print("\\nMissing Values:")
print(df_raw.isnull().sum())
print(f"\\nCancelled orders (InvoiceNo starts with C): {df_raw['InvoiceNo'].astype(str).str.startswith('C').sum()}")
"""))
cells.append(new_code_cell("""df_raw.describe(include='all').T
"""))

# ── Section 2 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 2. Data Cleaning and Preprocessing

**Steps:**
- Remove 9,288 cancelled orders (InvoiceNo starts with 'C')
- Drop 135,080 rows with missing CustomerID
- Remove rows where Quantity <= 0 or UnitPrice <= 0 (returns/adjustments)
- Convert CustomerID to int, InvoiceDate to datetime
- Derive TotalAmount = Quantity × UnitPrice
"""))
cells.append(new_code_cell("""df = df_raw.copy()

# Remove cancelled orders
df = df[~df['InvoiceNo'].astype(str).str.startswith('C')]
print(f"After removing cancellations: {df.shape}")

# Drop missing CustomerID
df = df.dropna(subset=['CustomerID'])
print(f"After dropping missing CustomerID: {df.shape}")

# Remove non-positive Quantity / UnitPrice
df = df[(df['Quantity'] > 0) & (df['UnitPrice'] > 0)]
print(f"After removing Qty/Price <= 0: {df.shape}")

# Type conversions
df['CustomerID'] = df['CustomerID'].astype(int)
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], format='mixed')

# Derived feature
df['TotalAmount'] = df['Quantity'] * df['UnitPrice']

print(f"\\nFinal clean dataset: {df.shape}")
print(f"Date range: {df['InvoiceDate'].min()} to {df['InvoiceDate'].max()}")
print(f"Unique customers: {df['CustomerID'].nunique()}")
print(f"Unique invoices : {df['InvoiceNo'].nunique()}")
"""))

# ── Section 3 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 3. Exploratory Data Analysis

Visual exploration of revenue by country and over time.
"""))
cells.append(new_code_cell("""# Top 10 countries by revenue
country_rev = (df.groupby('Country')['TotalAmount']
               .sum().sort_values(ascending=False).head(10))

fig, ax = plt.subplots(figsize=(12, 6))
bars = ax.bar(country_rev.index, country_rev.values / 1e6, color=COLORS[:len(country_rev)])
ax.set_title('Top 10 Countries by Revenue', fontsize=16, fontweight='bold')
ax.set_xlabel('Country'); ax.set_ylabel('Revenue (GBP Millions)')
plt.xticks(rotation=45, ha='right')
for bar, val in zip(bars, country_rev.values):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height(),
            f'GBP{val/1e6:.2f}M', ha='center', va='bottom', fontsize=9)
plt.tight_layout()
plt.show()
"""))
cells.append(new_code_cell("""# Monthly revenue trend
df['YearMonth'] = df['InvoiceDate'].dt.to_period('M')
monthly = df.groupby('YearMonth')['TotalAmount'].sum().reset_index()
monthly['YearMonth_str'] = monthly['YearMonth'].astype(str)

fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(monthly['YearMonth_str'], monthly['TotalAmount'] / 1e6,
        marker='o', linewidth=2, color='#FF6B6B', markersize=6)
ax.fill_between(monthly['YearMonth_str'], monthly['TotalAmount'] / 1e6,
                alpha=0.3, color='#FF6B6B')
ax.set_title('Monthly Revenue Trend', fontsize=16, fontweight='bold')
ax.set_xlabel('Month'); ax.set_ylabel('Revenue (GBP Millions)')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
"""))
cells.append(new_code_cell("""# Invoice value distribution
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
invoice_totals = df.groupby('InvoiceNo')['TotalAmount'].sum()
axes[0].hist(invoice_totals[invoice_totals < 1000], bins=60,
             color='#4ECDC4', edgecolor='white')
axes[0].set_title('Invoice Value Distribution (< GBP1000)', fontweight='bold')
axes[0].set_xlabel('Invoice Total (GBP)')
axes[0].set_ylabel('Count')

axes[1].hist(np.log1p(invoice_totals), bins=60, color='#45B7D1', edgecolor='white')
axes[1].set_title('Log Invoice Value Distribution', fontweight='bold')
axes[1].set_xlabel('log(Invoice Total + 1)')
axes[1].set_ylabel('Count')
plt.tight_layout()
plt.show()
"""))

# ── Section 4 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 4. RFM Feature Engineering

**RFM** is a proven framework for customer value analysis:
- **Recency** — days since the customer's most recent purchase (lower = better)
- **Frequency** — number of unique invoices (higher = better)
- **Monetary** — total spend (higher = better)
"""))
cells.append(new_code_cell("""reference_date = df['InvoiceDate'].max() + pd.Timedelta(days=1)
print(f"Reference date: {reference_date}")

rfm = df.groupby('CustomerID').agg(
    Recency   = ('InvoiceDate',  lambda x: (reference_date - x.max()).days),
    Frequency = ('InvoiceNo',    'nunique'),
    Monetary  = ('TotalAmount',  'sum')
).reset_index()

print(f"RFM table shape: {rfm.shape}")
rfm.describe().round(2)
"""))
cells.append(new_code_cell("""fig, axes = plt.subplots(1, 3, figsize=(15, 5))
for ax, col, color in zip(axes, ['Recency', 'Frequency', 'Monetary'], COLORS):
    ax.hist(rfm[col], bins=50, color=color, edgecolor='white', alpha=0.8)
    ax.set_title(f'{col} Distribution', fontsize=13, fontweight='bold')
    ax.set_xlabel(col); ax.set_ylabel('Count')
    ax.axvline(rfm[col].median(), color='red', linestyle='--', linewidth=1.5,
               label=f'Median: {rfm[col].median():.1f}')
    ax.legend()
plt.suptitle('RFM Feature Distributions', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()
"""))

# ── Section 5 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 5. Feature Scaling

RFM values are heavily right-skewed. We apply **log1p transformation** to reduce skewness,
then **StandardScaler** to ensure all three features have zero mean and unit variance.
This prevents high-magnitude monetary values from dominating the distance calculations.
"""))
cells.append(new_code_cell("""rfm_log = rfm[['Recency', 'Frequency', 'Monetary']].copy()
rfm_log['Recency']   = np.log1p(rfm_log['Recency'])
rfm_log['Frequency'] = np.log1p(rfm_log['Frequency'])
rfm_log['Monetary']  = np.log1p(rfm_log['Monetary'])

scaler = StandardScaler()
rfm_scaled = scaler.fit_transform(rfm_log)

print(f"rfm_scaled shape : {rfm_scaled.shape}")
print(f"Column means (~0): {rfm_scaled.mean(axis=0).round(4)}")
print(f"Column stds  (~1): {rfm_scaled.std(axis=0).round(4)}")

# Compare distributions before/after scaling
fig, axes = plt.subplots(2, 3, figsize=(15, 8))
for i, col in enumerate(['Recency', 'Frequency', 'Monetary']):
    axes[0, i].hist(rfm[col], bins=50, color=COLORS[i], edgecolor='white', alpha=0.8)
    axes[0, i].set_title(f'{col} — Original', fontweight='bold')
    axes[1, i].hist(rfm_scaled[:, i], bins=50, color=COLORS[i], edgecolor='white', alpha=0.8)
    axes[1, i].set_title(f'{col} — Scaled', fontweight='bold')
plt.suptitle('Feature Distributions Before and After Scaling', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()
"""))

# ── Section 6 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 6. Finding Optimal Number of Clusters

We sweep k=2 to 10 and evaluate four metrics:
- **Inertia** (Elbow method) — measures within-cluster sum of squares; look for the elbow
- **Silhouette Score** (higher is better) — measures cluster cohesion and separation
- **Davies-Bouldin Score** (lower is better) — ratio of within-cluster scatter to between-cluster separation
- **Calinski-Harabasz Score** (higher is better) — ratio of between-cluster to within-cluster dispersion
"""))
cells.append(new_code_cell("""k_range = range(2, 11)
inertias, silhouettes, db_scores, ch_scores = [], [], [], []

for k in k_range:
    km = KMeans(n_clusters=k, init='k-means++', random_state=42, n_init=10)
    labels = km.fit_predict(rfm_scaled)
    inertias.append(km.inertia_)
    silhouettes.append(silhouette_score(rfm_scaled, labels))
    db_scores.append(davies_bouldin_score(rfm_scaled, labels))
    ch_scores.append(calinski_harabasz_score(rfm_scaled, labels))
    print(f"k={k:2d}: inertia={km.inertia_:7.0f}  sil={silhouettes[-1]:.4f}  "
          f"db={db_scores[-1]:.4f}  ch={ch_scores[-1]:.0f}")
"""))
cells.append(new_code_cell("""fig, axes = plt.subplots(2, 2, figsize=(14, 10))
metrics = [
    (inertias,    'Inertia (Elbow Method)',          'Inertia',            '#FF6B6B'),
    (silhouettes, 'Silhouette Score (higher better)', 'Silhouette Score',   '#4ECDC4'),
    (db_scores,   'Davies-Bouldin Score (lower better)','DB Score',         '#45B7D1'),
    (ch_scores,   'Calinski-Harabasz Score (higher better)','CH Score',     '#96CEB4'),
]
for ax, (vals, title, ylabel, col) in zip(axes.flat, metrics):
    ax.plot(list(k_range), vals, marker='o', color=col, linewidth=2, markersize=8)
    ax.axvline(4, color='red', linestyle='--', alpha=0.7, label='k=4 (chosen)')
    ax.set_title(title, fontsize=12, fontweight='bold')
    ax.set_xlabel('Number of Clusters (k)')
    ax.set_ylabel(ylabel)
    ax.legend(); ax.set_xticks(list(k_range))
plt.suptitle('Optimal Number of Clusters Analysis', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()
print("\\nSelected k=4: good elbow in inertia; reasonable silhouette score.")
"""))

# ── Section 7 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 7. Algorithm Comparison

We train and evaluate four clustering algorithms all using k=4 (where applicable):
- **K-Means**: partitional, fast, assumes spherical clusters
- **Hierarchical (Ward linkage)**: builds a dendrogram; no need to pre-specify k
- **DBSCAN**: density-based; identifies noise, variable cluster shapes
- **GMM**: probabilistic; soft cluster assignments
"""))

cells.append(new_markdown_cell("### K-Means Clustering"))
cells.append(new_code_cell("""K_FINAL = 4
kmeans = KMeans(n_clusters=K_FINAL, init='k-means++', random_state=42, n_init=10)
km_labels = kmeans.fit_predict(rfm_scaled)

km_sil = silhouette_score(rfm_scaled, km_labels)
km_db  = davies_bouldin_score(rfm_scaled, km_labels)
km_ch  = calinski_harabasz_score(rfm_scaled, km_labels)
print(f"K-Means -> Silhouette: {km_sil:.4f}  Davies-Bouldin: {km_db:.4f}  Calinski-Harabasz: {km_ch:.0f}")

# PCA 2D projection
pca = PCA(n_components=2, random_state=42)
rfm_pca = pca.fit_transform(rfm_scaled)

fig, axes = plt.subplots(1, 2, figsize=(16, 6))
for i in range(K_FINAL):
    mask = km_labels == i
    axes[0].scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
                    c=COLORS[i], label=f'Cluster {i}', alpha=0.6, s=30)
centers_pca = pca.transform(kmeans.cluster_centers_)
axes[0].scatter(centers_pca[:, 0], centers_pca[:, 1],
                c='black', marker='X', s=200, zorder=5, label='Centroids')
axes[0].set_title(f'K-Means (k={K_FINAL}) PCA Projection', fontsize=13, fontweight='bold')
axes[0].set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
axes[0].set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
axes[0].legend()

# Silhouette plot
sil_vals = silhouette_samples(rfm_scaled, km_labels)
y_lower = 10
for i in range(K_FINAL):
    cluster_sil = np.sort(sil_vals[km_labels == i])
    size = cluster_sil.shape[0]
    y_upper = y_lower + size
    axes[1].fill_betweenx(np.arange(y_lower, y_upper), 0, cluster_sil,
                          facecolor=COLORS[i], edgecolor=COLORS[i], alpha=0.7)
    axes[1].text(-0.05, y_lower + 0.5*size, str(i))
    y_lower = y_upper + 10
axes[1].axvline(km_sil, color='red', linestyle='--', label=f'Avg={km_sil:.3f}')
axes[1].set_title('K-Means Silhouette Plot', fontsize=13, fontweight='bold')
axes[1].set_xlabel('Silhouette Coefficient'); axes[1].set_ylabel('Cluster')
axes[1].legend()
plt.tight_layout()
plt.show()
"""))

cells.append(new_markdown_cell("### Hierarchical Clustering"))
cells.append(new_code_cell("""np.random.seed(42)
sample_idx = np.random.choice(len(rfm_scaled), size=200, replace=False)
rfm_sample = rfm_scaled[sample_idx]
linked = linkage(rfm_sample, method='ward')

fig, ax = plt.subplots(figsize=(16, 7))
dendrogram(linked, ax=ax, truncate_mode='lastp', p=30,
           leaf_rotation=45, leaf_font_size=9, show_contracted=True)
ax.set_title('Hierarchical Clustering Dendrogram (200-sample subset)',
             fontsize=14, fontweight='bold')
ax.set_xlabel('Sample Index'); ax.set_ylabel('Distance')
plt.tight_layout()
plt.show()
"""))
cells.append(new_code_cell("""hc = AgglomerativeClustering(n_clusters=K_FINAL, linkage='ward')
hc_labels = hc.fit_predict(rfm_scaled)

hc_sil = silhouette_score(rfm_scaled, hc_labels)
hc_db  = davies_bouldin_score(rfm_scaled, hc_labels)
hc_ch  = calinski_harabasz_score(rfm_scaled, hc_labels)
print(f"Hierarchical -> Silhouette: {hc_sil:.4f}  Davies-Bouldin: {hc_db:.4f}  Calinski-Harabasz: {hc_ch:.0f}")

fig, ax = plt.subplots(figsize=(10, 8))
for i in range(K_FINAL):
    mask = hc_labels == i
    ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
               c=COLORS[i], label=f'Cluster {i}', alpha=0.6, s=30)
ax.set_title('Hierarchical Clustering PCA Projection', fontsize=14, fontweight='bold')
ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
ax.legend()
plt.show()
"""))

cells.append(new_markdown_cell("### DBSCAN"))
cells.append(new_code_cell("""# K-distance plot for eps selection
nbrs = NearestNeighbors(n_neighbors=5).fit(rfm_scaled)
distances, _ = nbrs.kneighbors(rfm_scaled)
k_distances = np.sort(distances[:, 4])[::-1]

fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(k_distances, color='#FF6B6B', linewidth=1.5)
ax.axhline(0.5, color='blue', linestyle='--', label='eps=0.5')
ax.set_title('K-Distance Plot (k=5) for DBSCAN eps Selection',
             fontsize=14, fontweight='bold')
ax.set_xlabel('Points (sorted)'); ax.set_ylabel('5th NN Distance')
ax.legend()
plt.show()
"""))
cells.append(new_code_cell("""db = DBSCAN(eps=0.5, min_samples=5)
db_labels = db.fit_predict(rfm_scaled)

n_clusters_db = len(set(db_labels)) - (1 if -1 in db_labels else 0)
n_noise_db    = np.sum(db_labels == -1)
print(f"DBSCAN: {n_clusters_db} clusters, {n_noise_db} noise points")

mask_no_noise = db_labels != -1
if n_clusters_db >= 2 and mask_no_noise.sum() > n_clusters_db:
    db_sil = silhouette_score(rfm_scaled[mask_no_noise], db_labels[mask_no_noise])
    db_db  = davies_bouldin_score(rfm_scaled[mask_no_noise], db_labels[mask_no_noise])
    db_ch  = calinski_harabasz_score(rfm_scaled[mask_no_noise], db_labels[mask_no_noise])
else:
    db_sil, db_db, db_ch = 0.0, float('inf'), 0.0
print(f"DBSCAN  -> Silhouette: {db_sil:.4f}  Davies-Bouldin: {db_db:.4f}  Calinski-Harabasz: {db_ch:.0f}")

fig, ax = plt.subplots(figsize=(10, 8))
for lbl in sorted(set(db_labels)):
    mask = db_labels == lbl
    if lbl == -1:
        ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
                   c='lightgrey', label='Noise', alpha=0.4, s=20)
    else:
        ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
                   c=COLORS[lbl % len(COLORS)], label=f'Cluster {lbl}', alpha=0.6, s=30)
ax.set_title('DBSCAN Clustering PCA Projection', fontsize=14, fontweight='bold')
ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
ax.legend()
plt.show()
"""))

cells.append(new_markdown_cell("### Gaussian Mixture Model (GMM)"))
cells.append(new_code_cell("""n_components_range = range(2, 9)
bic_scores, aic_scores = [], []
for n in n_components_range:
    gmm_tmp = GaussianMixture(n_components=n, random_state=42, n_init=5)
    gmm_tmp.fit(rfm_scaled)
    bic_scores.append(gmm_tmp.bic(rfm_scaled))
    aic_scores.append(gmm_tmp.aic(rfm_scaled))

fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(list(n_components_range), bic_scores, marker='o', label='BIC',
        color='#FF6B6B', linewidth=2)
ax.plot(list(n_components_range), aic_scores, marker='s', label='AIC',
        color='#4ECDC4', linewidth=2)
ax.axvline(K_FINAL, color='red', linestyle='--', alpha=0.7, label=f'n={K_FINAL}')
ax.set_title('GMM BIC/AIC Model Selection', fontsize=14, fontweight='bold')
ax.set_xlabel('Number of Components'); ax.set_ylabel('Score')
ax.legend()
plt.show()
"""))
cells.append(new_code_cell("""gmm = GaussianMixture(n_components=K_FINAL, random_state=42, n_init=10)
gmm_labels = gmm.fit_predict(rfm_scaled)

gmm_sil = silhouette_score(rfm_scaled, gmm_labels)
gmm_db  = davies_bouldin_score(rfm_scaled, gmm_labels)
gmm_ch  = calinski_harabasz_score(rfm_scaled, gmm_labels)
print(f"GMM -> Silhouette: {gmm_sil:.4f}  Davies-Bouldin: {gmm_db:.4f}  Calinski-Harabasz: {gmm_ch:.0f}")

fig, ax = plt.subplots(figsize=(10, 8))
for i in range(K_FINAL):
    mask = gmm_labels == i
    ax.scatter(rfm_pca[mask, 0], rfm_pca[mask, 1],
               c=COLORS[i], label=f'Component {i}', alpha=0.6, s=30)
ax.set_title('GMM Clustering PCA Projection', fontsize=14, fontweight='bold')
ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)')
ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)')
ax.legend()
plt.show()
"""))

# ── Section 8 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 8. Best Algorithm Selection

We compare all algorithms side by side using three clustering quality metrics.
"""))
cells.append(new_code_cell("""comparison = pd.DataFrame({
    'Algorithm':         ['K-Means', 'Hierarchical', 'DBSCAN', 'GMM'],
    'Clusters':          [K_FINAL, K_FINAL, n_clusters_db, K_FINAL],
    'Noise Points':      [0, 0, n_noise_db, 0],
    'Silhouette':        [km_sil, hc_sil, db_sil, gmm_sil],
    'Davies-Bouldin':    [km_db,  hc_db,  db_db,  gmm_db],
    'Calinski-Harabasz': [km_ch,  hc_ch,  db_ch,  gmm_ch],
})
print(comparison.to_string(index=False))

fig, axes = plt.subplots(1, 3, figsize=(16, 6))
algos = comparison['Algorithm']

axes[0].bar(algos, comparison['Silhouette'], color=COLORS[:4])
axes[0].set_title('Silhouette Score (higher better)', fontweight='bold')
axes[0].set_ylabel('Score'); axes[0].tick_params(axis='x', rotation=15)

axes[1].bar(algos, comparison['Davies-Bouldin'].replace(float('inf'), 0), color=COLORS[:4])
axes[1].set_title('Davies-Bouldin Score (lower better)', fontweight='bold')
axes[1].set_ylabel('Score'); axes[1].tick_params(axis='x', rotation=15)

axes[2].bar(algos, comparison['Calinski-Harabasz'], color=COLORS[:4])
axes[2].set_title('Calinski-Harabasz Score (higher better)', fontweight='bold')
axes[2].set_ylabel('Score'); axes[2].tick_params(axis='x', rotation=15)

plt.suptitle('Algorithm Comparison', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()

print("\\nWINNER: K-Means")
print("K-Means achieves the highest Silhouette score, lowest Davies-Bouldin score,")
print("and highest Calinski-Harabasz score among the four algorithms.")
"""))

# ── Section 9 ────────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 9. Customer Segment Profiling

We assign human-readable segment names based on each cluster's RFM profile
relative to the overall medians:
- **Champions**: low Recency AND high Frequency AND high Monetary
- **Loyal Customers**: low Recency AND high Frequency or high Monetary
- **Potential Loyalists**: low Recency but modest F/M
- **At Risk**: high Recency (haven't purchased recently)
"""))
cells.append(new_code_cell("""rfm_final = rfm.copy()
rfm_final['Cluster'] = km_labels

cluster_profile = rfm_final.groupby('Cluster').agg(
    Count            = ('CustomerID', 'count'),
    Avg_Recency      = ('Recency',    'mean'),
    Median_Recency   = ('Recency',    'median'),
    Avg_Frequency    = ('Frequency',  'mean'),
    Median_Frequency = ('Frequency',  'median'),
    Avg_Monetary     = ('Monetary',   'mean'),
    Median_Monetary  = ('Monetary',   'median'),
).round(2)

overall_r_med = rfm_final['Recency'].median()
overall_f_med = rfm_final['Frequency'].median()
overall_m_med = rfm_final['Monetary'].median()

def assign_segment(row):
    r_low  = row['Median_Recency']   < overall_r_med
    f_high = row['Median_Frequency'] > overall_f_med
    m_high = row['Median_Monetary']  > overall_m_med
    if r_low and f_high and m_high:
        return 'Champions'
    elif (not r_low) and f_high and m_high:
        return 'At Risk'
    elif r_low and f_high:
        return 'Loyal Customers'
    elif r_low and m_high:
        return 'Loyal Customers'
    elif r_low:
        return 'Potential Loyalists'
    else:
        return 'At Risk'

cluster_profile['Segment'] = cluster_profile.apply(assign_segment, axis=1)
seen = {}
new_names = []
for idx, seg in cluster_profile['Segment'].items():
    if seg in seen:
        new_names.append(f"{seg} (C{idx})")
    else:
        seen[seg] = True
        new_names.append(seg)
cluster_profile['Segment'] = new_names
rfm_final['Segment'] = rfm_final['Cluster'].map(cluster_profile['Segment'].to_dict())
print(cluster_profile)
"""))
cells.append(new_code_cell("""# Final dashboard
fig = plt.figure(figsize=(18, 12))
gs  = gridspec.GridSpec(2, 3, figure=fig, hspace=0.4, wspace=0.35)

ax_pie = fig.add_subplot(gs[0, :])
seg_counts = rfm_final['Segment'].value_counts()
ax_pie.pie(seg_counts.values, labels=seg_counts.index,
           autopct='%1.1f%%', colors=COLORS[:len(seg_counts)],
           startangle=140, pctdistance=0.85)
ax_pie.set_title('Customer Segment Distribution', fontsize=16, fontweight='bold')

ax_r = fig.add_subplot(gs[1, 0])
ax_f = fig.add_subplot(gs[1, 1])
ax_m = fig.add_subplot(gs[1, 2])

seg_means = rfm_final.groupby('Segment')[['Recency', 'Frequency', 'Monetary']].mean()

ax_r.bar(seg_means.index, seg_means['Recency'], color=COLORS[:len(seg_means)])
ax_r.set_title('Avg Recency by Segment\\n(lower = more recent)', fontweight='bold')
ax_r.set_ylabel('Days'); ax_r.tick_params(axis='x', rotation=30)

ax_f.bar(seg_means.index, seg_means['Frequency'], color=COLORS[:len(seg_means)])
ax_f.set_title('Avg Frequency by Segment', fontweight='bold')
ax_f.set_ylabel('# Purchases'); ax_f.tick_params(axis='x', rotation=30)

ax_m.bar(seg_means.index, seg_means['Monetary'], color=COLORS[:len(seg_means)])
ax_m.set_title('Avg Monetary Value by Segment', fontweight='bold')
ax_m.set_ylabel('GBP Revenue'); ax_m.tick_params(axis='x', rotation=30)

plt.suptitle('Customer Segmentation Dashboard', fontsize=18, fontweight='bold', y=1.01)
plt.tight_layout()
plt.show()
"""))
cells.append(new_code_cell("""# Normalised RFM scores
seg_rfm = rfm_final.groupby('Segment')[['Recency', 'Frequency', 'Monetary']].mean()
seg_rfm_norm = seg_rfm.copy()
seg_rfm_norm['Recency'] = seg_rfm_norm['Recency'].max() - seg_rfm_norm['Recency']
for col in seg_rfm_norm.columns:
    rng = seg_rfm_norm[col].max() - seg_rfm_norm[col].min()
    if rng > 0:
        seg_rfm_norm[col] = (seg_rfm_norm[col] - seg_rfm_norm[col].min()) / rng

x = np.arange(len(seg_rfm_norm.columns))
width = 0.8 / len(seg_rfm_norm)
fig, ax = plt.subplots(figsize=(12, 7))
for i, (seg, row) in enumerate(seg_rfm_norm.iterrows()):
    offset = (i - len(seg_rfm_norm) / 2 + 0.5) * width
    ax.bar(x + offset, row.values, width=width,
           label=seg, color=COLORS[i % len(COLORS)], alpha=0.85)
ax.set_xticks(x)
ax.set_xticklabels(['Recency\\n(inverted)', 'Frequency', 'Monetary'])
ax.set_title('Normalised RFM Scores by Customer Segment', fontsize=14, fontweight='bold')
ax.set_ylabel('Normalised Score (0-1)')
ax.legend(title='Segment', bbox_to_anchor=(1.01, 1), loc='upper left')
plt.tight_layout()
plt.show()
"""))

# ── Section 10 ───────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("""## 10. Business Recommendations

Based on the four customer segments identified by K-Means clustering:

### Champions (Cluster 1 — ~16.5% of customers)
- **Profile**: Bought very recently, high purchase frequency, highest spend
- **Strategy**: Reward with exclusive loyalty programs; early access to new products;
  ask for reviews and referrals; upsell premium products

### Potential Loyalists (Cluster 0 — ~19.3% of customers)
- **Profile**: Recent buyers with moderate frequency and modest spend
- **Strategy**: Offer loyalty points; personalised product recommendations;
  targeted cross-sell campaigns; subscription offers to increase frequency

### At Risk (Cluster 2 — ~27.1% of customers)
- **Profile**: Moderate recency; decent frequency and monetary value historically
- **Strategy**: Win-back email campaigns; limited-time discounts; re-engagement
  surveys to understand churn reasons; personalised 'we miss you' offers

### At Risk (C3) (Cluster 3 — ~37.2% of customers)
- **Profile**: Highest recency (haven't bought recently), low frequency, low spend
- **Strategy**: Aggressive win-back campaigns; large discount offers; consider
  removing from frequent communications to reduce unsubscribe rates;
  conduct exit surveys to understand drop-off

### Key Metrics to Track
| Metric | Target |
|--------|--------|
| Segment migration rate | Champions growing month-on-month |
| Customer Lifetime Value | Increase by 15% year-on-year |
| Churn rate (At Risk) | Reduce by 20% with targeted campaigns |
| Average Order Value | Grow Potential Loyalists' AOV by 25% |
"""))

# ── Section 11 ───────────────────────────────────────────────────────────────
cells.append(new_markdown_cell("## 11. Save Model and Artifacts"))
cells.append(new_code_cell("""import joblib

joblib.dump(kmeans, 'kmeans_model.pkl')
joblib.dump(scaler, 'scaler.pkl')
rfm_final.to_csv('rfm_customers.csv', index=False)
cluster_profile.to_csv('cluster_profiles.csv')

print("Saved: kmeans_model.pkl")
print("Saved: scaler.pkl")
print("Saved: rfm_customers.csv")
print("Saved: cluster_profiles.csv")
print("\\nAll artifacts saved successfully!")
"""))

nb.cells = cells

with open(r'C:\work\DS_Project-main\DS_Project-main\Customer_Segmentation_Analysis.ipynb',
          'w', encoding='utf-8') as f:
    nbformat.write(nb, f)

print("Notebook created: Customer_Segmentation_Analysis.ipynb")
