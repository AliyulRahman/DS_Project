"""
Project: Fine-tuning FLAN-T5 for Dialogue Summarisation
=========================================================
Description:
    This script fine-tunes google/flan-t5-small on a custom dialogue-summary
    dataset (15 pairs defined inline). FLAN-T5 is an encoder-decoder Transformer
    that is instruction-tuned — it follows natural language task descriptions.

    After fine-tuning, the model summarises new dialogues. Performance is
    evaluated using ROUGE-1, ROUGE-2, and ROUGE-L scores.

    The script mirrors the approach used with the knkarthick/dialogsum dataset
    but uses self-contained data so it runs without internet access to datasets.

How to Run:
    1. Install dependencies: pip install -r requirements_16.txt
    2. Run: python finetune_flant5_dialogue.py
    3. CPU training: ~10-15 minutes for 2 epochs on a modern machine.

Key Concepts:
    - Encoder-decoder models for seq2seq tasks (unlike GPT-2 which is decoder-only)
    - Instruction-tuned models: FLAN-T5 expects task description in the prompt
    - Seq2SeqTrainer: specialised Trainer for encoder-decoder models
    - ROUGE score: recall-oriented metric for summarisation evaluation

# Installation: pip install -r requirements_16.txt
"""

import os
import sys
import json

os.environ["TOKENIZERS_PARALLELISM"] = "false"

try:
    import torch
    from transformers import (
        T5ForConditionalGeneration,
        T5Tokenizer,
        Seq2SeqTrainer,
        Seq2SeqTrainingArguments,
        DataCollatorForSeq2Seq,
        AutoTokenizer,
        AutoModelForSeq2SeqLM,
    )
    from torch.utils.data import Dataset
    from rouge_score import rouge_scorer
except ImportError as e:
    print(f"ERROR: Required library not found: {e}")
    print("Please install dependencies: pip install -r requirements_16.txt")
    sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Dataset: 15 dialogue-summary pairs (defined inline)
# ─────────────────────────────────────────────────────────────────────────────
# Format mirrors knkarthick/dialogsum structure.
# 'dialogue': multi-turn conversation
# 'summary': human-written concise summary

DIALOGUE_DATASET = [
    {
        "dialogue": "#Person1#: Hey, are you free this weekend?\n#Person2#: I think so. Why?\n#Person1#: I was thinking we could go hiking at the national park.\n#Person2#: That sounds great! What time should we meet?\n#Person1#: How about 8 AM at the trailhead? We can get breakfast on the way.\n#Person2#: Perfect. I'll bring water and snacks.\n#Person1#: Great, see you Saturday!",
        "summary": "Person1 invites Person2 for a hiking trip at the national park on Saturday morning at 8 AM. Person2 agrees and will bring water and snacks."
    },
    {
        "dialogue": "#Doctor#: Your blood test results are back. Your cholesterol is a bit high.\n#Patient#: How high? Should I be worried?\n#Doctor#: It's borderline. I recommend changing your diet first before medication.\n#Patient#: What changes should I make?\n#Doctor#: Reduce red meat, eat more vegetables and fish, and exercise at least 30 minutes daily.\n#Patient#: I'll try. Should I come back?\n#Doctor#: Yes, let's check again in three months.",
        "summary": "A doctor informs a patient about borderline high cholesterol and recommends dietary changes and exercise before medication. A follow-up appointment is scheduled in three months."
    },
    {
        "dialogue": "#Customer#: I'd like to return this jacket. I bought it last week.\n#Staff#: Is there a problem with it?\n#Customer#: It's too small. I need a larger size.\n#Staff#: Do you have the receipt?\n#Customer#: Yes, here it is.\n#Staff#: Great. We can exchange it or give you store credit. Which would you prefer?\n#Customer#: I'll take the exchange please.\n#Staff#: Let me check if we have your size in stock.",
        "summary": "A customer wants to exchange a jacket bought last week for a larger size. The staff member confirms the receipt and agrees to process an exchange pending stock availability."
    },
    {
        "dialogue": "#Teacher#: Class, we have a field trip to the science museum next Friday.\n#Student1#: Do we need permission slips?\n#Teacher#: Yes, please bring them signed by Thursday.\n#Student2#: What should we bring?\n#Teacher#: Just a packed lunch and comfortable shoes. No electronic devices.\n#Student1#: What time do we leave?\n#Teacher#: We depart at 9 AM and return by 3 PM. Don't be late!",
        "summary": "A teacher announces a science museum field trip next Friday, departing at 9 AM and returning by 3 PM. Students must bring signed permission slips by Thursday and pack their own lunch."
    },
    {
        "dialogue": "#Manager#: I wanted to discuss your project deadline.\n#Employee#: Is there a problem?\n#Manager#: The client moved the delivery date to next Monday instead of Friday.\n#Employee#: That's only two extra days. Can we get more resources?\n#Manager#: I can assign Tom to help you with testing.\n#Employee#: That would help a lot. I'll brief him tomorrow.\n#Manager#: Good. Please send me a progress update daily.",
        "summary": "A manager informs an employee that a client moved a project deadline to Monday. Tom will be assigned to assist with testing, and the employee will send daily progress updates."
    },
    {
        "dialogue": "#Person1#: Have you seen the new movie that just came out?\n#Person2#: Not yet. Is it good?\n#Person1#: It's amazing! The special effects are incredible.\n#Person2#: What genre is it?\n#Person1#: Science fiction. It's about colonising Mars.\n#Person2#: I love sci-fi. Want to go watch it together tonight?\n#Person1#: I'd love to. The 7 PM showing still has seats.\n#Person2#: Let's do it. I'll meet you at the cinema.",
        "summary": "Person1 recommends a new sci-fi film about Mars colonisation with impressive special effects. They agree to watch the 7 PM showing together at the cinema."
    },
    {
        "dialogue": "#Caller#: Hi, I'd like to book a table for dinner tonight.\n#Host#: For how many people?\n#Caller#: Four adults and one child.\n#Host#: What time were you thinking?\n#Caller#: Around 7:30 PM if possible.\n#Host#: We have availability at 7:30. Any dietary requirements?\n#Caller#: One person is vegetarian.\n#Host#: We'll make a note of that. May I take your name?\n#Caller#: Smith, please.\n#Host#: Your table is booked, Mr. Smith. See you tonight!",
        "summary": "Mr. Smith books a restaurant table for four adults and one child at 7:30 PM tonight. The host notes one vegetarian dietary requirement."
    },
    {
        "dialogue": "#Friend1#: I just got accepted to the coding bootcamp!\n#Friend2#: That's fantastic! Congratulations!\n#Friend1#: Thanks! I'm nervous though. It's very intensive.\n#Friend2#: When does it start?\n#Friend1#: Next month. It's 12 weeks full-time.\n#Friend2#: Will you have to quit your job?\n#Friend1#: Yes, but I've saved up enough. I really want to become a developer.\n#Friend2#: You'll do great. I believe in you!",
        "summary": "Friend1 shares news of being accepted into an intensive 12-week coding bootcamp starting next month, which requires quitting their job. Friend2 offers congratulations and encouragement."
    },
    {
        "dialogue": "#Landlord#: I got your message about the broken heating.\n#Tenant#: Yes, it stopped working two days ago. It's very cold.\n#Landlord#: I'm sorry about that. I'll send a technician tomorrow morning.\n#Tenant#: Can it be in the afternoon? I work mornings.\n#Landlord#: Of course. How about 2 PM?\n#Tenant#: That works perfectly.\n#Landlord#: If the part needs replacing it might take another day.\n#Tenant#: I understand. Thank you for being responsive.",
        "summary": "A tenant reports a broken heating system to the landlord. A technician is scheduled for 2 PM the following day, though a part replacement might delay the full repair by an extra day."
    },
    {
        "dialogue": "#Student1#: Are you studying for the maths exam tomorrow?\n#Student2#: Trying to. I don't understand integration.\n#Student1#: I can help! What part is confusing you?\n#Student2#: The substitution method mostly.\n#Student1#: Let's go through some examples together. Come to the library at 5.\n#Student2#: That would be great. Should I bring my notes?\n#Student1#: Yes, and your textbook. We can work through the practice problems.\n#Student2#: Thank you so much. I was really stressed.",
        "summary": "Student1 offers to help Student2 understand the integration substitution method before their maths exam. They arrange to meet at the library at 5 PM to review notes and practice problems together."
    },
    {
        "dialogue": "#Person1#: My laptop is running really slow.\n#Person2#: When did it start?\n#Person1#: After I installed that software update last week.\n#Person2#: Have you tried restarting it?\n#Person1#: Many times. Doesn't help.\n#Person2#: You should check how much storage you have left.\n#Person1#: Oh, it says only 2 GB free.\n#Person2#: That's your problem. Delete some files or move them to cloud storage.\n#Person1#: I had no idea that could cause slowdowns. Thanks!",
        "summary": "Person1's laptop has been slow since a software update. Person2 diagnoses the issue as critically low storage (2GB remaining) and recommends deleting files or using cloud storage."
    },
    {
        "dialogue": "#Chef#: Today we'll make chicken tikka masala from scratch.\n#Student#: Where do we start?\n#Chef#: First, marinate the chicken in yogurt and spices for one hour.\n#Student#: What spices do we use?\n#Chef#: Cumin, garam masala, turmeric, and chilli powder.\n#Student#: And for the sauce?\n#Chef#: Sauté onions, garlic, ginger, then add tomatoes and cream.\n#Student#: How long does the whole dish take?\n#Chef#: About 90 minutes including marinating time.",
        "summary": "A chef teaches a student to make chicken tikka masala from scratch, explaining the marinating process with spices and the preparation of a tomato-cream sauce, totalling approximately 90 minutes."
    },
    {
        "dialogue": "#Interviewer#: Thank you for coming in. Tell me about your experience.\n#Candidate#: I've spent three years as a data analyst at a fintech startup.\n#Interviewer#: What tools do you use?\n#Candidate#: Python, SQL, and Tableau mainly. Some R as well.\n#Interviewer#: Have you worked with machine learning?\n#Candidate#: Yes, I built a fraud detection model that reduced false positives by 30%.\n#Interviewer#: Impressive. Why are you looking for a change?\n#Candidate#: I want to work on larger-scale data problems.\n#Interviewer#: We'll be in touch within a week.",
        "summary": "A data analyst with 3 years of fintech experience interviews for a new role, highlighting skills in Python, SQL, and Tableau, as well as a fraud detection model achievement. The interviewer will respond within a week."
    },
    {
        "dialogue": "#Parent#: What time does your football practice end today?\n#Child#: At 5:30. Can you pick me up?\n#Parent#: I have a meeting until 5. I'll try to make it.\n#Child#: If you're late can I go to Danny's house?\n#Parent#: Sure, but text me when you get there.\n#Child#: Okay. We're playing in the tournament this Saturday too.\n#Parent#: I'll be there to cheer you on!\n#Child#: Awesome! It starts at 10 AM at the main field.",
        "summary": "A parent and child discuss pickup arrangements after football practice at 5:30 PM. The child mentions a Saturday tournament at 10 AM and the parent plans to attend."
    },
    {
        "dialogue": "#Person1#: Did you hear about the new coffee shop on Main Street?\n#Person2#: No, what's it called?\n#Person1#: Brew & Bloom. It opened last weekend.\n#Person2#: Is it good?\n#Person1#: Excellent! The cold brew is amazing and they have great vegan options.\n#Person2#: I've been looking for a good vegan-friendly place!\n#Person1#: They also have a nice outdoor seating area.\n#Person2#: Let's check it out on Saturday?\n#Person1#: Definitely, I'll meet you there at noon.",
        "summary": "Person1 tells Person2 about a new coffee shop called Brew and Bloom with excellent cold brew and vegan options. They plan to visit together on Saturday at noon."
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# Custom Dataset class for seq2seq (encoder-decoder) training
# ─────────────────────────────────────────────────────────────────────────────

class DialogueSummaryDataset(Dataset):
    """
    Dataset for dialogue summarisation.

    For FLAN-T5 (encoder-decoder), we need:
    - input_ids: tokenised input (the dialogue with instruction prefix)
    - labels: tokenised target (the summary)

    The DataCollatorForSeq2Seq will handle padding and label masking
    (setting padding label tokens to -100 so they don't contribute to the loss).
    """

    def __init__(self, data, tokenizer, max_input_length=256, max_target_length=64):
        """
        Args:
            data (list[dict]): List of {'dialogue': ..., 'summary': ...} dicts.
            tokenizer: T5Tokenizer instance.
            max_input_length (int): Max token length for input (dialogue + instruction).
            max_target_length (int): Max token length for target (summary).
        """
        self.data = data
        self.tokenizer = tokenizer
        self.max_input_length = max_input_length
        self.max_target_length = max_target_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]

        # FLAN-T5 expects a natural language instruction prefix.
        # This is the "instruction-tuned" part — the model was trained to follow
        # task descriptions provided in the prompt.
        input_text = f"summarize: {item['dialogue']}"
        target_text = item["summary"]

        # Tokenise the input (dialogue)
        # padding=False: we let the DataCollator handle padding later (more efficient)
        model_inputs = self.tokenizer(
            input_text,
            max_length=self.max_input_length,
            truncation=True,
            padding=False,
        )

        # Tokenise the target (summary)
        # text_target: tells the tokeniser this is the decoder target
        with self.tokenizer.as_target_tokenizer():
            labels = self.tokenizer(
                target_text,
                max_length=self.max_target_length,
                truncation=True,
                padding=False,
            )

        # 'labels' contains the tokenised target sequence
        # During training, the decoder receives shifted labels as input
        # and predicts the original labels as output
        model_inputs["labels"] = labels["input_ids"]

        return model_inputs


# ─────────────────────────────────────────────────────────────────────────────
# Function: Fine-tune FLAN-T5
# ─────────────────────────────────────────────────────────────────────────────

def finetune_flant5(train_data, val_data, output_dir="./flant5_dialogue_finetuned",
                    num_epochs=2):
    """
    Fine-tune google/flan-t5-small on dialogue summarisation.

    FLAN-T5 Architecture:
        - Encoder: 8 Transformer encoder layers (T5 architecture)
        - Decoder: 8 Transformer decoder layers with cross-attention
        - 77M parameters (small variant) — runs on CPU in reasonable time
        - Relative position biases instead of absolute positional encoding
        - Pre-trained on the Colossal Clean Crawled Corpus (C4)
        - Fine-tuned on FLAN: 1,800+ NLP tasks as instruction-following examples

    Args:
        train_data (list): Training dialogue-summary pairs.
        val_data (list): Validation dialogue-summary pairs.
        output_dir (str): Directory for checkpoints.
        num_epochs (int): Training epochs.

    Returns:
        tuple: (trained_model, tokenizer)
    """
    print(f"\n{'='*55}")
    print("FINE-TUNING FLAN-T5-SMALL FOR DIALOGUE SUMMARISATION")
    print(f"{'='*55}")

    model_name = "google/flan-t5-small"
    print(f"\nLoading {model_name}...")

    # AutoTokenizer and AutoModelForSeq2SeqLM automatically detect the correct
    # classes for this model (T5Tokenizer and T5ForConditionalGeneration)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_name)

    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    print(f"Device: {'GPU' if torch.cuda.is_available() else 'CPU'}")

    # Create datasets
    train_dataset = DialogueSummaryDataset(train_data, tokenizer)
    val_dataset = DialogueSummaryDataset(val_data, tokenizer)

    print(f"Training samples: {len(train_dataset)}")
    print(f"Validation samples: {len(val_dataset)}")

    # DataCollator for seq2seq:
    # - Pads input_ids and labels to the longest sequence in each batch
    # - Replaces padding token IDs in labels with -100
    #   (so padded label positions don't contribute to the cross-entropy loss)
    data_collator = DataCollatorForSeq2Seq(
        tokenizer=tokenizer,
        model=model,
        padding=True,
        label_pad_token_id=-100  # Standard: ignore padding in loss
    )

    # Seq2SeqTrainingArguments extends TrainingArguments with seq2seq-specific options
    training_args = Seq2SeqTrainingArguments(
        output_dir=output_dir,
        overwrite_output_dir=True,

        # Training
        num_train_epochs=num_epochs,
        per_device_train_batch_size=2,
        per_device_eval_batch_size=2,

        # Optimiser
        learning_rate=3e-4,                 # T5/FLAN-T5 works well with slightly higher LR
        weight_decay=0.01,
        warmup_steps=5,

        # Evaluation
        evaluation_strategy="epoch",
        logging_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",

        # Seq2Seq specific
        predict_with_generate=True,         # Use generate() for predictions (not teacher forcing)
        generation_max_length=64,           # Max tokens for generated summaries during eval

        seed=42,
        report_to="none",
    )

    # Seq2SeqTrainer: specialised for encoder-decoder models
    trainer = Seq2SeqTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
    )

    print("\nStarting fine-tuning...")
    trainer.train()

    print("Fine-tuning complete!")
    return trainer.model, tokenizer


# ─────────────────────────────────────────────────────────────────────────────
# Function: Generate summaries
# ─────────────────────────────────────────────────────────────────────────────

def generate_summary(model, tokenizer, dialogue, max_length=64):
    """
    Generate a summary for a given dialogue using the fine-tuned FLAN-T5.

    The encoder processes the full dialogue, then the decoder generates the
    summary auto-regressively using beam search.

    Args:
        model: Fine-tuned T5ForConditionalGeneration.
        tokenizer: T5Tokenizer.
        dialogue (str): Input dialogue text.
        max_length (int): Maximum summary length in tokens.

    Returns:
        str: Generated summary.
    """
    model.eval()
    device = next(model.parameters()).device

    # Format input with the same instruction prefix used during training
    input_text = f"summarize: {dialogue}"

    # Tokenise
    inputs = tokenizer(
        input_text,
        return_tensors="pt",
        max_length=256,
        truncation=True,
        padding=True
    ).to(device)

    # Generate using beam search
    with torch.no_grad():
        output_ids = model.generate(
            inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            max_length=max_length,
            num_beams=4,
            early_stopping=True,
            no_repeat_ngram_size=3,     # Prevent 3-gram repetition
            length_penalty=0.8
        )

    # Decode
    summary = tokenizer.decode(output_ids[0], skip_special_tokens=True)
    return summary


# ─────────────────────────────────────────────────────────────────────────────
# Function: Compute ROUGE scores
# ─────────────────────────────────────────────────────────────────────────────

def compute_rouge_scores(references, hypotheses):
    """
    Compute ROUGE-1, ROUGE-2, and ROUGE-L scores.

    ROUGE (Recall-Oriented Understudy for Gisting Evaluation):
    - Designed for summarisation evaluation
    - Measures what fraction of the reference is captured in the hypothesis

    ROUGE-1: Unigram overlap
        - Recall: fraction of reference words appearing in hypothesis
        - Precision: fraction of hypothesis words that appear in reference
        - F1: harmonic mean of recall and precision

    ROUGE-2: Bigram overlap
        - Captures phrase-level overlap
        - Stricter than ROUGE-1

    ROUGE-L: Longest Common Subsequence
        - Captures sentence-level word order
        - More flexible than exact n-gram matching

    Typical scores for dialogue summarisation:
        - ROUGE-1 F1: 0.30 - 0.45
        - ROUGE-2 F1: 0.10 - 0.20
        - ROUGE-L F1: 0.25 - 0.40

    Args:
        references (list[str]): Human reference summaries.
        hypotheses (list[str]): Model-generated summaries.

    Returns:
        dict: Average ROUGE-1, ROUGE-2, ROUGE-L F1 scores.
    """
    # Create scorer object for the three ROUGE metrics
    scorer = rouge_scorer.RougeScorer(
        ["rouge1", "rouge2", "rougeL"],
        use_stemmer=True  # Reduce words to root form before comparing (run→run, running→run)
    )

    # Accumulate scores across all sentence pairs
    total_scores = {"rouge1": 0.0, "rouge2": 0.0, "rougeL": 0.0}

    for ref, hyp in zip(references, hypotheses):
        scores = scorer.score(ref, hyp)
        for key in total_scores:
            # .fmeasure gives the F1 score (balances recall and precision)
            total_scores[key] += scores[key].fmeasure

    # Average over all pairs
    n = len(references)
    avg_scores = {key: total_scores[key] / n for key in total_scores}

    return avg_scores


# ─────────────────────────────────────────────────────────────────────────────
# Main function
# ─────────────────────────────────────────────────────────────────────────────

def main():
    """
    Complete pipeline: fine-tune FLAN-T5 → generate summaries → evaluate → save.
    """
    print("=" * 60)
    print("FLAN-T5 FINE-TUNING: DIALOGUE SUMMARISATION")
    print("=" * 60)
    print(f"Dataset: {len(DIALOGUE_DATASET)} dialogue-summary pairs (built-in)")
    print("Model: google/flan-t5-small (77M parameters)")

    # ── Step 1: Split data ───────────────────────────────────────────────────
    split_idx = int(0.8 * len(DIALOGUE_DATASET))
    train_data = DIALOGUE_DATASET[:split_idx]
    val_data = DIALOGUE_DATASET[split_idx:]
    print(f"\nSplit: {len(train_data)} train / {len(val_data)} validation")

    # ── Step 2: Fine-tune ────────────────────────────────────────────────────
    print("\n[STEP 2] Fine-tuning FLAN-T5-small for 2 epochs...")
    try:
        model, tokenizer = finetune_flant5(
            train_data,
            val_data,
            output_dir="./flant5_dialogue_checkpoints",
            num_epochs=2
        )
    except Exception as e:
        print(f"Fine-tuning error: {e}")
        print("Loading base FLAN-T5-small as fallback...")
        tokenizer = AutoTokenizer.from_pretrained("google/flan-t5-small")
        model = AutoModelForSeq2SeqLM.from_pretrained("google/flan-t5-small")

    # ── Step 3: Generate summaries for validation set ────────────────────────
    print("\n[STEP 3] Generating summaries for validation dialogues...")

    generated_summaries = []
    reference_summaries = [item["summary"] for item in val_data]

    for i, item in enumerate(val_data):
        try:
            summary = generate_summary(model, tokenizer, item["dialogue"])
            generated_summaries.append(summary)

            print(f"\nDialogue {i+1}:")
            # Show first 150 chars of dialogue
            dialogue_preview = item["dialogue"][:150] + "..."
            print(f"  Dialogue: {dialogue_preview}")
            print(f"  Reference: {item['summary']}")
            print(f"  Generated: {summary}")
        except Exception as e:
            print(f"Error generating summary for dialogue {i+1}: {e}")
            generated_summaries.append("")

    # ── Step 4: Compute ROUGE scores ─────────────────────────────────────────
    print("\n[STEP 4] Computing ROUGE scores...")

    # Filter out any empty generated summaries
    valid_pairs = [(ref, hyp) for ref, hyp in zip(reference_summaries, generated_summaries)
                   if hyp.strip()]

    if valid_pairs:
        refs, hyps = zip(*valid_pairs)
        try:
            rouge_scores = compute_rouge_scores(list(refs), list(hyps))

            print(f"\n{'='*50}")
            print("ROUGE EVALUATION RESULTS")
            print(f"{'='*50}")
            print(f"ROUGE-1 F1: {rouge_scores['rouge1']:.4f}  "
                  f"({rouge_scores['rouge1']:.1%} unigram overlap)")
            print(f"ROUGE-2 F1: {rouge_scores['rouge2']:.4f}  "
                  f"({rouge_scores['rouge2']:.1%} bigram overlap)")
            print(f"ROUGE-L F1: {rouge_scores['rougeL']:.4f}  "
                  f"({rouge_scores['rougeL']:.1%} longest common subsequence)")
            print(f"\nNote: Higher scores indicate better alignment with human summaries.")
            print(f"Typical range for dialogue summarisation: ROUGE-1 ≈ 0.30-0.45")
        except Exception as e:
            print(f"ROUGE computation error: {e}")

    # ── Step 5: Save model ───────────────────────────────────────────────────
    print("\n[STEP 5] Saving fine-tuned model...")
    save_dir = "./flant5_dialogue_final"
    try:
        os.makedirs(save_dir, exist_ok=True)
        model.save_pretrained(save_dir)
        tokenizer.save_pretrained(save_dir)
        print(f"Model saved to: {save_dir}")
    except Exception as e:
        print(f"Save error: {e}")

    print("\n" + "=" * 60)
    print("FLAN-T5 fine-tuning pipeline complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
