"""
GPT-2 Fine-tuning on Indian Food Recipes
Demonstrates the full fine-tuning pipeline: data prep, tokenisation, training, generation, BLEU eval.
Run: pip install transformers torch nltk
     python finetune_gpt2_recipes.py
"""

import torch
import subprocess
import sys

for pkg in ['transformers', 'torch', 'nltk']:
    subprocess.run([sys.executable, '-m', 'pip', 'install', pkg, '-q'], check=True)

import nltk
nltk.download('punkt', quiet=True)

from transformers import GPT2LMHeadModel, GPT2Tokenizer
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
import random
import numpy as np

random.seed(42)
torch.manual_seed(42)
np.random.seed(42)

# ── 10 Sample Indian Food Recipes ──
RECIPES = [
    """Recipe: Butter Chicken
Ingredients: chicken 500g, butter 3tbsp, tomato puree 1 cup, cream 100ml, garam masala 1tsp, ginger garlic paste 2tbsp
Instructions: Marinate chicken with spices. Cook in butter until golden. Add tomato puree and simmer 15 minutes. Stir in cream. Serve with naan.""",

    """Recipe: Dal Tadka
Ingredients: yellow lentils 1 cup, onion 1, tomato 2, cumin seeds 1tsp, garlic 4 cloves, turmeric 1/2 tsp, ghee 2tbsp
Instructions: Boil lentils until soft. Fry cumin and garlic in ghee. Add onions and tomatoes. Mix with lentils. Simmer 10 minutes.""",

    """Recipe: Palak Paneer
Ingredients: spinach 400g, paneer 200g, onion 1, cream 50ml, cumin 1tsp, garam masala 1tsp, garlic 3 cloves
Instructions: Blanch spinach and blend smooth. Fry paneer golden. Cook onion and garlic in oil. Add spinach paste and spices. Add paneer and cream.""",

    """Recipe: Biryani
Ingredients: basmati rice 2 cups, chicken 500g, onion 2, yogurt 1 cup, saffron pinch, whole spices, ghee 4tbsp
Instructions: Marinate chicken with yogurt and spices. Parboil rice. Layer chicken and rice in pot. Cook on dum 30 minutes.""",

    """Recipe: Masala Chai
Ingredients: tea leaves 2tsp, milk 1 cup, water 1 cup, ginger 1 inch, cardamom 3 pods, cinnamon stick 1, sugar to taste
Instructions: Boil water with spices and ginger 3 minutes. Add tea leaves and milk. Simmer 5 minutes. Strain and sweeten.""",

    """Recipe: Paneer Tikka
Ingredients: paneer 300g, yogurt 1 cup, red chilli 1tsp, turmeric 1/2 tsp, cumin powder 1tsp, lemon juice 2tbsp, bell peppers
Instructions: Mix yogurt with spices for marinade. Coat paneer and vegetables. Refrigerate 1 hour. Grill or bake until charred.""",

    """Recipe: Aloo Gobi
Ingredients: potato 3, cauliflower 1 head, onion 1, tomato 2, turmeric 1/2 tsp, cumin 1tsp, coriander powder 2tsp
Instructions: Fry cumin in oil. Add onions until golden. Add potatoes and cauliflower. Season with spices. Cook covered 20 minutes.""",

    """Recipe: Samosa
Ingredients: flour 2 cups, potato 3 boiled, peas 1/2 cup, cumin seeds, coriander, chilli, oil for frying
Instructions: Make dough. Cook potato and pea filling with spices. Fold dough into cones and fill. Seal and deep fry golden.""",

    """Recipe: Gulab Jamun
Ingredients: milk powder 1 cup, flour 3tbsp, ghee 2tbsp, baking soda pinch, sugar 2 cups, water 1 cup, cardamom, rose water
Instructions: Mix milk powder, flour and ghee. Add water to form soft dough. Shape into balls. Deep fry on low heat. Soak in sugar syrup.""",

    """Recipe: Raita
Ingredients: yogurt 2 cups, cucumber 1 grated, mint leaves handful, cumin powder 1/2 tsp, salt, black pepper
Instructions: Whisk yogurt smooth. Squeeze water from grated cucumber. Mix cucumber and mint into yogurt. Season with spices. Chill before serving.""",
]


class RecipeDataset(Dataset):
    def __init__(self, texts, tokenizer, max_length=256):
        self.encodings = tokenizer(
            texts,
            truncation=True,
            padding='max_length',
            max_length=max_length,
            return_tensors='pt'
        )

    def __len__(self):
        return len(self.encodings['input_ids'])

    def __getitem__(self, idx):
        input_ids = self.encodings['input_ids'][idx]
        return {'input_ids': input_ids, 'labels': input_ids.clone()}


def train_model(model, dataloader, optimizer, device, epochs=2):
    model.train()
    for epoch in range(epochs):
        total_loss = 0
        for batch in dataloader:
            input_ids = batch['input_ids'].to(device)
            labels    = batch['labels'].to(device)

            optimizer.zero_grad()
            outputs = model(input_ids=input_ids, labels=labels)
            loss = outputs.loss
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(dataloader)
        print(f"  Epoch {epoch+1}/{epochs} — Average Loss: {avg_loss:.4f}")


def generate_recipe(model, tokenizer, prompt, max_new_tokens=100, device='cpu'):
    model.eval()
    inputs = tokenizer(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        outputs = model.generate(
            inputs['input_ids'],
            max_new_tokens=max_new_tokens,
            do_sample=True,
            temperature=0.8,
            top_p=0.92,
            pad_token_id=tokenizer.eos_token_id
        )
    return tokenizer.decode(outputs[0], skip_special_tokens=True)


def main():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")
    print("
Loading GPT-2 model and tokenizer...")

    tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
    tokenizer.pad_token = tokenizer.eos_token

    model = GPT2LMHeadModel.from_pretrained('gpt2')
    model.to(device)

    total_params = sum(p.numel() for p in model.parameters())
    print(f"GPT-2 parameters: {total_params:,}")

    # ── Dataset & DataLoader ──
    dataset    = RecipeDataset(RECIPES, tokenizer)
    dataloader = DataLoader(dataset, batch_size=2, shuffle=True)
    print(f"Dataset: {len(dataset)} recipes")

    # ── Optimizer ──
    optimizer = AdamW(model.parameters(), lr=5e-5, weight_decay=0.01)

    # ── Train ──
    print("
Fine-tuning GPT-2 on Indian food recipes (2 epochs)...")
    train_model(model, dataloader, optimizer, device, epochs=2)

    # ── Generate ──
    print("
--- Generated Recipes After Fine-tuning ---")
    prompts = [
        "Recipe: Chicken Curry
Ingredients:",
        "Recipe: Vegetable Biryani
Ingredients:",
        "Recipe: Mango Lassi
Ingredients:",
    ]
    for prompt in prompts:
        generated = generate_recipe(model, tokenizer, prompt, device=device)
        print(f"
Prompt: {prompt}")
        print(f"Generated: {generated[:300]}...")
        print("-" * 60)

    # ── BLEU Evaluation ──
    print("
--- BLEU Score Evaluation ---")
    smoother = SmoothingFunction().method1
    reference = RECIPES[0].split()

    test_generation = generate_recipe(
        model, tokenizer, "Recipe: Butter Chicken
Ingredients:", device=device
    )
    hypothesis = test_generation.split()

    bleu = sentence_bleu([reference], hypothesis, smoothing_function=smoother)
    print(f"BLEU score (generated vs original Butter Chicken recipe): {bleu:.4f}")
    print("Note: Low BLEU is expected — model generates plausible NEW content, not copies.")


if __name__ == "__main__":
    main()
