"""
Demonstrates BLEU and ROUGE scores with detailed examples.
Run: pip install nltk rouge-score
     python evaluate_bleu_rouge.py
"""

import subprocess
import sys

# Ensure dependencies
for pkg in ['nltk', 'rouge-score']:
    subprocess.run([sys.executable, '-m', 'pip', 'install', pkg, '-q'], check=True)

import nltk
nltk.download('punkt', quiet=True)
from nltk.translate.bleu_score import sentence_bleu, corpus_bleu, SmoothingFunction
from rouge_score import rouge_scorer


def compute_bleu(reference_tokens, hypothesis_tokens):
    """Compute sentence BLEU with smoothing."""
    smoother = SmoothingFunction().method1
    score = sentence_bleu([reference_tokens], hypothesis_tokens,
                          smoothing_function=smoother)
    return score


def compute_rouge(reference_text, hypothesis_text):
    """Compute ROUGE-1, ROUGE-2, ROUGE-L F1 scores."""
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'],
                                      use_stemmer=True)
    scores = scorer.score(reference_text, hypothesis_text)
    return scores


def main():
    print("=" * 65)
    print("BLEU and ROUGE Score Demonstration")
    print("=" * 65)

    # ── BLEU Examples ──
    print("
--- BLEU Score Examples ---")

    reference = ['the', 'cat', 'sat', 'on', 'the', 'mat']
    examples = [
        (['the', 'cat', 'sat', 'on', 'the', 'mat'],
         "Perfect match — identical to reference"),
        (['the', 'cat', 'is', 'on', 'the', 'mat'],
         "1 word different ('is' vs 'sat')"),
        (['the', 'cat', 'sat', 'near', 'the', 'mat'],
         "1 word different ('near' vs 'on')"),
        (['a', 'dog', 'ran', 'in', 'the', 'park'],
         "Very different — low overlap"),
        (['cat', 'mat'],
         "Too short — brevity penalty applied"),
    ]

    print(f"
Reference: {' '.join(reference)}
")
    print(f"{'Hypothesis':45s} {'BLEU':8s}  Description")
    print("-" * 80)
    for hyp, desc in examples:
        bleu = compute_bleu(reference, hyp)
        print(f"{' '.join(hyp):45s} {bleu:.4f}    {desc}")

    # ── ROUGE Examples ──
    print("
--- ROUGE Score Examples ---")

    reference_text = (
        "The transformer architecture has revolutionised natural language processing "
        "by enabling models to process sequences in parallel using attention mechanisms."
    )

    hypotheses = [
        ("The transformer architecture has revolutionised natural language processing "
         "by enabling models to process sequences in parallel using attention mechanisms.",
         "Perfect: identical to reference"),

        ("Transformers have changed NLP by using attention to process text in parallel.",
         "Good paraphrase: captures key concepts with different words"),

        ("The cat sat on the mat and enjoyed the warm sunshine.",
         "Completely unrelated content"),

        ("The transformer model uses attention mechanisms for language.",
         "Partial: mentions some key terms but much shorter"),
    ]

    print(f"
Reference:
  {reference_text}
")
    print(f"{'Hypothesis (first 55 chars)':57s} {'R1-F1':7s} {'R2-F1':7s} {'RL-F1':7s}  Description")
    print("-" * 105)
    for hyp, desc in hypotheses:
        scores = compute_rouge(reference_text, hyp)
        r1 = scores['rouge1'].fmeasure
        r2 = scores['rouge2'].fmeasure
        rl = scores['rougeL'].fmeasure
        print(f"{hyp[:55]:57s} {r1:.3f}   {r2:.3f}   {rl:.3f}    {desc}")

    # ── Interpretation guide ──
    print("
" + "=" * 65)
    print("Interpretation Guide")
    print("=" * 65)
    print("
BLEU:")
    print("  1.0  = Perfect match (identical to reference)")
    print("  0.7+ = Excellent (near-human translation quality)")
    print("  0.4+ = Good machine translation")
    print("  0.2+ = Passable")
    print("  <0.2 = Poor quality")
    print("
ROUGE-1 F1 (for summarisation):")
    print("  0.5+ = Excellent summarisation")
    print("  0.4+ = Good summarisation")
    print("  0.3+ = Fair")
    print("  <0.2 = Poor — significant content missing or off-topic")
    print("
Note: BLEU emphasises PRECISION (quality of n-grams generated)")
    print("      ROUGE emphasises RECALL  (coverage of reference content)")


if __name__ == "__main__":
    main()
