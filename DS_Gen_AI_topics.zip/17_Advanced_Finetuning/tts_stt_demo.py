"""
Project: Text-to-Speech (TTS) and Speech-to-Text (STT) with Hugging Face
==========================================================================
Description:
    This script demonstrates speech pipeline integration using Hugging Face:

    1. Speech-to-Text (STT): OpenAI Whisper transcribes audio to text
    2. Text-to-Speech (TTS): SpeechT5 converts text to spoken audio
    3. Full round-trip pipeline: text → speech → text (STT)

    The script includes graceful fallbacks for systems without audio libraries,
    allowing conceptual demonstration even without microphone/speakers.

How to Run:
    1. Install dependencies: pip install -r requirements_17.txt
    2. Optional audio libraries: pip install soundfile librosa
    3. Run: python tts_stt_demo.py
    4. Whisper model (~150MB) and SpeechT5 (~330MB) download on first run.

Models Used:
    - STT: openai/whisper-tiny (39M params, fastest Whisper model)
    - TTS: microsoft/speecht5_tts (encoder-decoder for TTS)
    - TTS vocoder: microsoft/speecht5_hifigan (converts spectrograms to audio)

Key Concepts:
    - Whisper: encoder-decoder Transformer trained on 680K hours of audio
    - SpeechT5: unified pre-training for speech/text tasks
    - Audio pipeline: waveform → mel spectrogram → tokens → text (STT)
    - Audio pipeline: text → tokens → mel spectrogram → waveform (TTS)

# Installation: pip install -r requirements_17.txt
"""

import os
import sys
import tempfile

os.environ["TOKENIZERS_PARALLELISM"] = "false"

try:
    import torch
    from transformers import pipeline, AutoProcessor, AutoModelForSpeechSeq2Seq
except ImportError as e:
    print(f"ERROR: Required library not found: {e}")
    print("Please install: pip install -r requirements_17.txt")
    sys.exit(1)

# Optional imports for audio I/O
try:
    import soundfile as sf
    import numpy as np
    AUDIO_AVAILABLE = True
except ImportError:
    AUDIO_AVAILABLE = False

# Optional import for TTS
try:
    from transformers import SpeechT5Processor, SpeechT5ForTextToSpeech, SpeechT5HifiGan
    from datasets import load_dataset
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# Speech-to-Text with Whisper
# ─────────────────────────────────────────────────────────────────────────────

def demo_whisper_stt(audio_path=None):
    """
    Demonstrate Speech-to-Text using OpenAI Whisper.

    Whisper Architecture:
        - Encoder-Decoder Transformer
        - Encoder: processes 30-second audio chunks as log-mel spectrograms
          (80 mel frequency bins)
        - Decoder: generates transcribed text auto-regressively
        - Trained on 680,000 hours of multilingual audio from the web
        - Automatically detects language

    Whisper Models (speed vs accuracy trade-off):
        - whisper-tiny (39M params): fastest, ~32x real-time on CPU
        - whisper-base (74M params): 2x slower, better accuracy
        - whisper-small (244M params): 4x slower, good for most use cases
        - whisper-medium (769M params): high accuracy
        - whisper-large-v3 (1.5B params): best accuracy

    Args:
        audio_path (str or None): Path to an audio file (.wav, .mp3, .flac).
                                  If None, a synthetic demo is used.

    Returns:
        str: Transcribed text (or description if no audio available).
    """
    print("\n" + "=" * 60)
    print("SPEECH-TO-TEXT (STT) — OpenAI Whisper")
    print("=" * 60)
    print()
    print("Whisper Architecture:")
    print("  Audio → Mel Spectrogram → Transformer Encoder → Decoder → Text")
    print("  Trained on 680,000 hours of multilingual audio")
    print("  Supports 99 languages with automatic language detection")
    print()

    model_name = "openai/whisper-tiny"
    print(f"Loading model: {model_name}...")

    device = 0 if torch.cuda.is_available() else -1

    try:
        # Create Whisper STT pipeline
        # 'automatic-speech-recognition' task uses Whisper's full encoder-decoder
        asr_pipeline = pipeline(
            "automatic-speech-recognition",
            model=model_name,
            device=device,
            chunk_length_s=30,    # Process audio in 30-second chunks
            return_timestamps=True  # Return word-level timestamps
        )
        print("Whisper model loaded successfully.")

        if audio_path and os.path.exists(audio_path):
            # Transcribe a real audio file
            print(f"\nTranscribing: {audio_path}")
            result = asr_pipeline(audio_path)
            transcription = result["text"]
            print(f"Transcription: {transcription}")

            # Show timestamps if available
            if "chunks" in result and result["chunks"]:
                print("\nWord-level timestamps:")
                for chunk in result["chunks"][:5]:  # Show first 5 words
                    print(f"  [{chunk['timestamp'][0]:.1f}s - {chunk['timestamp'][1]:.1f}s]: "
                          f"{chunk['text']}")
        else:
            # Demonstrate with a synthetic short audio tone (if numpy/soundfile available)
            if AUDIO_AVAILABLE:
                print("\nNo audio file provided — generating a short synthetic tone...")
                print("(For real transcription, pass an audio file path)")

                # Create a very short synthetic audio signal (1 second, 16kHz)
                sample_rate = 16000
                duration = 1.0
                t = np.linspace(0, duration, int(sample_rate * duration))
                # Sine wave — not speech, but demonstrates the pipeline API
                synthetic_audio = 0.5 * np.sin(2 * np.pi * 440 * t).astype(np.float32)

                # Save temporarily
                temp_file = os.path.join(tempfile.gettempdir(), "synthetic_tone.wav")
                sf.write(temp_file, synthetic_audio, sample_rate)

                print(f"Synthetic audio saved to: {temp_file}")
                print("Running Whisper on synthetic tone...")
                result = asr_pipeline(temp_file)
                print(f"Transcription output: '{result['text']}' (empty/noise expected for tone)")

                print("\nTo transcribe real speech, provide: asr_pipeline('path/to/audio.wav')")
            else:
                print("\nAudio libraries not available (soundfile/librosa).")
                print("To use with real audio:")
                print("  pip install soundfile librosa")
                print("  pipe = pipeline('automatic-speech-recognition', model='openai/whisper-tiny')")
                print("  result = pipe('your_audio.wav')")
                print("  print(result['text'])")
                return "STT demo (no audio): Whisper loaded successfully. Pass audio file for transcription."

        return transcription if audio_path else "Whisper pipeline operational."

    except Exception as e:
        print(f"Whisper error: {e}")
        return f"[Error: {e}]"


# ─────────────────────────────────────────────────────────────────────────────
# Text-to-Speech with SpeechT5
# ─────────────────────────────────────────────────────────────────────────────

def demo_speecht5_tts(text_to_speak=None):
    """
    Demonstrate Text-to-Speech using Microsoft SpeechT5.

    SpeechT5 Architecture:
        - Unified sequence-to-sequence model for speech and text
        - Encoder: processes text tokens
        - Decoder: generates log-mel spectrograms
        - Vocoder (HifiGAN): converts spectrograms to audio waveforms
        - Pre-trained on LibriSpeech and LibriTTS datasets

    Pipeline: text → tokeniser → encoder → decoder → mel spectrogram → HifiGAN → waveform

    Args:
        text_to_speak (str): Text to convert to speech.
                             If None, uses a default sentence.

    Returns:
        str: Path to saved audio file, or status message.
    """
    print("\n" + "=" * 60)
    print("TEXT-TO-SPEECH (TTS) — Microsoft SpeechT5")
    print("=" * 60)
    print()
    print("SpeechT5 Pipeline:")
    print("  Text → Tokeniser → Encoder → Decoder → Mel Spectrogram")
    print("                                              ↓")
    print("                                        HifiGAN Vocoder")
    print("                                              ↓")
    print("                                        Audio Waveform (.wav)")
    print()

    if text_to_speak is None:
        text_to_speak = "Hello, this is a demonstration of text to speech using the SpeechT5 model from Microsoft."

    if not TTS_AVAILABLE or not AUDIO_AVAILABLE:
        print("TTS libraries not fully available. Demonstrating conceptually:")
        print(f"\nInput text: '{text_to_speak}'")
        print("\nTTS Pipeline (conceptual):")
        print("  1. Tokenise: 'Hello' → [8774]")
        print("  2. Encoder: token IDs → contextual embeddings (512-dim)")
        print("  3. Decoder: embeddings → mel spectrogram (80 freq bins × T frames)")
        print("  4. HifiGAN vocoder: mel spectrogram → audio waveform (22050 Hz)")
        print("  5. Save: waveform → .wav file")
        print("\nTo enable: pip install transformers soundfile datasets")
        return "TTS conceptual demo complete."

    try:
        print(f"Input text: '{text_to_speak}'")
        print(f"\nLoading SpeechT5 model...")

        # Load processor and model
        processor = SpeechT5Processor.from_pretrained("microsoft/speecht5_tts")
        model_tts = SpeechT5ForTextToSpeech.from_pretrained("microsoft/speecht5_tts")
        vocoder = SpeechT5HifiGan.from_pretrained("microsoft/speecht5_hifigan")

        model_tts.eval()
        vocoder.eval()

        print("Models loaded. Generating speech...")

        # Tokenise text input
        inputs = processor(text=text_to_speak, return_tensors="pt")

        # Load speaker embeddings from a dataset
        # Speaker embeddings provide voice characteristics (pitch, timbre)
        # Using a pre-computed speaker embedding for natural-sounding TTS
        print("Loading speaker embeddings...")
        embeddings_dataset = load_dataset(
            "Matthijs/cmu-arctic-xvectors",
            split="validation"
        )
        # Select speaker with index 7306 (clear male voice)
        speaker_embeddings = torch.tensor(
            embeddings_dataset[7306]["xvector"]
        ).unsqueeze(0)  # Add batch dimension

        # Generate speech
        with torch.no_grad():
            speech = model_tts.generate_speech(
                inputs["input_ids"],
                speaker_embeddings,
                vocoder=vocoder
            )

        # Save to .wav file
        output_path = "tts_output.wav"
        sf.write(output_path, speech.numpy(), samplerate=16000)
        print(f"\nSpeech saved to: {os.path.abspath(output_path)}")
        print(f"Duration: {len(speech) / 16000:.2f} seconds")
        print(f"Sample rate: 16000 Hz")
        print(f"Samples: {len(speech):,}")

        return output_path

    except Exception as e:
        print(f"TTS error: {e}")
        print("\nConceptual TTS pipeline:")
        print("  1. processor(text) → tokenised input_ids")
        print("  2. model.generate_speech(input_ids, speaker_embeddings, vocoder)")
        print("  3. soundfile.write('output.wav', speech, samplerate=16000)")
        return f"[TTS Error: {e}]"


# ─────────────────────────────────────────────────────────────────────────────
# Full round-trip pipeline: Text → Speech → Text
# ─────────────────────────────────────────────────────────────────────────────

def demo_full_pipeline():
    """
    Demonstrate the complete text → speech → text round-trip pipeline.

    This pipeline demonstrates:
    1. GPT-2 generates text
    2. SpeechT5 converts text to speech (.wav)
    3. Whisper transcribes the speech back to text
    4. Comparison: original text vs round-trip text

    This is a powerful demonstration of multi-modal AI integration:
    all three models (GPT-2, SpeechT5, Whisper) are Transformer-based
    and accessible via the same Hugging Face API.
    """
    print("\n" + "=" * 60)
    print("FULL PIPELINE: TEXT → SPEECH → TEXT (Round-trip)")
    print("=" * 60)
    print()

    # The text we'll use for the round-trip
    original_text = "Artificial intelligence is transforming the world."
    print(f"Step 1 — Original text:")
    print(f"  \"{original_text}\"")

    # Step 2: TTS
    print(f"\nStep 2 — Converting text to speech (TTS)...")
    audio_path = demo_speecht5_tts(original_text)
    print(f"  Audio output: {audio_path}")

    # Step 3: STT
    print(f"\nStep 3 — Transcribing speech back to text (STT)...")

    if isinstance(audio_path, str) and os.path.exists(audio_path):
        transcribed = demo_whisper_stt(audio_path)
    else:
        print("  (Audio file not available — skipping STT)")
        transcribed = "[Audio file not available]"

    # Step 4: Comparison
    print(f"\nStep 4 — Round-trip comparison:")
    print(f"  Original text:       \"{original_text}\"")
    print(f"  Round-trip text:     \"{transcribed}\"")

    # Simple word-level comparison
    if transcribed and transcribed not in ["[Audio file not available]"]:
        orig_words = set(original_text.lower().replace(".", "").split())
        trans_words = set(transcribed.lower().replace(".", "").split())
        if orig_words:
            overlap = len(orig_words & trans_words) / len(orig_words)
            print(f"  Word overlap:        {overlap:.0%}")
            if overlap > 0.8:
                print("  Result: Excellent round-trip fidelity!")
            elif overlap > 0.5:
                print("  Result: Good round-trip — minor variations expected.")
            else:
                print("  Result: Some degradation — this is normal for short clips.")


# ─────────────────────────────────────────────────────────────────────────────
# Model comparison summary
# ─────────────────────────────────────────────────────────────────────────────

def print_model_comparison():
    """Print a comparison of available STT and TTS models on Hugging Face."""
    print("\n" + "=" * 60)
    print("SPEECH MODELS AVAILABLE ON HUGGING FACE")
    print("=" * 60)
    print()
    print("SPEECH-TO-TEXT (STT) Models:")
    print(f"  {'Model':<35} {'Params':>8}  {'Speed':>8}  Notes")
    print(f"  {'─'*65}")
    models_stt = [
        ("openai/whisper-tiny",         "39M",   "~32x RT", "Fastest, good for demos"),
        ("openai/whisper-base",          "74M",   "~16x RT", "Balanced speed/accuracy"),
        ("openai/whisper-small",         "244M",  "~6x RT",  "Recommended for most tasks"),
        ("openai/whisper-medium",        "769M",  "~2x RT",  "High accuracy"),
        ("openai/whisper-large-v3",      "1.5B",  "~1x RT",  "Best accuracy, 99 languages"),
        ("facebook/wav2vec2-base-960h",  "95M",   "Fast",    "English only, lightweight"),
    ]
    for name, params, speed, notes in models_stt:
        print(f"  {name:<35} {params:>8}  {speed:>8}  {notes}")

    print()
    print("TEXT-TO-SPEECH (TTS) Models:")
    print(f"  {'Model':<40} {'Notes'}")
    print(f"  {'─'*65}")
    models_tts = [
        ("microsoft/speecht5_tts",        "Speaker-conditioned, needs embeddings"),
        ("suno/bark",                     "Very natural, multilingual, slow"),
        ("facebook/fastspeech2-en-200_speaker",  "Fast, multi-speaker English"),
        ("espnet/kan-bayashi_ljspeech_vits",      "VITS: end-to-end, very natural"),
    ]
    for name, notes in models_tts:
        print(f"  {name:<40} {notes}")


# ─────────────────────────────────────────────────────────────────────────────
# Main function
# ─────────────────────────────────────────────────────────────────────────────

def main():
    """
    Demonstrate TTS, STT, and the complete text→speech→text pipeline.
    """
    print("=" * 60)
    print("TEXT-TO-SPEECH & SPEECH-TO-TEXT DEMO")
    print("Using Hugging Face Transformers (Whisper + SpeechT5)")
    print("=" * 60)

    print(f"\nAudio libraries available: {'YES (soundfile)' if AUDIO_AVAILABLE else 'NO — install soundfile'}")
    print(f"TTS libraries available:   {'YES (SpeechT5 + datasets)' if TTS_AVAILABLE else 'NO — see note below'}")

    if not AUDIO_AVAILABLE:
        print("\nNote: For full audio functionality, install:")
        print("  pip install soundfile librosa")

    # ── Demo 1: Speech-to-Text (Whisper) ─────────────────────────────────────
    print("\n[DEMO 1] Speech-to-Text with OpenAI Whisper")
    print("(Pass an audio file path to demo_whisper_stt() for real transcription)")
    demo_whisper_stt(audio_path=None)

    # ── Demo 2: Text-to-Speech (SpeechT5) ────────────────────────────────────
    print("\n[DEMO 2] Text-to-Speech with Microsoft SpeechT5")
    demo_speecht5_tts(
        text_to_speak="Machine learning is a fascinating field that combines mathematics and programming."
    )

    # ── Demo 3: Full round-trip pipeline ─────────────────────────────────────
    print("\n[DEMO 3] Full Round-Trip: Text → Speech → Text")
    demo_full_pipeline()

    # ── Reference table ───────────────────────────────────────────────────────
    print_model_comparison()

    print("\n" + "=" * 60)
    print("TTS/STT demonstration complete!")
    print()
    print("Next steps:")
    print("  1. Provide a real .wav file to demo_whisper_stt() for transcription")
    print("  2. Combine with GPT-2 for: voice input → AI response → voice output")
    print("  3. Try whisper-small for better accuracy on real audio")
    print("=" * 60)


if __name__ == "__main__":
    main()
