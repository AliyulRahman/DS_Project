"""
Conditional Text Generation — Temperature, Top-k, Top-p Effects on GPT-2
Run: pip install transformers torch
     python conditional_text_generation.py
"""

import subprocess
import sys

for pkg in ['transformers', 'torch']:
    subprocess.run([sys.executable, '-m', 'pip', 'install', pkg, '-q'], check=True)

import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer

print("Loading GPT-2...")
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
model     = GPT2LMHeadModel.from_pretrained('gpt2')
model.eval()

device = 'cuda' if torch.cuda.is_available() else 'cpu'
model.to(device)


def generate(prompt, max_new_tokens=80, temperature=1.0, top_k=0, top_p=1.0,
             do_sample=True, label=""):
    """Generate text with specified sampling parameters."""
    inputs = tokenizer(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        output = model.generate(
            inputs['input_ids'],
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_k=top_k if top_k > 0 else None,
            top_p=top_p,
            do_sample=do_sample,
            pad_token_id=tokenizer.eos_token_id,
        )
    text = tokenizer.decode(output[0], skip_special_tokens=True)
    return text[len(prompt):].strip()


prompts = [
    "The scientist discovered an unusual phenomenon when she",
    "In the year 2050, humans and robots",
]

print("
" + "=" * 70)
print("Conditional Text Generation: Effect of Sampling Parameters on GPT-2")
print("=" * 70)

for prompt in prompts:
    print(f"
{'='*70}")
    print(f"PROMPT: "{prompt}"")
    print("=" * 70)

    # Temperature experiments
    print("
--- Temperature Effect (Top-p=1.0, Top-k=0) ---")
    temp_settings = [
        (0.1, "Very low (0.1): deterministic, conservative, repetitive"),
        (0.7, "Medium  (0.7): balanced creativity and coherence"),
        (1.5, "High    (1.5): creative, diverse, may be incoherent"),
    ]
    for temp, desc in temp_settings:
        result = generate(prompt, temperature=temp, do_sample=True)
        print(f"
  Temp={temp} ({desc}):")
        print(f"  "{result[:180]}"")

    # Top-k experiments
    print("
--- Top-k Effect (temp=1.0, Top-p=1.0) ---")
    topk_settings = [
        (5,   "Top-k=5:   only top 5 tokens, conservative"),
        (50,  "Top-k=50:  moderate diversity"),
        (200, "Top-k=200: high diversity"),
    ]
    for k, desc in topk_settings:
        result = generate(prompt, temperature=1.0, top_k=k, do_sample=True)
        print(f"
  {desc}:")
        print(f"  "{result[:180]}"")

    # Top-p experiments
    print("
--- Top-p (Nucleus) Effect (temp=1.0, Top-k=0) ---")
    topp_settings = [
        (0.5, "Top-p=0.5: small nucleus, safe and focused"),
        (0.9, "Top-p=0.9: standard nucleus sampling"),
        (1.0, "Top-p=1.0: no nucleus restriction (all tokens eligible)"),
    ]
    for p, desc in topp_settings:
        result = generate(prompt, temperature=1.0, top_p=p, do_sample=True)
        print(f"
  {desc}:")
        print(f"  "{result[:180]}"")

print("
" + "=" * 70)
print("Summary:")
print("  Temperature  : controls sharpness of probability distribution")
print("  Top-k        : restricts pool to k highest-probability tokens")
print("  Top-p        : dynamically selects smallest set with cumulative prob > p")
print("  Best practice: combine top-p=0.9 with temperature=0.7-0.9 for quality+diversity")
print("=" * 70)
