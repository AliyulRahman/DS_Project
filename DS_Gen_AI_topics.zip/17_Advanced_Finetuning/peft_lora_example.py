"""
PEFT/LoRA Fine-tuning Example using GPT-2
Run: pip install transformers peft torch accelerate
     python peft_lora_example.py
"""

import subprocess
import sys

for pkg in ['transformers', 'peft', 'torch', 'accelerate']:
    subprocess.run([sys.executable, '-m', 'pip', 'install', pkg, '-q'], check=True)

import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer
from peft import get_peft_model, LoraConfig, TaskType

print("=" * 65)
print("PEFT / LoRA Fine-tuning Demonstration")
print("=" * 65)

# ── Load base GPT-2 ──
print("
Loading GPT-2 base model...")
model     = GPT2LMHeadModel.from_pretrained('gpt2')
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
tokenizer.pad_token = tokenizer.eos_token

# ── Count original parameters ──
total_params = sum(p.numel() for p in model.parameters())
print(f"Original parameters: {total_params:,}")

# ── Apply LoRA ──
print("
Applying LoRA configuration...")
lora_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM,
    r=8,               # rank — lower = fewer trainable params
    lora_alpha=32,     # scaling factor (effective_lr = lora_alpha / r)
    target_modules=["c_attn"],  # apply to attention projection matrices
    lora_dropout=0.1,
    bias="none",
)

peft_model = get_peft_model(model, lora_config)

trainable   = sum(p.numel() for p in peft_model.parameters() if p.requires_grad)
reduction   = (1 - trainable / total_params) * 100
print(f"Total parameters:      {total_params:>12,}")
print(f"Trainable parameters:  {trainable:>12,}")
print(f"Parameter reduction:   {reduction:.2f}%  fewer parameters to train!")
print()
peft_model.print_trainable_parameters()

# ── 10 Q&A fine-tuning examples ──
QA_PAIRS = [
    ("Q: What is machine learning? A:", "Machine learning is a branch of AI that enables computers to learn from data without being explicitly programmed."),
    ("Q: What is deep learning? A:", "Deep learning uses multi-layered neural networks to automatically learn hierarchical representations from raw data."),
    ("Q: What is a neural network? A:", "A neural network is a computational model inspired by the brain, consisting of interconnected layers of neurons."),
    ("Q: What is supervised learning? A:", "Supervised learning trains models on labelled data, learning to map inputs to known outputs."),
    ("Q: What is overfitting? A:", "Overfitting occurs when a model learns the training data too well and fails to generalise to new unseen data."),
    ("Q: What is gradient descent? A:", "Gradient descent is an optimisation algorithm that minimises the loss function by iteratively updating parameters."),
    ("Q: What is a transformer? A:", "A transformer is a neural network architecture using self-attention to process sequences in parallel."),
    ("Q: What is LoRA? A:", "LoRA adds trainable low-rank matrices to frozen model weights, enabling efficient fine-tuning with minimal parameters."),
    ("Q: What is fine-tuning? A:", "Fine-tuning adapts a pre-trained model to a specific task by continuing training on a smaller task-specific dataset."),
    ("Q: What is the attention mechanism? A:", "Attention allows models to dynamically focus on different parts of the input sequence when producing each output token."),
]

# ── Simple training loop (2 epochs) ──
device    = 'cuda' if torch.cuda.is_available() else 'cpu'
peft_model.to(device)

optimizer = torch.optim.AdamW(
    [p for p in peft_model.parameters() if p.requires_grad],
    lr=5e-4
)

print(f"
Fine-tuning on {len(QA_PAIRS)} Q&A pairs (device: {device})...")
print("Epochs: 3
")

peft_model.train()
for epoch in range(3):
    total_loss = 0
    for question, answer in QA_PAIRS:
        text   = question + " " + answer
        inputs = tokenizer(text, return_tensors='pt',
                           truncation=True, max_length=128,
                           padding='max_length')
        input_ids = inputs['input_ids'].to(device)

        optimizer.zero_grad()
        outputs = peft_model(input_ids=input_ids, labels=input_ids)
        loss    = outputs.loss
        loss.backward()
        torch.nn.utils.clip_grad_norm_(peft_model.parameters(), 1.0)
        optimizer.step()
        total_loss += loss.item()

    print(f"  Epoch {epoch+1}/3 — Loss: {total_loss/len(QA_PAIRS):.4f}")

# ── Generate responses ──
print("
--- Generating Responses After LoRA Fine-tuning ---")
test_questions = [
    "Q: What is machine learning? A:",
    "Q: What is overfitting? A:",
    "Q: What is fine-tuning? A:",
]

peft_model.eval()
for q in test_questions:
    inputs  = tokenizer(q, return_tensors='pt').to(device)
    with torch.no_grad():
        outputs = peft_model.generate(
            inputs['input_ids'],
            max_new_tokens=60,
            do_sample=True,
            temperature=0.7,
            top_p=0.9,
            pad_token_id=tokenizer.eos_token_id
        )
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    print(f"
{q}")
    print(f"  -> {response[len(q):].strip()}")

print("
" + "=" * 65)
print("LoRA fine-tuning demo complete!")
print(f"Only {trainable:,} parameters were trained out of {total_params:,} total.")
print(f"That is just {trainable/total_params*100:.3f}% of the model!")
