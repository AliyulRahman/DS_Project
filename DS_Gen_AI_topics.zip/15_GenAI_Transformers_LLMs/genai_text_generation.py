"""
Text Generation using GPT-2
Run: pip install transformers torch
     python genai_text_generation.py
"""

from transformers import pipeline


def generate_text(prompt, max_length=150, num_sequences=2):
    """Generate text continuations for a given prompt using GPT-2."""
    print("Loading GPT-2 model (first run downloads ~500MB)...")
    generator = pipeline('text-generation', model='gpt2')
    results = generator(
        prompt,
        max_length=max_length,
        num_return_sequences=num_sequences,
        truncation=True,
        pad_token_id=50256,
        do_sample=True,
        temperature=0.9,
        top_p=0.95,
    )
    return [r['generated_text'] for r in results]


def main():
    prompts = [
        "Once upon a time in a small village,",
        "The future of artificial intelligence is",
        "The best way to learn data science is"
    ]

    print("=" * 60)
    print("GPT-2 Text Generation Demo")
    print("=" * 60)

    for prompt in prompts:
        print(f"
Prompt: {prompt}")
        print("-" * 50)
        outputs = generate_text(prompt)
        for i, text in enumerate(outputs, 1):
            print(f"
Output {i}:
{text}
")
        print("=" * 60)


if __name__ == "__main__":
    main()
