"""
Project: Text Generation using GPT-2
=====================================
Description:
    This script uses GPT-2, a decoder-only Transformer model from OpenAI (available
    on Hugging Face), to generate creative text continuations from user-provided prompts.
    GPT-2 was trained on ~40GB of internet text and can produce coherent, contextually
    relevant continuations.

How to Run:
    1. Install dependencies: pip install -r requirements_15.txt
    2. Run: python genai_project1_text_generation.py
    3. First run will download GPT-2 weights (~500MB) from Hugging Face Hub.

Key Concepts Demonstrated:
    - Loading a pre-trained GPT-2 model with the Hugging Face pipeline API
    - Controlling generation with temperature, top_p, top_k, repetition_penalty
    - Generating multiple sequences from the same prompt
    - Using GPT2Tokenizer and GPT2LMHeadModel directly (lower-level API)

# Installation: pip install -r requirements_15.txt
"""

import os
import sys

# ─── Suppress TensorFlow/Transformers info logs ─────────────────────────────
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

try:
    from transformers import pipeline, GPT2LMHeadModel, GPT2Tokenizer
    import torch
except ImportError as e:
    print(f"ERROR: Required library not found: {e}")
    print("Please install dependencies: pip install -r requirements_15.txt")
    sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Function 1: Simple pipeline-based text generation
# ─────────────────────────────────────────────────────────────────────────────

def generate_with_pipeline(prompt, max_new_tokens=80, num_sequences=3, temperature=0.9):
    """
    Generate text continuations using the Hugging Face pipeline API.

    The pipeline abstracts tokenisation, model inference, and decoding into
    a single easy-to-use function call.

    Args:
        prompt (str): The starting text the model will continue.
        max_new_tokens (int): Maximum number of NEW tokens to generate (beyond the prompt).
        num_sequences (int): How many different continuations to generate.
        temperature (float): Controls randomness.
                             0.1 = deterministic, 1.0 = balanced, 2.0 = very creative.

    Returns:
        list[str]: List of generated text strings.
    """
    print(f"\n{'='*60}")
    print(f"PROMPT: {prompt}")
    print(f"{'='*60}")

    # Load the GPT-2 pipeline
    # 'text-generation' tells the pipeline to use a causal language model
    # model='gpt2' downloads the 124M parameter base GPT-2 model
    generator = pipeline(
        "text-generation",
        model="gpt2",
        # Use GPU if available, otherwise CPU
        device=0 if torch.cuda.is_available() else -1
    )

    # Generate text continuations
    # do_sample=True: use sampling instead of greedy decoding
    # temperature: controls the sharpness of the probability distribution
    #   - low temperature → peaks around the most likely token
    #   - high temperature → flatter distribution → more diverse outputs
    # top_p=0.95: nucleus sampling — only sample from tokens whose cumulative
    #   probability is >= 95%, filtering out very unlikely tokens
    # top_k=50: also limit to the top 50 most probable tokens
    # repetition_penalty: penalise tokens that have already appeared (> 1.0 reduces repetition)
    outputs = generator(
        prompt,
        max_new_tokens=max_new_tokens,
        num_return_sequences=num_sequences,
        do_sample=True,
        temperature=temperature,
        top_p=0.95,
        top_k=50,
        repetition_penalty=1.2,
        pad_token_id=50256  # GPT-2's EOS token ID — used as padding token
    )

    # Extract and display the generated texts
    results = []
    for i, output in enumerate(outputs, 1):
        # 'generated_text' key contains the full text (prompt + continuation)
        generated_text = output["generated_text"]
        results.append(generated_text)
        print(f"\n--- Sequence {i} ---")
        print(generated_text)

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Function 2: Lower-level generation with GPT2LMHeadModel
# ─────────────────────────────────────────────────────────────────────────────

def generate_with_model_directly(prompt, max_new_tokens=100, temperature=0.8):
    """
    Generate text using GPT2LMHeadModel and GPT2Tokenizer directly.

    This lower-level approach gives more control over the generation process
    and is useful for understanding what happens under the hood.

    GPT-2 Architecture:
        - 12 Transformer decoder layers
        - 12 attention heads per layer
        - 768-dimensional embeddings
        - 50,257 token vocabulary (BPE tokenisation)
        - 1024 token context window

    Args:
        prompt (str): Starting text for generation.
        max_new_tokens (int): Number of new tokens to generate.
        temperature (float): Sampling temperature.

    Returns:
        str: The generated text continuation.
    """
    print(f"\n{'='*60}")
    print("LOWER-LEVEL GPT-2 GENERATION")
    print(f"Prompt: {prompt}")
    print(f"{'='*60}")

    # Step 1: Load the tokeniser
    # GPT2Tokenizer uses Byte Pair Encoding (BPE) — a subword tokenisation method
    # The tokeniser converts text → integer token IDs
    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")

    # GPT-2 was trained without a padding token — we set eos_token as pad_token
    tokenizer.pad_token = tokenizer.eos_token

    # Step 2: Load the pre-trained model
    # GPT2LMHeadModel = GPT-2 backbone + language model head (linear layer → vocabulary)
    # The LM head predicts probabilities over all 50,257 tokens at each position
    model = GPT2LMHeadModel.from_pretrained("gpt2")
    model.eval()  # Switch to evaluation mode (disables dropout)

    # Move to GPU if available
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    print(f"Using device: {device}")

    # Step 3: Tokenise the prompt
    # return_tensors='pt' returns PyTorch tensors
    # The output contains 'input_ids': shape [1, sequence_length]
    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        return_attention_mask=True
    )
    input_ids = inputs["input_ids"].to(device)
    attention_mask = inputs["attention_mask"].to(device)

    print(f"Prompt tokens: {input_ids.shape[1]} tokens")

    # Step 4: Generate tokens auto-regressively
    # model.generate() implements beam search, sampling, and greedy decoding
    # Here we use sampling with temperature
    with torch.no_grad():  # Disable gradient computation for inference
        output_ids = model.generate(
            input_ids,
            attention_mask=attention_mask,
            max_new_tokens=max_new_tokens,
            do_sample=True,           # Use sampling (not greedy)
            temperature=temperature,  # Sampling temperature
            top_p=0.92,               # Nucleus sampling threshold
            top_k=40,                 # Top-k filtering
            repetition_penalty=1.3,  # Penalise repeated phrases
            pad_token_id=tokenizer.eos_token_id
        )

    # Step 5: Decode the output token IDs back to text
    # skip_special_tokens=True removes [PAD], [EOS], etc. from the output
    generated_text = tokenizer.decode(output_ids[0], skip_special_tokens=True)

    print(f"\nGenerated Text:")
    print(generated_text)
    print(f"\nGenerated tokens: {output_ids.shape[1] - input_ids.shape[1]}")

    return generated_text


# ─────────────────────────────────────────────────────────────────────────────
# Function 3: Compare generation with different temperatures
# ─────────────────────────────────────────────────────────────────────────────

def compare_temperatures(prompt):
    """
    Demonstrate the effect of temperature on text generation.

    Temperature controls the sharpness of the token probability distribution:
    - Low temperature (0.1): model is very confident, almost deterministic
    - Medium temperature (1.0): balanced between creativity and coherence
    - High temperature (1.5): very creative but may be incoherent

    Args:
        prompt (str): The prompt to generate from.
    """
    print(f"\n{'='*60}")
    print("TEMPERATURE COMPARISON")
    print(f"Prompt: {prompt}")
    print(f"{'='*60}")

    # Load model and tokenizer once for efficiency
    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
    tokenizer.pad_token = tokenizer.eos_token
    model = GPT2LMHeadModel.from_pretrained("gpt2")
    model.eval()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    # Tokenise the prompt
    input_ids = tokenizer(prompt, return_tensors="pt")["input_ids"].to(device)

    temperatures = [0.3, 1.0, 1.8]
    descriptions = ["Deterministic (T=0.3)", "Balanced (T=1.0)", "Creative (T=1.8)"]

    for temp, desc in zip(temperatures, descriptions):
        with torch.no_grad():
            output_ids = model.generate(
                input_ids,
                max_new_tokens=60,
                do_sample=True,
                temperature=temp,
                top_k=50,
                pad_token_id=tokenizer.eos_token_id
            )

        generated_text = tokenizer.decode(output_ids[0], skip_special_tokens=True)
        print(f"\n{desc}:")
        print(f"  {generated_text}")


# ─────────────────────────────────────────────────────────────────────────────
# Main function
# ─────────────────────────────────────────────────────────────────────────────

def main():
    """
    Run text generation demonstrations with multiple prompts and methods.
    """
    print("=" * 60)
    print("GPT-2 TEXT GENERATION PROJECT")
    print("Using Hugging Face Transformers library")
    print("=" * 60)

    # ── Demo 1: Pipeline-based generation with multiple prompts ──────────────
    print("\n\n[DEMO 1] Pipeline-based text generation")
    print("Generating 3 continuations for each of 3 prompts...")

    prompts = [
        "Once upon a time in a small village,",
        "The future of artificial intelligence is",
        "The best way to learn programming is"
    ]

    for prompt in prompts:
        try:
            generate_with_pipeline(
                prompt=prompt,
                max_new_tokens=80,
                num_sequences=3,
                temperature=0.9
            )
        except Exception as e:
            print(f"Error generating text for prompt '{prompt}': {e}")

    # ── Demo 2: Direct model API ─────────────────────────────────────────────
    print("\n\n[DEMO 2] Lower-level generation with GPT2LMHeadModel")
    try:
        generate_with_model_directly(
            prompt="Scientists have recently discovered a new planet that",
            max_new_tokens=100,
            temperature=0.85
        )
    except Exception as e:
        print(f"Error in direct generation: {e}")

    # ── Demo 3: Temperature comparison ───────────────────────────────────────
    print("\n\n[DEMO 3] Comparing generation at different temperatures")
    try:
        compare_temperatures(
            prompt="Deep learning is transforming the world by"
        )
    except Exception as e:
        print(f"Error in temperature comparison: {e}")

    print("\n" + "=" * 60)
    print("Text generation complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
