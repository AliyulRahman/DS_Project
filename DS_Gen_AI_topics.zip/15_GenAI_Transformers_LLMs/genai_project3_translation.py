"""
Project: Neural Machine Translation using Helsinki-NLP OPUS-MT Models
=======================================================================
Description:
    This script demonstrates multilingual machine translation using the
    Helsinki-NLP OPUS-MT model family from Hugging Face. Each model handles
    a specific language pair (e.g., English → French). These are encoder-decoder
    Transformer models trained on the OPUS corpus — a large collection of
    open-source parallel texts.

    We translate 5 English sentences into French, German, and Spanish,
    demonstrating multi-target translation.

How to Run:
    1. Install dependencies: pip install -r requirements_15.txt
    2. Run: python genai_project3_translation.py
    3. First run downloads models (~300MB each) from Hugging Face Hub.

Models Used:
    - Helsinki-NLP/opus-mt-en-fr  (English → French)
    - Helsinki-NLP/opus-mt-en-de  (English → German)
    - Helsinki-NLP/opus-mt-en-es  (English → Spanish)

Key Concepts Demonstrated:
    - Encoder-decoder Transformer models for seq2seq translation
    - Loading multiple language-pair models
    - Batch translation (translating multiple sentences at once)
    - Comparing translations across target languages

# Installation: pip install -r requirements_15.txt
"""

import os
import sys

os.environ["TOKENIZERS_PARALLELISM"] = "false"

try:
    from transformers import pipeline, MarianMTModel, MarianTokenizer
    import torch
except ImportError as e:
    print(f"ERROR: Required library not found: {e}")
    print("Please install dependencies: pip install -r requirements_15.txt")
    sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# English sentences to translate
# ─────────────────────────────────────────────────────────────────────────────

# Five diverse English sentences covering different contexts
ENGLISH_SENTENCES = [
    "Hello, how are you today?",
    "Machine learning is changing the world.",
    "The weather is beautiful in the spring.",
    "I would like to order a coffee, please.",
    "Education is the most powerful tool to change the world.",
]


# Language configurations: name, model ID, language code
LANGUAGE_CONFIGS = [
    {
        "name": "French",
        "code": "fr",
        "model": "Helsinki-NLP/opus-mt-en-fr",
        "example_note": "Romance language, ~80M native speakers"
    },
    {
        "name": "German",
        "code": "de",
        "model": "Helsinki-NLP/opus-mt-en-de",
        "example_note": "Germanic language, ~95M native speakers"
    },
    {
        "name": "Spanish",
        "code": "es",
        "model": "Helsinki-NLP/opus-mt-en-es",
        "example_note": "Romance language, ~500M native speakers"
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# Function 1: Translate using the pipeline API (simple approach)
# ─────────────────────────────────────────────────────────────────────────────

def translate_with_pipeline(sentences, target_lang_config):
    """
    Translate a list of sentences to a target language using the pipeline API.

    Helsinki-NLP OPUS-MT models use the MarianMT architecture:
        - Based on the Marian NMT C++ framework
        - Encoder: 6 Transformer encoder layers with self-attention
        - Decoder: 6 Transformer decoder layers with cross-attention to encoder
        - Vocabulary: SentencePiece tokenisation (~60K tokens)
        - Trained on OPUS: aligned parallel texts from subtitles, books, law, EU documents

    Args:
        sentences (list[str]): List of English sentences to translate.
        target_lang_config (dict): Configuration dict with 'name', 'model', etc.

    Returns:
        list[str]: Translated sentences in the target language.
    """
    lang_name = target_lang_config["name"]
    model_name = target_lang_config["model"]

    print(f"\n{'─'*55}")
    print(f"Translating to {lang_name} using {model_name}")
    print(f"{'─'*55}")

    # Detect device
    device = 0 if torch.cuda.is_available() else -1

    # Load the translation pipeline for this language pair
    # 'translation_en_to_XX' is a convention but 'translation' works too
    translator = pipeline(
        "translation",
        model=model_name,
        device=device
    )

    # Translate all sentences in a batch
    # The pipeline handles tokenisation, beam search decoding, and text conversion
    translations = translator(sentences)

    # Extract translated texts
    translated_texts = [t["translation_text"] for t in translations]

    return translated_texts


# ─────────────────────────────────────────────────────────────────────────────
# Function 2: Translate using MarianMTModel directly (lower-level)
# ─────────────────────────────────────────────────────────────────────────────

def translate_with_marian(sentences, model_name, source_lang="en", target_lang="fr"):
    """
    Translate sentences using MarianMTModel and MarianTokenizer directly.

    This gives more control and insight into the translation process:
    1. Tokenise source sentences
    2. Run encoder to get contextual representations
    3. Run decoder auto-regressively to generate target tokens
    4. Decode token IDs back to text

    Args:
        sentences (list[str]): English sentences to translate.
        model_name (str): Hugging Face model identifier.
        source_lang (str): Source language code.
        target_lang (str): Target language code.

    Returns:
        list[str]: List of translated texts.
    """
    print(f"\nLow-level translation: {source_lang} → {target_lang}")
    print(f"Model: {model_name}")

    # Load tokeniser — MarianTokenizer uses SentencePiece
    # SentencePiece is a language-agnostic subword tokeniser
    tokenizer = MarianTokenizer.from_pretrained(model_name)

    # Load the MarianMT model (encoder-decoder architecture)
    model = MarianMTModel.from_pretrained(model_name)
    model.eval()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    # Tokenise sentences
    # padding=True: pad all sentences to the same length in the batch
    # truncation=True: truncate if sentence exceeds model maximum
    # return_tensors='pt': return PyTorch tensors
    encoded = tokenizer(
        sentences,
        padding=True,
        truncation=True,
        max_length=512,
        return_tensors="pt"
    )

    # Move input tensors to the appropriate device
    input_ids = encoded["input_ids"].to(device)
    attention_mask = encoded["attention_mask"].to(device)

    # Generate translations
    # model.generate() runs beam search (default: num_beams=4)
    # Beam search maintains 4 partial translations simultaneously and
    # selects the sequence with highest log-probability
    with torch.no_grad():
        translated_ids = model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            num_beams=4,                    # Beam search with 4 beams
            max_length=512,
            early_stopping=True,            # Stop when all beams produce EOS
            length_penalty=0.6              # Penalise very long translations
        )

    # Decode the generated token IDs back to text
    # batch_decode processes multiple sequences at once
    translations = tokenizer.batch_decode(translated_ids, skip_special_tokens=True)

    return translations


# ─────────────────────────────────────────────────────────────────────────────
# Function 3: Display a formatted translation table
# ─────────────────────────────────────────────────────────────────────────────

def display_translation_table(sentences, all_translations):
    """
    Display a formatted comparison table of translations.

    Args:
        sentences (list[str]): Original English sentences.
        all_translations (dict): {lang_name: [translated_sentences]}
    """
    print(f"\n\n{'='*75}")
    print("COMPLETE TRANSLATION COMPARISON TABLE")
    print(f"{'='*75}")

    for i, sentence in enumerate(sentences):
        print(f"\n  English:  {sentence}")
        for lang_name, translations in all_translations.items():
            if i < len(translations):
                print(f"  {lang_name:<9} {translations[i]}")
        print(f"  {'─'*70}")


# ─────────────────────────────────────────────────────────────────────────────
# Function 4: Back-translation quality check
# ─────────────────────────────────────────────────────────────────────────────

def back_translate(original_sentence, target_model_name, back_model_name,
                   lang_name="French"):
    """
    Translate a sentence to a target language, then translate back to English.

    Back-translation is a common data augmentation technique and a rough
    quality check: if the round-trip translation preserves meaning well,
    the model is capturing semantic content accurately.

    Args:
        original_sentence (str): Original English sentence.
        target_model_name (str): Model for English → Target language.
        back_model_name (str): Model for Target language → English.
        lang_name (str): Name of the target language.

    Returns:
        tuple: (forward_translation, back_translation)
    """
    device = 0 if torch.cuda.is_available() else -1

    # Forward translation: English → Target
    forward_translator = pipeline("translation", model=target_model_name, device=device)
    forward_result = forward_translator([original_sentence])
    forward_translation = forward_result[0]["translation_text"]

    # Back translation: Target → English
    back_translator = pipeline("translation", model=back_model_name, device=device)
    back_result = back_translator([forward_translation])
    back_translation = back_result[0]["translation_text"]

    return forward_translation, back_translation


# ─────────────────────────────────────────────────────────────────────────────
# Main function
# ─────────────────────────────────────────────────────────────────────────────

def main():
    """
    Demonstrate multilingual translation to French, German, and Spanish.
    """
    print("=" * 65)
    print("NEURAL MACHINE TRANSLATION PROJECT")
    print("Helsinki-NLP OPUS-MT Models (Hugging Face)")
    print("=" * 65)
    print(f"\nTranslating {len(ENGLISH_SENTENCES)} sentences to "
          f"{len(LANGUAGE_CONFIGS)} languages...")

    # ── Demo 1: Translate all sentences to all three languages ───────────────
    print("\n[DEMO 1] Translating to French, German, and Spanish")

    all_translations = {}

    for lang_config in LANGUAGE_CONFIGS:
        lang_name = lang_config["name"]
        print(f"\nLoading model for {lang_name}...")

        try:
            translations = translate_with_pipeline(
                ENGLISH_SENTENCES,
                lang_config
            )
            all_translations[lang_name] = translations

            # Show individual results
            print(f"\nResults ({lang_name}):")
            for en, trans in zip(ENGLISH_SENTENCES, translations):
                print(f"  EN: {en}")
                print(f"  {lang_config['code'].upper()}: {trans}")
                print()

        except Exception as e:
            print(f"Error translating to {lang_name}: {e}")
            all_translations[lang_name] = ["[ERROR]"] * len(ENGLISH_SENTENCES)

    # ── Demo 2: Display complete comparison table ────────────────────────────
    print("\n[DEMO 2] Complete translation comparison table")
    if all_translations:
        display_translation_table(ENGLISH_SENTENCES, all_translations)

    # ── Demo 3: Back-translation quality check ───────────────────────────────
    print("\n\n[DEMO 3] Back-translation quality check (English → French → English)")
    test_sentence = "Artificial intelligence is transforming the way we work and live."

    try:
        forward, back = back_translate(
            original_sentence=test_sentence,
            target_model_name="Helsinki-NLP/opus-mt-en-fr",
            back_model_name="Helsinki-NLP/opus-mt-fr-en",
            lang_name="French"
        )
        print(f"\nOriginal   (EN): {test_sentence}")
        print(f"Translated (FR): {forward}")
        print(f"Back-Trans (EN): {back}")

        # Simple similarity check
        original_words = set(test_sentence.lower().split())
        back_words = set(back.lower().split())
        overlap = len(original_words & back_words) / len(original_words)
        print(f"\nWord overlap: {overlap:.0%} (rough quality indicator)")
        if overlap > 0.6:
            print("Good translation quality — key meaning preserved!")
        else:
            print("Some meaning may have been altered — typical for complex sentences.")

    except Exception as e:
        print(f"Back-translation demo failed (may need opus-mt-fr-en model): {e}")

    print("\n" + "=" * 65)
    print("Translation project complete!")
    print("\nModels used:")
    for lang_config in LANGUAGE_CONFIGS:
        print(f"  {lang_config['name']:<10}: {lang_config['model']}")
    print("=" * 65)


if __name__ == "__main__":
    main()
