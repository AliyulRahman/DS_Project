"""
Project: Text Summarisation using BART
========================================
Description:
    This script demonstrates abstractive text summarisation using the
    facebook/bart-large-cnn model (or the smaller sshleifer/distilbart-cnn-12-6
    as a fallback). BART (Bidirectional and Auto-Regressive Transformer) is an
    encoder-decoder model pre-trained with a denoising objective and fine-tuned
    on the CNN/DailyMail news summarisation dataset.

    Abstractive summarisation generates new sentences that capture the key points
    of a document — unlike extractive summarisation, which only selects existing sentences.

How to Run:
    1. Install dependencies: pip install -r requirements_15.txt
    2. Run: python genai_project2_summarization.py
    3. First run downloads model weights (~1.6GB for BART-large, ~306MB for DistilBART).

Key Concepts Demonstrated:
    - Encoder-decoder models for seq2seq tasks
    - Controlling summary length with min_length and max_length
    - Batch summarisation of multiple documents
    - Comparing full BART vs distilled DistilBART

# Installation: pip install -r requirements_15.txt
"""

import os
import sys

os.environ["TOKENIZERS_PARALLELISM"] = "false"

try:
    from transformers import pipeline, BartForConditionalGeneration, BartTokenizer
    import torch
except ImportError as e:
    print(f"ERROR: Required library not found: {e}")
    print("Please install dependencies: pip install -r requirements_15.txt")
    sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# Sample texts for summarisation
# ─────────────────────────────────────────────────────────────────────────────

# Three long sample texts (100+ words) covering different topics
SAMPLE_TEXTS = {
    "Climate Change": """
        Climate change refers to long-term shifts in global temperatures and weather patterns.
        While some of these changes are natural, since the mid-20th century human activities have
        been the main driver of climate change, primarily due to the burning of fossil fuels like
        coal, oil, and gas. The release of greenhouse gases such as carbon dioxide and methane into
        the atmosphere traps heat from the sun, causing the planet to warm — a phenomenon known as
        the greenhouse effect. Rising global temperatures have led to melting polar ice caps, rising
        sea levels, more frequent and severe weather events such as hurricanes, droughts, and
        heatwaves, and disruption to ecosystems worldwide. Scientists warn that without significant
        reductions in greenhouse gas emissions and a rapid transition to renewable energy sources
        like solar and wind power, the consequences could be catastrophic for human civilisation
        and the natural world. International agreements such as the Paris Agreement aim to limit
        global warming to 1.5 degrees Celsius above pre-industrial levels by coordinating action
        among nations to reduce emissions and invest in clean energy technologies.
    """,

    "Artificial Intelligence in Healthcare": """
        Artificial intelligence is rapidly transforming the healthcare industry, offering
        unprecedented opportunities to improve patient outcomes, reduce costs, and enhance the
        efficiency of medical services. Machine learning algorithms can now analyse medical images
        such as X-rays, CT scans, and MRIs with accuracy comparable to or exceeding that of
        experienced radiologists, enabling earlier and more accurate detection of diseases including
        cancer, cardiovascular conditions, and neurological disorders. Natural language processing
        technologies allow AI systems to process and extract meaningful information from millions
        of unstructured clinical notes, research papers, and patient records in seconds, providing
        clinicians with evidence-based recommendations at the point of care. AI-powered drug
        discovery platforms are dramatically accelerating the identification of potential therapeutic
        compounds by predicting molecular interactions and simulating biological processes at a
        fraction of the time and cost of traditional laboratory methods. Personalised medicine,
        enabled by AI analysis of genomic data and individual patient profiles, promises to
        tailor treatments to each patient's unique biological makeup rather than relying on
        one-size-fits-all approaches. Despite these exciting advances, challenges remain around
        data privacy, algorithmic bias, regulatory approval, and the need for transparency in
        AI-driven clinical decisions to maintain physician trust and patient safety.
    """,

    "Space Exploration": """
        Space exploration has entered a transformative new era driven by the emergence of private
        space companies alongside traditional government agencies. SpaceX, founded by Elon Musk,
        has revolutionised access to space with its reusable Falcon 9 rockets and Dragon capsules,
        dramatically reducing launch costs and enabling more frequent missions. NASA's Artemis
        programme aims to return humans to the Moon by the mid-2020s and use lunar missions as
        a stepping stone for eventual crewed expeditions to Mars. The James Webb Space Telescope,
        launched in December 2021, has provided humanity with the deepest and sharpest infrared
        images of the universe ever captured, revealing galaxies formed just hundreds of millions
        of years after the Big Bang and offering new insights into the formation of stars and
        planetary systems. Robotic missions continue to explore the solar system, with NASA's
        Perseverance rover actively collecting rock samples on Mars that could provide evidence
        of ancient microbial life. Meanwhile, commercial satellite constellations like SpaceX's
        Starlink are bringing high-speed internet connectivity to remote areas of Earth. The coming
        decades promise even more ambitious missions: returning Mars samples to Earth, building
        permanent lunar bases, and potentially launching the first crewed mission to Mars before 2050.
    """
}


# ─────────────────────────────────────────────────────────────────────────────
# Function 1: Summarise using the pipeline API
# ─────────────────────────────────────────────────────────────────────────────

def summarise_with_pipeline(texts_dict, model_name="sshleifer/distilbart-cnn-12-6",
                             min_length=40, max_length=130):
    """
    Summarise multiple texts using the Hugging Face summarisation pipeline.

    BART Architecture:
        - Encoder: bidirectional Transformer (like BERT) reads the full document
        - Decoder: auto-regressive Transformer generates the summary token by token
        - Fine-tuned on CNN/DailyMail: ~287,000 news articles with highlights

    Model options:
        - facebook/bart-large-cnn: full model, best quality (~1.6GB download)
        - sshleifer/distilbart-cnn-12-6: distilled, 6x smaller, similar quality

    Args:
        texts_dict (dict): {topic: text} mapping of texts to summarise.
        model_name (str): Hugging Face model identifier.
        min_length (int): Minimum summary length in tokens (prevents trivially short summaries).
        max_length (int): Maximum summary length in tokens.
    """
    print(f"\n{'='*65}")
    print(f"SUMMARISATION WITH: {model_name}")
    print(f"min_length={min_length}, max_length={max_length}")
    print(f"{'='*65}")

    # Load the summarisation pipeline
    # The pipeline handles: tokenisation → inference → decoding
    print(f"\nLoading model '{model_name}'... (may take a moment on first run)")

    # Detect device: use GPU if available
    device = 0 if torch.cuda.is_available() else -1

    summariser = pipeline(
        "summarization",
        model=model_name,
        device=device
    )

    print("Model loaded successfully!\n")

    results = {}

    for topic, text in texts_dict.items():
        print(f"\n{'─'*55}")
        print(f"TOPIC: {topic}")
        print(f"{'─'*55}")

        # Clean the text (remove leading/trailing whitespace)
        clean_text = text.strip()

        # Show original text length
        word_count = len(clean_text.split())
        print(f"Original text: {word_count} words")
        print(f"\nORIGINAL:")
        print(clean_text[:300] + "..." if len(clean_text) > 300 else clean_text)

        # Generate summary
        # truncation=True: if text exceeds model's max input length (1024 tokens for BART),
        #   truncate it rather than throwing an error
        # do_sample=False: use beam search (more reliable for summarisation than sampling)
        summary_output = summariser(
            clean_text,
            max_length=max_length,
            min_length=min_length,
            do_sample=False,       # Beam search for deterministic, high-quality summaries
            truncation=True        # Truncate input if it exceeds model maximum
        )

        # Extract the summary text from the output
        summary = summary_output[0]["summary_text"]

        summary_word_count = len(summary.split())
        compression_ratio = round(word_count / summary_word_count, 1)

        print(f"\nSUMMARY ({summary_word_count} words, {compression_ratio}x compression):")
        print(summary)

        results[topic] = {
            "original": clean_text,
            "summary": summary,
            "original_words": word_count,
            "summary_words": summary_word_count,
            "compression_ratio": compression_ratio
        }

    return results


# ─────────────────────────────────────────────────────────────────────────────
# Function 2: Demonstrate different length controls
# ─────────────────────────────────────────────────────────────────────────────

def demonstrate_length_control(text, topic="Sample Topic"):
    """
    Show how min_length and max_length parameters control summary length.

    This is useful when you need summaries of specific lengths:
    - Short summaries: for headlines or brief previews
    - Medium summaries: for abstracts and overviews
    - Long summaries: for detailed digests

    Args:
        text (str): Document to summarise.
        topic (str): Topic label for display.
    """
    print(f"\n{'='*65}")
    print(f"LENGTH CONTROL DEMONSTRATION — {topic}")
    print(f"{'='*65}")

    # Use the smaller model to reduce download time
    model_name = "sshleifer/distilbart-cnn-12-6"
    device = 0 if torch.cuda.is_available() else -1

    summariser = pipeline(
        "summarization",
        model=model_name,
        device=device
    )

    # Different length configurations
    length_configs = [
        {"name": "Short (headline)",   "min_length": 10, "max_length": 30},
        {"name": "Medium (abstract)",  "min_length": 40, "max_length": 80},
        {"name": "Long (digest)",      "min_length": 80, "max_length": 150},
    ]

    clean_text = text.strip()
    print(f"Original: {len(clean_text.split())} words\n")

    for config in length_configs:
        summary_output = summariser(
            clean_text,
            max_length=config["max_length"],
            min_length=config["min_length"],
            do_sample=False,
            truncation=True
        )
        summary = summary_output[0]["summary_text"]
        print(f"{config['name']} (min={config['min_length']}, max={config['max_length']}):")
        print(f"  [{len(summary.split())} words] {summary}")
        print()


# ─────────────────────────────────────────────────────────────────────────────
# Function 3: Summarise custom text provided by the user
# ─────────────────────────────────────────────────────────────────────────────

def summarise_custom(custom_text, min_length=30, max_length=100):
    """
    Summarise any custom text passed as a string.

    Args:
        custom_text (str): Any text you want summarised.
        min_length (int): Minimum summary length.
        max_length (int): Maximum summary length.

    Returns:
        str: Generated summary.
    """
    model_name = "sshleifer/distilbart-cnn-12-6"
    device = 0 if torch.cuda.is_available() else -1

    summariser = pipeline("summarization", model=model_name, device=device)

    result = summariser(
        custom_text,
        max_length=max_length,
        min_length=min_length,
        do_sample=False,
        truncation=True
    )
    return result[0]["summary_text"]


# ─────────────────────────────────────────────────────────────────────────────
# Main function
# ─────────────────────────────────────────────────────────────────────────────

def main():
    """
    Run summarisation demonstrations on multiple topics with different settings.
    """
    print("=" * 65)
    print("TEXT SUMMARISATION PROJECT — BART / DistilBART")
    print("Using Hugging Face Transformers library")
    print("=" * 65)

    # ── Demo 1: Summarise all three sample texts ─────────────────────────────
    print("\n[DEMO 1] Summarising 3 sample texts on different topics")
    print("Using: sshleifer/distilbart-cnn-12-6 (lighter model)")
    print("(For best quality, change to 'facebook/bart-large-cnn')")

    try:
        results = summarise_with_pipeline(
            SAMPLE_TEXTS,
            model_name="sshleifer/distilbart-cnn-12-6",
            min_length=45,
            max_length=120
        )

        # Print summary statistics
        print(f"\n\n{'='*65}")
        print("SUMMARY STATISTICS")
        print(f"{'='*65}")
        print(f"{'Topic':<35} {'Original':>8} {'Summary':>8} {'Ratio':>6}")
        print(f"{'─'*65}")
        for topic, data in results.items():
            print(
                f"{topic:<35} {data['original_words']:>8} "
                f"{data['summary_words']:>8} {data['compression_ratio']:>5}x"
            )

    except Exception as e:
        print(f"Error during summarisation: {e}")
        print("Check that transformers and torch are installed correctly.")

    # ── Demo 2: Length control ───────────────────────────────────────────────
    print("\n\n[DEMO 2] Demonstrating length control on Climate Change text")
    try:
        demonstrate_length_control(
            SAMPLE_TEXTS["Climate Change"],
            topic="Climate Change"
        )
    except Exception as e:
        print(f"Error in length control demo: {e}")

    print("\n" + "=" * 65)
    print("Summarisation project complete!")
    print("Tip: Replace 'sshleifer/distilbart-cnn-12-6' with")
    print("     'facebook/bart-large-cnn' for higher quality summaries.")
    print("=" * 65)


if __name__ == "__main__":
    main()
