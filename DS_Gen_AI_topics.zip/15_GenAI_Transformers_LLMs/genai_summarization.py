"""
Text Summarisation using facebook/bart-large-cnn
Run: pip install transformers torch
     python genai_summarization.py
"""

from transformers import pipeline


def summarise_text(text, max_length=130, min_length=30):
    """Summarise a long text using BART-large-CNN."""
    print("Loading BART summarisation model (first run downloads ~1.6GB)...")
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    result = summarizer(
        text,
        max_length=max_length,
        min_length=min_length,
        do_sample=False
    )
    return result[0]['summary_text']


# Sample long texts to summarise
texts = [
    """
    Artificial intelligence has made remarkable progress over the past decade.
    Deep learning models, particularly transformers, have revolutionised the field
    of natural language processing. These models, trained on vast amounts of text data,
    can now perform tasks such as translation, summarisation, question answering, and
    code generation at near-human or superhuman levels. The transformer architecture,
    introduced by Google researchers in 2017, uses attention mechanisms to process
    sequences in parallel rather than sequentially, enabling training on much larger
    datasets and producing significantly better representations of language.
    Companies like OpenAI, Google DeepMind, and Anthropic continue to push the
    boundaries of what is possible with large language models, releasing systems
    that can hold coherent multi-turn conversations, write poetry, debug code,
    and even pass professional exams.
    """,

    """
    Climate change represents one of the most significant challenges facing humanity
    in the twenty-first century. Rising global temperatures, caused primarily by the
    emission of greenhouse gases from burning fossil fuels, are leading to more frequent
    and intense extreme weather events, rising sea levels, and disruption to ecosystems
    worldwide. Scientists warn that without rapid and deep cuts in carbon dioxide emissions,
    the world will exceed the 1.5 degree Celsius warming threshold set by the Paris Agreement,
    leading to potentially catastrophic consequences for millions of people, particularly
    in low-lying coastal regions and developing countries. Renewable energy sources such
    as solar and wind power have become dramatically cheaper over the past decade,
    offering a viable pathway to decarbonising the electricity sector. However, achieving
    net-zero emissions by 2050 will also require transforming transportation, agriculture,
    industry, and buildings — a challenge requiring unprecedented global cooperation
    and investment.
    """,

    """
    Machine learning has transformed the healthcare industry in profound ways.
    Computer vision algorithms trained on millions of medical images can now detect
    early-stage cancers, diabetic retinopathy, and other conditions with accuracy
    matching or exceeding experienced specialists. Natural language processing models
    extract structured information from clinical notes, enabling better population
    health management and reducing the administrative burden on clinicians. Predictive
    models can identify patients at high risk of hospital readmission or sepsis,
    enabling earlier interventions. Drug discovery timelines are being compressed
    from years to months as AI models predict molecular structures and biological
    activity. Wearable devices combined with machine learning can monitor heart rhythms
    continuously and alert users and clinicians to potential arrhythmias. Despite these
    advances, challenges remain around data privacy, algorithmic bias, regulatory
    approval, and integration with existing clinical workflows.
    """
]


def main():
    print("=" * 60)
    print("Text Summarisation Demo — facebook/bart-large-cnn")
    print("=" * 60)

    for i, text in enumerate(texts, 1):
        print(f"
--- Sample Text {i} ---")
        print(f"Original ({len(text.split())} words):
{text.strip()[:300]}...
")
        summary = summarise_text(text.strip())
        print(f"Summary ({len(summary.split())} words):
{summary}")
        print("=" * 60)


if __name__ == "__main__":
    main()
