"""
Text Translation using Helsinki-NLP OPUS-MT models
Run: pip install transformers torch sentencepiece
     python genai_translation.py
"""

from transformers import pipeline


def translate_text(text, model_name):
    """Translate text using the specified Helsinki-NLP OPUS-MT model."""
    translator = pipeline("translation", model=model_name)
    result = translator(text, max_length=512)
    return result[0]['translation_text']


# Texts to translate
texts_en = [
    "Artificial intelligence is transforming the way we live and work.",
    "The best way to learn data science is through hands-on practice with real datasets.",
    "Natural language processing allows computers to understand and generate human language."
]

texts_fr = [
    "L'intelligence artificielle révolutionne notre façon de vivre et de travailler.",
    "La meilleure façon d'apprendre la science des données est la pratique.",
    "Le traitement du langage naturel permet aux ordinateurs de comprendre le langage humain."
]

texts_de = [
    "Künstliche Intelligenz verändert die Art und Weise, wie wir leben und arbeiten.",
    "Der beste Weg, Data Science zu lernen, ist praktische Arbeit mit echten Datensätzen.",
    "Die Verarbeitung natürlicher Sprache ermöglicht es Computern, menschliche Sprache zu verstehen."
]


def main():
    print("=" * 65)
    print("Text Translation Demo — Helsinki-NLP OPUS-MT")
    print("=" * 65)

    # English to French
    print("
--- English → French (Helsinki-NLP/opus-mt-en-fr) ---")
    print("Loading model...")
    for text in texts_en:
        translation = translate_text(text, "Helsinki-NLP/opus-mt-en-fr")
        print(f"
  EN: {text}")
        print(f"  FR: {translation}")

    # English to German
    print("
--- English → German (Helsinki-NLP/opus-mt-en-de) ---")
    print("Loading model...")
    for text in texts_en:
        translation = translate_text(text, "Helsinki-NLP/opus-mt-en-de")
        print(f"
  EN: {text}")
        print(f"  DE: {translation}")

    # French to English
    print("
--- French → English (Helsinki-NLP/opus-mt-fr-en) ---")
    print("Loading model...")
    for text in texts_fr:
        translation = translate_text(text, "Helsinki-NLP/opus-mt-fr-en")
        print(f"
  FR: {text}")
        print(f"  EN: {translation}")

    print("
" + "=" * 65)
    print("Translation demo complete!")


if __name__ == "__main__":
    main()
